﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ItemsPackMsrProvider
    {
        #region--Instance--
        public static ItemsPackMsrProvider Instance = new ItemsPackMsrProvider();
        #endregion

        #region--Insert ItemsPackMSR --
        public string InsertItemsPackMSR(ItemsPackMsr _item)
        {
            string returnMessage = "0";
            using (DBEntities db = new DBEntities())
            {
                returnMessage = ValidateUOMInsertion(_item);
                if (string.IsNullOrEmpty(returnMessage))
                {
                    if (_item.ItemsPackMsrNum == 0)
                    {
                        db.ItemsPackMsrs.Add(_item);
                        db.SaveChanges();
                        returnMessage = _item.ItemsPackMsrNum.ToString();

                    }
                    else
                    {
                        returnMessage = UpdateItemsPackMSR(_item) == 0 ? "0" : "";
                    }
                }
            }
            return returnMessage;
        }

        private string ValidateUOMInsertion(ItemsPackMsr _item)
        {
            string returnMessage = string.Empty;

            using (DBEntities db = new DBEntities())
            {
                ItemsPackMsr itemMSR = db.ItemsPackMsrs
                        .Where(x => x.ItemNum == _item.ItemNum && (x.Code == _item.Code || x.Description == _item.Description) && x.Active == true)
                        .FirstOrDefault();

                if (itemMSR != null && itemMSR.ItemsPackMsrNum != _item.ItemsPackMsrNum)
                {
                    returnMessage = "Item with same UOM code / Name already exists. Must be unique for the current item.";
                }
                else
                {
                    if (_item.IsBaseUOM == true)
                    {
                        List<ItemsPackMsr> listItemMSR = db.ItemsPackMsrs
                         .Where(x => x.ItemNum == _item.ItemNum && x.Active == true && x.IsBaseUOM == true)
                         .ToList();

                        if (listItemMSR.Count == 0)
                        {
                            returnMessage = "";
                        }
                        else
                        {
                            if (listItemMSR.Count > 0)
                                listItemMSR = listItemMSR.Where(x => x.ItemsPackMsrNum == _item.ItemsPackMsrNum).ToList();

                            if (listItemMSR.Count == 0)
                            {
                                returnMessage = "Error : Cannot have more then one unit of measure. Please deactivate the default one prior.";
                            }
                            else
                            {
                                returnMessage = "";
                            }
                        }
                    }
                }
            }

            return returnMessage;
        }
        #endregion

        #region--Update ItemsPackMSR --
        public int UpdateItemsPackMSR(ItemsPackMsr _item)
        {
            int itemID = 0;
            using (DBEntities db = new DBEntities())
            {
                ItemsPackMsr currItem = db.ItemsPackMsrs.Where(x => x.ItemsPackMsrNum == _item.ItemsPackMsrNum).FirstOrDefault();
                if (currItem != null)
                {
                    currItem.Active = _item.Active;
                    currItem.Code = _item.Code;
                    currItem.Description = _item.Description;
                    currItem.GlobalCustomerNum = _item.GlobalCustomerNum;
                    currItem.IsBaseUOM = _item.IsBaseUOM;
                    currItem.IsPurchaseDefault = _item.IsPurchaseDefault;
                    currItem.IsSalesDefault = _item.IsSalesDefault;
                    currItem.UnitPerPack = _item.UnitPerPack;
                    db.SaveChanges();

                    itemID = _item.ItemsPackMsrNum;
                }
            }
            return itemID;
        }
        #endregion

        #region--Get ItemsPackMsr--
        public List<ItemsPackMsr> GetItemsPackMsr(int itemsPackMsr)
        {
            List<ItemsPackMsr> rType = new List<ItemsPackMsr>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from u in db.ItemsPackMsrs where (u.ItemsPackMsrNum == itemsPackMsr || itemsPackMsr == 0) select u).ToList();
            }
            return rType;
        }

        #endregion

        #region--Get ItemsPackMsr--
        public bool DeleteItemsPackMSR(int itemsPackMsrNum)
        {
            bool isDeleted = false;
            ItemsPackMsr itemsPackMsr = new ItemsPackMsr();
            using (DBEntities db = new DBEntities())
            {
                itemsPackMsr = (from u in db.ItemsPackMsrs where (u.ItemsPackMsrNum == itemsPackMsrNum || itemsPackMsrNum == 0) select u).FirstOrDefault();
                if (itemsPackMsr != null)
                {
                    itemsPackMsr.Active = false;
                    db.SaveChanges();
                    isDeleted = true;
                }
            }
            return isDeleted;
        }

        #endregion

        #region-- Get Items Pack Msr For Item --
        public List<ItemsPackMsr> GetItemsPackMsrForItem(int itemNo)
        {
            List<ItemsPackMsr> rType = new List<ItemsPackMsr>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from u in db.ItemsPackMsrs where (u.ItemNum == itemNo && u.Active == true) select u).ToList();
            }
            return rType;
        }

        #endregion
    }
}
