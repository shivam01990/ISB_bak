﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class VocabularyDisplayProvider
    {
        #region--Instance--
        public static VocabularyDisplayProvider Instance = new VocabularyDisplayProvider();
        #endregion

        #region--Get Vocabulary Display--
        public List<VocabularyDisplay> LoadVocabulary(int VocabularyDisplayNum, int UserLanguageNum)
        {
            List<VocabularyDisplay> rType = new List<VocabularyDisplay>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.VocabularyDisplays where (c.VocabularyDisplayNum == VocabularyDisplayNum || VocabularyDisplayNum == 0) && (c.UserLanguageNum == UserLanguageNum || UserLanguageNum == 0)  select c).ToList();
                }
                catch(Exception ex) { }
            }
            return rType;
        }
        #endregion


        //********************************************************* 
        //Purpose:      Load the vocubulary details from the database. 
        //Inputs:       intVocabularyDisplayNum :  the value of the control number.    
        //              IntUserLanguage : User Language of the current user
        //Returns:      it will return the text value to display in the UI controls .
        //*********************************************************
        public string LoadVocabularyDisplay(int intVocabularyDisplayNum, int IntUserLanguage)
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var listVocabulary = dbcontext.VocabularyDisplays.Where(x => x.UserLanguageNum == IntUserLanguage && x.VocabularyDisplayNum == intVocabularyDisplayNum);

                    if (listVocabulary != null)
                    {
                        return listVocabulary.FirstOrDefault().TextValue;
                    }
                }

                return string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }
     

    }
}
