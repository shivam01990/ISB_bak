﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class PositionProvider
    {
        #region--Instance--
        public static PositionProvider Instance = new PositionProvider();
        #endregion

        #region--Get Gender--
        public List<Position> GetPosition(int PositionNum)
        {
            List<Position> rType = new List<Position>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Positions where (c.PositionNum == PositionNum || PositionNum == 0) && (c.Active == true) select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion
    }
}
