﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class TaxGroupProvider
    {

        #region--Instance--
        public static TaxGroupProvider Instance = new TaxGroupProvider();
        #endregion

        //********************************************************* 
        //Purpose:    Get all the Tax Groups from the database. 
        //Returns:    list of all the Tax Groups.
        //*********************************************************
        public List<TaxGroup> GetTaxGroups(int TaxGroupNum)
        {
            List<TaxGroup> rType = new List<TaxGroup>();
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    rType = (from t in dbcontext.TaxGroups
                             where (((t.TaxGroupNum == TaxGroupNum) || (TaxGroupNum == 0))&& (t.Active==true))
                             select t).ToList();
                }
                return rType;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
