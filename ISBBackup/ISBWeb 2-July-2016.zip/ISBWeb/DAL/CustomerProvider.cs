﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CustomerProvider
    {

        #region--Instance--
        public static CustomerProvider Instance = new CustomerProvider();
        #endregion

        //********************************************************* 
        //Purpose:      Save or update the BP data into DB. 
        //Inputs:       objBP :  the values of the BP object.    
        //              blnUpdate: it will check the value is true or false to make update/save
        //              IntUserID : User ID value
        //              IntUserLanguage : User Language of the user
        //Returns:      string value(message) to load from the endusertable .
        //*********************************************************
        public string SaveCustomer(BPEntity objBP, bool blnUpdate, int IntUserID, int IntUserLanguage, out bool blnIsSuccess)
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    if (objBP != null)
                    {
                        if (!blnUpdate)
                        {
                            // To check the BP code already exist or not
                            var IsCodeExist = dbcontext.BPs.Where(x => x.Code == objBP.Code);
                            if (IsCodeExist != null && IsCodeExist.ToList().Count > 0)
                            {
                                blnIsSuccess = false;
                                return EndUserTextProvider.Instance.LoadEndUserText(2, IntUserLanguage);

                            }
                        }

                        //To Insert/Update the record into DB
                        int i = int.Parse(dbcontext.p_SaveBP(objBP.BPNum, objBP.GlobalCustomerNum, objBP.Code, objBP.Name, objBP.Adress1, objBP.Adress2, objBP.City, objBP.State, objBP.ZipCode,
                                             objBP.Country, objBP.Balance, objBP.TotalCredit, objBP.LogoPath, objBP.InternNote, objBP.OrderNote, objBP.Email, objBP.WebSite,
                                             objBP.FaceBook, objBP.Active, objBP.GlobalCategoryNum, objBP.BusinessCategoryNum, objBP.TaxGroupNum, objBP.CurrencyNum, objBP.PaymentTermsNum,
                                             objBP.RatingValueNum, objBP.CustomField1Name, objBP.CustomField1Value, objBP.CustomField1Vis, objBP.CustomField2Name, objBP.CustomField2Value, objBP.CustomField2Vis,
                                             objBP.CustomField3Name, objBP.CustomField3Value, objBP.CustomField3Vis, objBP.CustomField4Name, objBP.CustomField4Value, objBP.CustomField4Vis,
                                             objBP.CustomField5Name, objBP.CustomField5Value, objBP.CustomField5Vis, objBP.CustomField6Name, objBP.CustomField6Value, objBP.CustomField6Vis,
                                             objBP.CustomField7Name, objBP.CustomField7Value, objBP.CustomField7Vis, objBP.CustomField8Name, objBP.CustomField8Value, objBP.CustomField8Vis).FirstOrDefault().ToString());

                        //LogDBChanges(1, IntUserID, "UPDATE", "");

                    }
                    blnIsSuccess = true;
                    return EndUserTextProvider.Instance.LoadEndUserText(1, IntUserLanguage);
                }
            }
            catch (Exception)
            {
                blnIsSuccess = false;
                return EndUserTextProvider.Instance.LoadEndUserText(3, IntUserLanguage);
            }
        }


        //********************************************************* 
        //Purpose:      Get the details of the existing customer. 
        //Inputs:       IntBPNumber :  the value of the BP number.    
        //Returns:    it will return matching BP object from the db if number is matchched else return null value.
        //*********************************************************
        public BPEntity GetCustomer(int IntBPNumber)
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var objBP = dbcontext.BPs.Where(x => x.BPNum == IntBPNumber).FirstOrDefault();

                    if (objBP != null)
                    {
                        var objBpEntity = new BPEntity()
                        {
                            Name = objBP.Name,
                            Code = objBP.Code,
                            BPNum = objBP.BPNum,
                            Adress1 = objBP.Adress1,
                            Adress2 = objBP.Adress2,
                            Balance = objBP.Balance,
                            TotalCredit = objBP.TotalCredit,
                            OrderNote = objBP.OrderNote,
                            InternNote = objBP.InternNote,
                            City = objBP.City,
                            State = objBP.State,
                            Country = objBP.Country,
                            ZipCode = objBP.ZipCode,
                            Active = objBP.Active,
                            BusinessCategoryNum = objBP.BusinessCategoryNum,
                            LogoPath = objBP.LogoPath,
                            WebSite = objBP.WebSite,
                            Email = objBP.Email,
                            FaceBook = objBP.FaceBook,
                            GlobalCategoryNum = objBP.GlobalCategoryNum,
                            GlobalCustomerNum = objBP.GlobalCustomerNum,
                            PaymentTermsNum = objBP.PaymentTermsNum,
                            RatingValueNum = objBP.RatingValueNum,
                            TaxGroupNum = objBP.TaxGroupNum,
                            CurrencyNum = objBP.CurrencyNum,
                            CustomField1Name = objBP.CustomField1Name,
                            CustomField1Value = objBP.CustomField1Value,
                            CustomField1Vis = objBP.CustomField1Vis,
                            CustomField2Name = objBP.CustomField2Name,
                            CustomField2Value = objBP.CustomField2Value,
                            CustomField2Vis = objBP.CustomField2Vis,
                            CustomField3Name = objBP.CustomField3Name,
                            CustomField3Value = objBP.CustomField3Value,
                            CustomField3Vis = objBP.CustomField3Vis,
                            CustomField4Name = objBP.CustomField4Name,
                            CustomField4Value = objBP.CustomField4Value,
                            CustomField4Vis = objBP.CustomField4Vis,
                            CustomField5Name = objBP.CustomField5Name,
                            CustomField5Value = objBP.CustomField5Value,
                            CustomField5Vis = objBP.CustomField5Vis,
                            CustomField6Name = objBP.CustomField6Name,
                            CustomField6Value = objBP.CustomField6Value,
                            CustomField6Vis = objBP.CustomField6Vis,
                            CustomField7Name = objBP.CustomField7Name,
                            CustomField7Value = objBP.CustomField7Value,
                            CustomField7Vis = objBP.CustomField7Vis,
                            CustomField8Name = objBP.CustomField8Name,
                            CustomField8Value = objBP.CustomField8Value,
                            CustomField8Vis = objBP.CustomField8Vis,

                        };
                        return objBpEntity;

                    }
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //********************************************************* 
        //Purpose:      Get the Maximum BPnumber . 
        //Returns:      return the max value from the BP table and return the value+1.
        //*********************************************************
        public int GetMaxBPNum()
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var IntBPNum = dbcontext.BPs.OrderByDescending(x => x.BPNum).FirstOrDefault().BPNum + 1;

                    return IntBPNum;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //********************************************************* 
        //Purpose:      To Search the Customer based on the filters. 
        //Inputs:       objBP :  the values of the BPEntitySearch object.    
        //Returns:      Return the same object to bind the data into the grid.
        //*********************************************************
        public List<BPEntitySearch> SearchCustomer(BPEntitySearch objBP)
        {
            try
            {
                var listCustomers = new List<BPEntitySearch>();
                using (var dbcontext = new DBEntities())
                {
                    if (objBP != null)
                    {
                        var resultCustomer = dbcontext.p_GetCustomerSearch(objBP.Page, objBP.RecordsPerPage, objBP.Name, objBP.Code, objBP.City, objBP.State, objBP.ZipCode, objBP.InternalNote,
                                                        objBP.GlobalCategoryNum, objBP.BusinessCategoryNum, objBP.Email, objBP.IsActive).ToList();

                        //var resultCustomer = dbcontext.p_GetCustomerSearch().ToList();

                        if (resultCustomer != null && resultCustomer.Count() > 0)
                        {
                            foreach (var item in resultCustomer.ToList())
                            {
                                listCustomers.Add(new BPEntitySearch() { BPNum = item.BPNum, Code = item.Code, Name = item.Name, City = item.City, State = item.State, GlobalCategory = item.GlobalCategoryName, LogoPath = item.LogoPath, TotalRecords = 27 });

                            }
                        }
                    }
                }

                return listCustomers;
            }
            catch (Exception)
            {
                return null;
            }
        }

        // Commented this code based on the dicussion with Steeve - 25-11-2015
        //public void LogDBChanges(int IntIDModule, int IntUser, string StrChangeType,string StrSQLQuery)
        //{
        //    using (var dbcontext = new DBEntities())
        //    {
        //        var ModuleID = new SqlParameter("@ModuleID", IntIDModule);
        //        var UserID = new SqlParameter("@UserID", IntUser);
        //        var ChangeType = new SqlParameter("@ChangeType", StrChangeType);
        //        var SQLQuery = new SqlParameter("@SQLQuery", StrSQLQuery);

        //        var result = dbcontext.Database
        //            .SqlQuery<string>("USP_LogDBChanges @ModuleID , @UserID ,@ChangeType ,@SQLQuery ", ModuleID, IntUser,StrChangeType, SQLQuery);
        //    }

        //}
    }

    #region "--Entities--"

    public partial class BPEntity
    {
        public int BPNum { get; set; }
        public int GlobalCustomerNum { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Adress1 { get; set; }
        public string Adress2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; }
        public Nullable<double> Balance { get; set; }
        public Nullable<double> TotalCredit { get; set; }
        public string LogoPath { get; set; }
        public string InternNote { get; set; }
        public string OrderNote { get; set; }
        public string Email { get; set; }
        public string WebSite { get; set; }
        public string FaceBook { get; set; }
        public Nullable<bool> Active { get; set; }
        public Nullable<int> GlobalCategoryNum { get; set; }
        public Nullable<int> BusinessCategoryNum { get; set; }
        public Nullable<int> TaxGroupNum { get; set; }
        public Nullable<int> CurrencyNum { get; set; }
        public Nullable<int> PaymentTermsNum { get; set; }
        public Nullable<int> RatingValueNum { get; set; }
        public string CustomField1Name { get; set; }
        public string CustomField1Value { get; set; }
        public Nullable<bool> CustomField1Vis { get; set; }
        public string CustomField2Name { get; set; }
        public string CustomField2Value { get; set; }
        public Nullable<bool> CustomField2Vis { get; set; }
        public string CustomField3Name { get; set; }
        public string CustomField3Value { get; set; }
        public Nullable<bool> CustomField3Vis { get; set; }
        public string CustomField4Name { get; set; }
        public string CustomField4Value { get; set; }
        public Nullable<bool> CustomField4Vis { get; set; }
        public string CustomField5Name { get; set; }
        public string CustomField5Value { get; set; }
        public Nullable<bool> CustomField5Vis { get; set; }
        public string CustomField6Name { get; set; }
        public string CustomField6Value { get; set; }
        public Nullable<bool> CustomField6Vis { get; set; }
        public string CustomField7Name { get; set; }
        public string CustomField7Value { get; set; }
        public Nullable<bool> CustomField7Vis { get; set; }
        public string CustomField8Name { get; set; }
        public string CustomField8Value { get; set; }
        public Nullable<bool> CustomField8Vis { get; set; }
    }

    public class BPEntitySearch
    {
        public int BPNum { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string InternalNote { get; set; }
        public string Email { get; set; }
        public int GlobalCategoryNum { get; set; }
        public int BusinessCategoryNum { get; set; }
        public string LogoPath { get; set; }
        public bool IsActive { get; set; }
        public int Page { get; set; }
        public int RecordsPerPage { get; set; }
        public int TotalRecords { get; set; }
        public string GlobalCategory { get; set; }
        public string BusinessCategory { get; set; }
    }

    #endregion

}

