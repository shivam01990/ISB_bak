﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class TaxesProvider
    {

        #region--Instance--
        public static TaxesProvider Instance = new TaxesProvider();
        #endregion

        #region--Get Tax--
        public List<Tax> GetTax(int TaxNum)
        {
            List<Tax> rType = new List<Tax>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Taxes
                             where ((c.TaxeNum == TaxNum || TaxNum == 0)
                                 && (c.Active == true))
                             select c).ToList();
                }
                catch (Exception ex) { }
            }
            return rType;
        }
        #endregion
    }
}
