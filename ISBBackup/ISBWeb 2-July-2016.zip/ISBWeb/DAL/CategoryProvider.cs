﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CategoryProvider
    {
        #region--Instance--
        public static CategoryProvider Instance = new CategoryProvider();
        #endregion

        #region--Get Category--
        public List<Category> GetCategory(int categoryNum)
        {
            List<Category> rType = new List<Category>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Categories where (c.CategoryNum == categoryNum || categoryNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
