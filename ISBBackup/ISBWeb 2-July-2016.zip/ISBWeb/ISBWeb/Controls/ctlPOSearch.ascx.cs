﻿using BLL;
using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.Controls
{
    public partial class ctlPOSearch : System.Web.UI.UserControl
    {
        #region ---Declaration---
        protected int PageSize = 25;
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }
        #endregion

        #region--Page Load--
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["msg"] != null)
                {
                    if (Request.QueryString["msg"] == "1")
                    {
                        Helper.ShowMessage(DivMsg, "Purchase Order Successfully Saved.", true);
                    }
                }
                BindDropdowns();
                BindPOOrder();
            }
        }
        #endregion

        #region--Bind DropDown--
        public void BindDropdowns()
        {
            FilterUserEntity _FilterUserEntity = new FilterUserEntity();
            _FilterUserEntity.Active = true;
            _FilterUserEntity.UserNum = 0;
            _FilterUserEntity.IsManager = null;
            List<p_FilterUsers_Result> _UserList = UserServices.Instance.FilterUsers(_FilterUserEntity);
            var UserQuery = _UserList.Select(p => new { UserId = p.UserNum, DisplayText = p.FirstName + " " + p.LastName });
            ddlSalesRep.AppendDataBoundItems = true;
            ddlSalesRep.DataTextField = "DisplayText";
            ddlSalesRep.DataValueField = "UserId";
            ddlSalesRep.DataSource = UserQuery;
            ddlSalesRep.DataBind();
            ddlSalesRep.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));

            ddlStatus.AppendDataBoundItems = true;
            ddlStatus.DataTextField = "Name";
            ddlStatus.DataValueField = "DocSatesNum";
            ddlStatus.DataSource = DocStatesServices.Instance.GetDocStates();
            ddlStatus.DataBind();
            ddlStatus.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));

            ddlShipTo.AppendDataBoundItems = true;
            ddlShipTo.DataTextField = "Name";
            ddlShipTo.DataValueField = "AdressNum";
            ddlShipTo.DataSource = AdressesServices.Instance.GetAdresses(0);
            ddlShipTo.DataBind();
            ddlShipTo.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));
        }
        #endregion

        #region ---Bind Sales Order---
        public void BindPOOrder()
        {
            int PONum = 0;
            int.TryParse(txtOrderID.Text, out PONum);

            DateTime? SOStartDate = null;
            DateTime _SOStartDate = new DateTime();
            DateTime? SOEndDate = null;
            DateTime _SOEndDate = new DateTime();

            DateTime? SODueStartDate = null;
            DateTime _SODueStartDate = new DateTime();
            DateTime? SODueEndDate = null;
            DateTime _SODueEndDate = new DateTime();
            try
            {
                _SOStartDate = DateTime.ParseExact(txtDocumentStartdate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SOStartDate = _SOStartDate;
            }
            catch
            {
                SOStartDate = null;
            }

            try
            {
                _SOEndDate = DateTime.ParseExact(txtDocumentEnddate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SOEndDate = _SOEndDate;
            }
            catch
            {
                SOEndDate = null;
            }

            try
            {
                _SODueStartDate = DateTime.ParseExact(txtDeliveryDateStartDate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SODueStartDate = _SODueStartDate;
            }
            catch
            {
                SODueStartDate = null;
            }

            try
            {
                _SODueEndDate = DateTime.ParseExact(txtDeliveryEndDate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SODueEndDate = _SODueEndDate;
            }
            catch
            {
                SODueEndDate = null;
            }

            int AddressNum = 0;
            int.TryParse(ddlShipTo.SelectedValue, out AddressNum);

            int DocSatesNum = 0;
            int.TryParse(ddlStatus.SelectedValue, out DocSatesNum);

            int UserNum_SalesRep = 0;
            int.TryParse(ddlSalesRep.SelectedValue, out UserNum_SalesRep);

            FilterPOEntity _FilterPOEntity = new FilterPOEntity();
            _FilterPOEntity.PONum = PONum;
            _FilterPOEntity.AdressNum = AddressNum;
            _FilterPOEntity.DocSatesCode = DocSatesNum;
            _FilterPOEntity.UserNum_SalesRep = UserNum_SalesRep;
            _FilterPOEntity.SORef = txtCustomerRef.Text.Trim();
            _FilterPOEntity.BPCode = txtBillToCode.Text.Trim();
            _FilterPOEntity.SOStartDate = SOStartDate;
            _FilterPOEntity.SOEndDate = SOEndDate;
            _FilterPOEntity.SODueDateStartDate = SODueStartDate;
            _FilterPOEntity.SODueDateEndDate = SODueEndDate;
            _FilterPOEntity.OrderBy = HdnOrderBy.Value;
            _FilterPOEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterPOEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterPOEntity.PageSize = PageSize;
            List<p_FilterPO_Result> _POList = POServices.Instance.FilterPO(_FilterPOEntity);
            if (_POList != null && _POList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = _POList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = _POList;
            GrdCustomers.DataBind();
        }
        #endregion

        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                //if (Offers.Instance.DeleteOffer(int.Parse(e.CommandArgument.ToString())))
                //{
                //    Common.ShowMessage(DivMsg, "Offer successfully deleted", Page.ResolveUrl("~"), true);
                //    BindOffers();
                //}
                //else
                //{
                //    Common.ShowMessage(DivMsg, "Unable to delete Offer", Page.ResolveUrl("~"), true);
                //}
            }
        }
        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    sp_GetOfferList_Result data = (sp_GetOfferList_Result)e.Row.DataItem;
            //    LinkButton LnkDelete = (LinkButton)e.Row.FindControl("LnkDelete");
            //    if (LnkDelete != null)
            //    {
            //        LnkDelete.CommandName = "Delete";
            //        LnkDelete.CommandArgument = data.OfferID.ToString();
            //        LnkDelete.Attributes.Add("onclick", "return ConfirmBoxWithPostBack('Are you sure to delete this Offer?','" + LnkDelete.UniqueID + "');");
            //    }
            //}
        }
        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindPOOrder();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindPOOrder();
        }
        #endregion

        #region--Search--
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindPOOrder();
        }
        #endregion

        #region--Reset--
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtOrderID.Text = "";
            txtDocumentStartdate.Text = "";
            txtDocumentEnddate.Text = "";
            txtDeliveryDateStartDate.Text = "";
            txtDeliveryEndDate.Text = "";
            ddlShipTo.ClearSelection();
            ddlShipTo.Items.FindByValue("0").Selected = true;
            txtCustomerRef.Text = "";
            txtBillToCode.Text = "";
            ddlStatus.ClearSelection();
            ddlStatus.Items.FindByValue("0").Selected = true;
            ddlSalesRep.ClearSelection();
            ddlSalesRep.Items.FindByValue("0").Selected = true;
            BindPOOrder();
        }
        #endregion
    }
}