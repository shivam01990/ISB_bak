﻿using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ItemsServices
    {
        #region--Instance--
        public static ItemsServices Instance = new ItemsServices();
        #endregion

        #region--Insert Item--
        public int InsertItem(Item _item)
        {
            return ItemsProvider.Instance.InsertItem(_item);
        }
        #endregion

        #region--Update Item--
        public void UpdateItem(Item _item)
        {
            ItemsProvider.Instance.UpdateItem(_item);
        }
        #endregion

        #region--Get Item--
        public Item GetItem(int itemNum)
        {
            return ItemsProvider.Instance.GetItem(itemNum).FirstOrDefault();
        }
        #endregion

        #region--Get All Item--
        public List<Item> GetAllItem()
        {
            return ItemsProvider.Instance.GetItem(0);
        }

        #endregion

        #region--FilterItems--
        public List<p_FilterItems_Result> FilterItems(FilterItemEntity _FilterItemEntity)
        {
            return ItemsProvider.Instance.FilterItems(_FilterItemEntity);
        }
        #endregion

    }
}
