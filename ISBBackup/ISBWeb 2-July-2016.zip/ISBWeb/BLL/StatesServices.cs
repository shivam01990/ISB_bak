﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class StatesServices
    {
        #region--Instance--
       public static StatesServices Instance = new StatesServices();
        #endregion

        #region--Get Access--
        public List<State> GetStates(int StateNum,int CountryNum)
        {
            return StatesProvider.Instance.GetStates(StateNum, CountryNum);
        }

        public List<State> GetAllStates()
        {
            return StatesProvider.Instance.GetStates(0,0);
        }
        #endregion
    }
}
