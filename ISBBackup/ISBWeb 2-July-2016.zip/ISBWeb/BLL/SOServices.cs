﻿using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class SOServices
    {
        #region--Instance--
        public static SOServices Instance = new SOServices();
        #endregion

        #region--Save SO--
        public bool SaveSO(p_FilterSO_Result _SO)
        {
            return SOProvider.Instance.SaveSO(_SO);
        }
        #endregion

        #region--Get SO--
        public List<p_FilterSO_Result> FilterSO(FilterSOEntity _FilterSO)
        {
            List<p_FilterSO_Result> rType = new List<p_FilterSO_Result>();
            rType = SOProvider.Instance.FilterSO(_FilterSO);
            return rType;
        }
        #endregion

        #region--Get SO_L--
        public List<SO_L> GetSO_L(int SO_LNum, int SONum)
        {
            List<SO_L> rType = new List<SO_L>();
            rType = SOProvider.Instance.GetSO_L(SO_LNum, SONum);
            return rType;

        }
        #endregion

        #region--Save SO_L--
        public bool SaveSO_L(SO_L _SO_L)
        {
            return SOProvider.Instance.SaveSO_L(_SO_L);
        }
        #endregion

        #region--Delete SO_L--        
      
        public void DeleteSO_L(int SO_LNum)
        {
            SOProvider.Instance.DeleteSO_L(SO_LNum);
        }  
        #endregion

    }
}