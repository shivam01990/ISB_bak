﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UOMItemsServices
    {
        #region--Instance--
        public static UOMItemsServices Instance = new UOMItemsServices();
        #endregion

        #region--Get UOM Item--
        public UOMItem GetUOMItems(int uomItemNum)
        {
            return UOMItemsProvider.Instance.GetUOMItems(uomItemNum).FirstOrDefault();
        }
        #endregion


        #region--Get UOM Item--
        public List<UOMItem> GetAllUOMItems()
        {
            return UOMItemsProvider.Instance.GetUOMItems(0);
        }
        #endregion
    }
}
