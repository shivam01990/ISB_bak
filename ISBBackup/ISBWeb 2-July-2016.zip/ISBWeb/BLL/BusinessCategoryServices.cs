﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class BusinessCategoryServices
    {
        #region--Instance--
        public static BusinessCategoryServices Instance = new BusinessCategoryServices();
        #endregion

        #region--Get All Business Categories--
        public List<BusinessCategory> GetBusinessCategories()
        {
            return BusinessCategoryProvider.Instance.GetBusinessCategories();
        }
        #endregion

    }
}
