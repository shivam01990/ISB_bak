﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class SubCategoryServices
    {
        #region--Instance--
        public static SubCategoryServices Instance = new SubCategoryServices();
        #endregion

        #region--Get Sub Category--
        public SubCategory GetSubCategory(int subCategoryNum)
        {
            return SubCategoryProvider.Instance.GetSubCategory(subCategoryNum).FirstOrDefault();
        }
        #endregion


        #region--Get Sub Category--
        public List<SubCategory> GetAllSubCategory()
        {
            return SubCategoryProvider.Instance.GetSubCategory(0);
        }
        #endregion
    }
}
