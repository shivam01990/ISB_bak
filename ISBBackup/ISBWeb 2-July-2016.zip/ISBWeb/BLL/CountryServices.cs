﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class CountryServices
    {
        #region--Instance--
        public static CountryServices Instance = new CountryServices();
        #endregion

        #region--Get Country--
        public Country GetCountry(int CountryNum)
        {
            return CountryProvider.Instance.GetCountry(CountryNum).FirstOrDefault();
        }
        #endregion


        #region--Get Country--
        public List<Country> GetAllCountry()
        {
            return CountryProvider.Instance.GetCountry(0);
        }
        #endregion
    }
}
