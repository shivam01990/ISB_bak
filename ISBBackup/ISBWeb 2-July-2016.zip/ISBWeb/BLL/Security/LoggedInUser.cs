﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BLL.Security
{
    [Serializable]
    [XmlRootAttribute("UserData")]
    public class LoggedInUser
    {
        [XmlElement("UserNum")]
        public int UserNum = -1;
        [XmlElement("GlobalCustomerNum")]
        public int GlobalCustomerNum = -1;
        [XmlElement("UsersMngRight")]
        public string UsersMngRight = "RW";
        [XmlElement("UserLanguage")]
        public int UserLanguage = -1;        
        [XmlElement("Roles")]
        public string[] Roles = null;
        [XmlElement("Name")]
        public string Name = string.Empty;
        [XmlElement("Email")]
        public string Email = string.Empty;
        [XmlElement("LoginSuccess")]
        public bool LoginSuccess = false;
        [XmlElement("RemainingPasswordAttempt")]
        public short RemainingPasswordAttempt = 0;
        [XmlElement("IsEmailExists")]
        public bool IsEmailExists = false;
        [XmlElement("IsLockOut")]
        public bool IsLockOut = false;
        [XmlElement("IsConfirmed")]
        public bool IsConfirmed = false;

    }
}
