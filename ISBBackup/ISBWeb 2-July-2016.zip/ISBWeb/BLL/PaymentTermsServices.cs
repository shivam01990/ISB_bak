﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class PaymentTermsServices
    {
        #region--Instance--
        public static PaymentTermsServices Instance = new PaymentTermsServices();
        #endregion

        #region--Get All PaymentTerms--
        public List<PaymentTerm> GetPaymentTerms()
        {
            return PaymentTermsProvider.Instance.GetPaymentTerms();
        }
        #endregion

    }
}
