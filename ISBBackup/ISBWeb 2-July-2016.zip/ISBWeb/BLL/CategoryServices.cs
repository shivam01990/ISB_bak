﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class CategoryServices
    {
        #region--Instance--
        public static CategoryServices Instance = new CategoryServices();
        #endregion

        #region--Get Category--
        public Category GetCategory(int categoryNum)
        {
            return CategoryProvider.Instance.GetCategory(categoryNum).FirstOrDefault();
        }
        #endregion


        #region--Get Category--
        public List<Category> GetAllCategory()
        {
            return CategoryProvider.Instance.GetCategory(0);
        }
        #endregion
    }
}
