﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ItemsPackMSRServices
    {
        #region--Instance--
        public static ItemsPackMSRServices Instance = new ItemsPackMSRServices();
        #endregion

        #region--Insert ItemsPackMSR  --
        public string InsertItemsPackMSR(ItemsPackMsr _item)
        {
            return ItemsPackMsrProvider.Instance.InsertItemsPackMSR(_item);
        }
        #endregion

        #region--Update ItemsPackMSR --
        public int UpdateItemsPackMSR(ItemsPackMsr _item)
        {
            return ItemsPackMsrProvider.Instance.UpdateItemsPackMSR(_item);
        }
        #endregion

        #region--Get ItemsPackMSR--
        public ItemsPackMsrModel GetItemsPackMSR(int itemsPackMSRNum)
        {
            ItemsPackMsr itemsPackMsr = ItemsPackMsrProvider.Instance.GetItemsPackMsr(itemsPackMSRNum).FirstOrDefault();
            ItemsPackMsrModel itemsPackMsrModel = ConvertToItemsPackMsrModel(itemsPackMsr);
            return itemsPackMsrModel;
        }
        #endregion


        #region--Delete ItemsPackMSR--
        public bool DeleteItemsPackMSR(int itemsPackMSRNum)
        {
            bool isDeleted = ItemsPackMsrProvider.Instance.DeleteItemsPackMSR(itemsPackMSRNum);            
            return isDeleted;
        }
        #endregion

        #region--Get Item--
        public List<ItemsPackMsr> GetAllItemsPackMSR()
        {
            return ItemsPackMsrProvider.Instance.GetItemsPackMsr(0);
        }

        #endregion

        #region--Get All Item--
        public List<ItemsPackMsrModel> GetItemsPackMsrForItem(int itemNum)
        {
            List<ItemsPackMsr> listItemsPackMsr = ItemsPackMsrProvider.Instance.GetItemsPackMsrForItem(itemNum);

            List<ItemsPackMsrModel> listItemsPackMsrModel = ConvertToItemsPackMsrModelList(listItemsPackMsr);

            return listItemsPackMsrModel;
        }

        #endregion

        public List<ItemsPackMsrModel> ConvertToItemsPackMsrModelList(List<ItemsPackMsr> listItemsPackMsr)
        {
            List<ItemsPackMsrModel> listItemsPackMsrModel = new List<ItemsPackMsrModel>();
            foreach (ItemsPackMsr itemsPackMsr in listItemsPackMsr)
            {
                listItemsPackMsrModel.Add(ConvertToItemsPackMsrModel(itemsPackMsr));
            }

            return listItemsPackMsrModel;
        }

        public ItemsPackMsrModel ConvertToItemsPackMsrModel(ItemsPackMsr itemsPackMsr)
        {
            ItemsPackMsrModel itemsPackMsrModel = new ItemsPackMsrModel();
            itemsPackMsrModel.Active = Helper.GetBoolean(itemsPackMsr.Active);
            itemsPackMsrModel.Code = itemsPackMsr.Code;
            itemsPackMsrModel.Description = itemsPackMsr.Description;
            itemsPackMsrModel.GlobalCustomerNum = itemsPackMsr.GlobalCustomerNum;
            itemsPackMsrModel.IsBaseUOM = Helper.GetBoolean(itemsPackMsr.IsBaseUOM);
            itemsPackMsrModel.IsPurchaseDefault = Helper.GetBoolean(itemsPackMsr.IsPurchaseDefault);
            itemsPackMsrModel.IsSalesDefault = Helper.GetBoolean(itemsPackMsr.IsSalesDefault);
            itemsPackMsrModel.ItemNum = itemsPackMsr.ItemNum;
            itemsPackMsrModel.ItemsPackMsrNum = itemsPackMsr.ItemsPackMsrNum;
            itemsPackMsrModel.UnitPerPack = itemsPackMsr.UnitPerPack;

            return itemsPackMsrModel;
        }


    }
    public class ItemsPackMsrModel
    {
        public ItemsPackMsrModel()
        {

        }
        public int ItemsPackMsrNum { get; set; }
        public Nullable<int> ItemNum { get; set; }
        public Nullable<int> GlobalCustomerNum { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public Nullable<int> UnitPerPack { get; set; }
        public Nullable<bool> IsPurchaseDefault { get; set; }
        public Nullable<bool> IsSalesDefault { get; set; }
        public Nullable<bool> IsBaseUOM { get; set; }
        public Nullable<bool> Active { get; set; }

    }


}

