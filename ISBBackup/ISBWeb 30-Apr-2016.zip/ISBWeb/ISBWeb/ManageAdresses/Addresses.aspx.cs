﻿using BLL;
using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.ManageAdresses
{
    public partial class Addresses : System.Web.UI.Page
    {
        #region ---Declaration---
        protected int PageSize = 25;
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }      
        #endregion

        #region--Page Load--
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //SesStrUsersMngRight = "RW";
                //SesGlobalCustomerNum = 1;
                //SesUserID = 1;
                //SesIntUserLanguage = 1;
                BindCountry();
                BindStates();
                BindAddress();
                CheckPermission();
            }
        }
        #endregion
        #region--Check Permission--
        public void CheckPermission()
        {
            if (Helper.SesStrUsersMngRight == "R")
            {
                btnSave.Enabled = false;
                lnkDelete.Enabled = false;
                btnClose.Enabled = false;
                GrdCustomers.Enabled = false;
                lnkAddNew.Enabled = false;

            }
        }
        #endregion
        #region--Bind DropDowns--
        public void BindCountry()
        {

            ddlCountry.AppendDataBoundItems = true;
            ddlCountry.DataSource = CountryServices.Instance.GetAllCountry();
            ddlCountry.DataTextField = "Name";
            ddlCountry.DataValueField = "CountryNum";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "--Please Select--" }));
        }
        #endregion

        #region--Bind States--
        public void BindStates()
        {
            ddlState.ClearSelection();
            ddlState.Items.Clear();
            int CountryNum = 0;
            int.TryParse(ddlCountry.SelectedValue, out CountryNum);
            if (CountryNum > 0)
            {
                ddlState.AppendDataBoundItems = true;
                ddlState.DataSource = StatesServices.Instance.GetStates(0, CountryNum);
                ddlState.DataTextField = "Name";
                ddlState.DataValueField = "StateNum";
                ddlState.DataBind();
            }
            ddlState.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "--Please Select--" }));
        }
        #endregion

        #region ---Bind Addresses---
        public void BindAddress()
        {
            FilterAdressesEntity _FilterAdressesEntity = new FilterAdressesEntity();
            _FilterAdressesEntity.AdressNum = 0;
            _FilterAdressesEntity.OrderBy = HdnOrderBy.Value;
            _FilterAdressesEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterAdressesEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterAdressesEntity.PageSize = PageSize;
            List<p_FilterAdresses_Result> _AdressList = AdressesServices.Instance.FilterAdresses(_FilterAdressesEntity);
            if (_AdressList != null && _AdressList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = _AdressList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = _AdressList;
            GrdCustomers.DataBind();
        }
        #endregion

        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SelectAddress")
            {
                int AdressNum = int.Parse(e.CommandArgument.ToString());
                FilterAdressesEntity _FilterAdressesEntity = new FilterAdressesEntity();
                _FilterAdressesEntity.AdressNum = AdressNum;
                p_FilterAdresses_Result _Address = AdressesServices.Instance.FilterAdresses(_FilterAdressesEntity).FirstOrDefault();
                if (_Address != null)
                {
                    lnkDelete.Enabled = true;
                    lnkDelete.Attributes.Add("onclick", "return confirm('Are you sure to delete this BP ADDRESS/Package?')");
                    hdnAdressNum.Value = _Address.AdressNum.ToString();
                    txtName.Text = _Address.Name;
                    txtAddress1.Text = _Address.Adress1;
                    txtAddress2.Text = _Address.Adress2;
                    txtCity.Text = _Address.City;
                    if (ddlCountry.Items.FindByValue(_Address.CountryNum.ToString()) != null)
                    {
                        ddlCountry.ClearSelection();
                        ddlCountry.Items.FindByValue(_Address.CountryNum.ToString()).Selected = true;
                        BindStates();
                        if (ddlState.Items.FindByValue(_Address.StateNum.ToString()) != null)
                        {
                            ddlState.ClearSelection();
                            ddlState.Items.FindByValue(_Address.StateNum.ToString()).Selected = true;
                        }
                    }
                    txtZipCode.Text = _Address.ZipCode;
                    if (ddlAddressType.Items.FindByValue(_Address.AdressType.ToString()) != null)
                    {
                        ddlAddressType.ClearSelection();
                        ddlAddressType.Items.FindByValue(_Address.AdressType.ToString()).Selected = true;
                    }
                    chkIsActive.Checked = _Address.Active == null ? false : (bool)_Address.Active;

                }
            }
        }
        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    sp_GetOfferList_Result data = (sp_GetOfferList_Result)e.Row.DataItem;
            //    LinkButton LnkDelete = (LinkButton)e.Row.FindControl("LnkDelete");
            //    if (LnkDelete != null)
            //    {
            //        LnkDelete.CommandName = "Delete";
            //        LnkDelete.CommandArgument = data.OfferID.ToString();
            //        LnkDelete.Attributes.Add("onclick", "return ConfirmBoxWithPostBack('Are you sure to delete this Offer?','" + LnkDelete.UniqueID + "');");
            //    }
            //}
        }
        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindAddress();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindAddress();
        }
        #endregion

        #region--Country Index Change--
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindStates();
        }
        #endregion

        #region--Save--
        protected void btnSave_Click(object sender, EventArgs e)
        {
            p_FilterAdresses_Result _Address = new p_FilterAdresses_Result();
            int AddressNum = 0;
            int.TryParse(hdnAdressNum.Value, out AddressNum);
            if (AddressNum > 0)
            {
                FilterAdressesEntity _FilterAdressesEntity = new FilterAdressesEntity();
                _FilterAdressesEntity.AdressNum = AddressNum;
                _Address = AdressesServices.Instance.FilterAdresses(_FilterAdressesEntity).FirstOrDefault();
                if (_Address == null)
                {
                    Helper.ShowMessage(msgDiv, "Address not exit.", false);
                    return;
                }
            }

            int CountryNum = 0;
            int.TryParse(ddlCountry.SelectedValue, out CountryNum);

            int StateNum = 0;
            int.TryParse(ddlState.SelectedValue, out StateNum);

            _Address.Name = txtName.Text;
            _Address.Adress1 = txtAddress1.Text;
            _Address.Adress2 = txtAddress2.Text;
            _Address.City = txtCity.Text;
            _Address.CountryNum = CountryNum;
            _Address.StateNum = StateNum;
            _Address.ZipCode = txtZipCode.Text;
            _Address.AdressType = ddlAddressType.SelectedValue;
            _Address.Active = chkIsActive.Checked;

            bool flag = AdressesServices.Instance.SaveAdresses(_Address);
            if (flag)
            {
                Helper.ShowMessage(msgDiv, "Address is successfully Saved.", true);
                Initialize();
                BindAddress();
            }
            else
            {
                Helper.ShowMessage(msgDiv, "Unable to Address.", false);
            }
        }
        #endregion

        #region--Initialize--
        public void Initialize()
        {
            lnkDelete.Attributes.Remove("onclick");
            lnkDelete.Enabled = false;
            hdnAdressNum.Value = "0";
            txtName.Text = "";
            txtAddress1.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            ddlCountry.ClearSelection();
            ddlCountry.Items.FindByValue("0").Selected = true;
            ddlState.ClearSelection();
            ddlState.Items.FindByValue("0").Selected = true;
            txtZipCode.Text = "";
            ddlAddressType.ClearSelection();
            ddlAddressType.SelectedIndex = 0;
            chkIsActive.Checked = false;
        }
        #endregion

        #region--Add New--
        protected void lnkAddNew_Click(object sender, EventArgs e)
        {
            Initialize();
        }
        #endregion

        #region--Delete--
        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            int AdressNum = 0;
            int.TryParse(hdnAdressNum.Value, out AdressNum);
            if (AdressNum > 0)
            {
              bool flag=  AdressesServices.Instance.DeleteAddress(AdressNum);
                if(flag)
                Helper.ShowMessage(msgDiv, "Address is successfully Deleted.", true); 
                else
                    Helper.ShowMessage(msgDiv, " Address is associated with other records.", false); 

                Initialize();
                BindAddress();
            }
            else
            {
                Helper.ShowMessage(msgDiv, "Please select Address.", false);   
            }

        }
        #endregion

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Initialize();
        }

    }
}