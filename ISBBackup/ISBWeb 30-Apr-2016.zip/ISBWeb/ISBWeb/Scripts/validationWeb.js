﻿$(document).ready(function () {
    
    $("#form1").validate({
        ignore: ".ignore",
        rules: {
            ctl00$ContentPlaceHolder1$txtName: {
                required: true,
                minlength: 3,
                maxlength : 30
            },

            ctl00$ContentPlaceHolder1$txtCode: {
                required: true,
                minlength: 4,
                maxlength : 10
            },
            ctl00$ContentPlaceHolder1$txtBalance: {
                required:true,
                number: true,
                min: 0,
                max : 999999,
            },
            ctl00$ContentPlaceHolder1$txtTotalCredit: {
                required: true,
                number: true,
                min : 0,
                max : 999999,
            },

            ctl00$ContentPlaceHolder1$txtZipCode: {
                number:true,
            },

            ctl00$ContentPlaceHolder1$txtEmail: {
                email: true
            },

            ctl00$ContentPlaceHolder1$txtWebsite: {
                url: true
            },
        },
        messages: {

            ctl00$ContentPlaceHolder1$txtName: {
                required: 'Name is required',
                minlength: 'Minimum Length is 3',
                maxlength: 'Maximum Length is 30'
            },

            ctl00$ContentPlaceHolder1$txtCode: {
                required: 'Code is required',
                minlength: 'Minimum length is 3',
                maxlength: 'Maximum length is 10'
            },
            ctl00$ContentPlaceHolder1$txtBalance: {
                required: "Value should be between 0 and 99999",
                number: 'Enter a valid number',
                min: "Value should be between 0 and 99999",
                max: "Value should be between 0 and 99999",
            },
            ctl00$ContentPlaceHolder1$txtTotalCredit: {
                required: "Value should be between 0 and 99999",
                number: 'Enter a valid number',
                min: "Value should be between 0 and 99999",
                max: "Value should be between 0 and 99999",
            },

            ctl00$ContentPlaceHolder1$txtZipCode: {
                number: 'Enter a valid number',
            },

            ctl00$ContentPlaceHolder1$txtEmail: {
                email: 'Enter a valid email'
            },

            ctl00$ContentPlaceHolder1$txtWebsite: {
                url: 'Enter a valid url'
            },
        }
    });
});
