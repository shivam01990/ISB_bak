﻿using BLL;
using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.Controls
{
    public partial class ctlPOSearch : System.Web.UI.UserControl
    {
        #region ---Declaration---
        protected int PageSize = 25;
        private const int _firstEditCellIndex = 2;
        private List<int> _lsteditCell = new List<int>() { 3, 4, 5, 6, 7 };
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }
        #endregion

        #region--Page Load--
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["msg"] != null)
                {
                    if (Request.QueryString["msg"] == "1")
                    {
                        Helper.ShowMessage(DivMsg, "Sales Order Successfully Saved.", true);
                    }
                }
                BindDropdowns();
                BindPOOrder();
            }

            if (this.GrdCustomers.SelectedIndex > -1)
            {
                // Call UpdateRow on every postback
                this.GrdCustomers.UpdateRow(this.GrdCustomers.SelectedIndex, false);
            }
        }
        #endregion

        #region--Bind DropDown--
        public void BindDropdowns()
        {
            FilterUserEntity _FilterUserEntity = new FilterUserEntity();
            _FilterUserEntity.Active = true;
            _FilterUserEntity.UserNum = 0;
            _FilterUserEntity.IsManager = null;
            List<p_FilterUsers_Result> _UserList = UserServices.Instance.FilterUsers(_FilterUserEntity);
            var UserQuery = _UserList.Select(p => new { UserId = p.UserNum, DisplayText = p.FirstName + " " + p.LastName });
            ddlSalesRep.AppendDataBoundItems = true;
            ddlSalesRep.DataTextField = "DisplayText";
            ddlSalesRep.DataValueField = "UserId";
            ddlSalesRep.DataSource = UserQuery;
            ddlSalesRep.DataBind();
            ddlSalesRep.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));

            ddlStatus.AppendDataBoundItems = true;
            ddlStatus.DataTextField = "Name";
            ddlStatus.DataValueField = "DocSatesNum";
            ddlStatus.DataSource = DocStatesServices.Instance.GetDocStates();
            ddlStatus.DataBind();
            ddlStatus.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));

            ddlShipTo.AppendDataBoundItems = true;
            ddlShipTo.DataTextField = "Name";
            ddlShipTo.DataValueField = "AdressNum";
            ddlShipTo.DataSource = AdressesServices.Instance.GetAdresses(0);
            ddlShipTo.DataBind();
            ddlShipTo.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));
        }
        #endregion

        #region ---Bind Sales Order---
        public void BindPOOrder()
        {
            int PONum = 0;
            int.TryParse(txtOrderID.Text, out PONum);

            DateTime? SOStartDate = null;
            DateTime _SOStartDate = new DateTime();
            DateTime? SOEndDate = null;
            DateTime _SOEndDate = new DateTime();

            DateTime? SODueStartDate = null;
            DateTime _SODueStartDate = new DateTime();
            DateTime? SODueEndDate = null;
            DateTime _SODueEndDate = new DateTime();
            try
            {
                _SOStartDate = DateTime.ParseExact(txtDocumentStartdate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SOStartDate = _SOStartDate;
            }
            catch
            {
                SOStartDate = null;
            }

            try
            {
                _SOEndDate = DateTime.ParseExact(txtDocumentEnddate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SOEndDate = _SOEndDate;
            }
            catch
            {
                SOEndDate = null;
            }

            try
            {
                _SODueStartDate = DateTime.ParseExact(txtDeliveryDateStartDate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SODueStartDate = _SODueStartDate;
            }
            catch
            {
                SODueStartDate = null;
            }

            try
            {
                _SODueEndDate = DateTime.ParseExact(txtDeliveryEndDate.Text, "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                SODueEndDate = _SODueEndDate;
            }
            catch
            {
                SODueEndDate = null;
            }


            int AddressNum = 0;
            int.TryParse(ddlShipTo.SelectedValue, out AddressNum);

            int DocSatesNum = 0;
            int.TryParse(ddlStatus.SelectedValue, out DocSatesNum);

            int UserNum_SalesRep = 0;
            int.TryParse(ddlSalesRep.SelectedValue, out UserNum_SalesRep);

            FilterPOEntity _FilterPOEntity = new FilterPOEntity();
            _FilterPOEntity.PONum = PONum;
            _FilterPOEntity.AdressNum = AddressNum;
            _FilterPOEntity.DocSatesCode = DocSatesNum;
            _FilterPOEntity.UserNum_SalesRep = UserNum_SalesRep;
            _FilterPOEntity.SORef = txtCustomerRef.Text.Trim();
            _FilterPOEntity.BPCode = txtBillToCode.Text.Trim();
            _FilterPOEntity.SOStartDate = SOStartDate;
            _FilterPOEntity.SOEndDate = SOEndDate;
            _FilterPOEntity.SODueDateStartDate = SODueStartDate;
            _FilterPOEntity.SODueDateEndDate = SODueEndDate;
            _FilterPOEntity.OrderBy = HdnOrderBy.Value;
            _FilterPOEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterPOEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterPOEntity.PageSize = PageSize;
            List<p_FilterPO_Result> _POList = POServices.Instance.FilterPO(_FilterPOEntity);
            if (_POList != null && _POList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = _POList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = _POList;
            GrdCustomers.DataBind();
        }
        #endregion

        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridView _gridView = (GridView)sender;

            switch (e.CommandName)
            {
                case ("SingleClick"):
                    // Get the row index
                    int _rowIndex = int.Parse(e.CommandArgument.ToString());
                    // Parse the event argument (added in RowDataBound) to get the selected column index
                    int _columnIndex = int.Parse(Request.Form["__EVENTARGUMENT"]);
                    // Set the Gridview selected index
                    _gridView.SelectedIndex = _rowIndex;
                    // Bind the Gridview
                    BindPOOrder();

                    // Write out a history if the event
                    //this.Message.Text += "Single clicked GridView row at index " + _rowIndex.ToString()
                    //    + " on column index " + _columnIndex + "<br />";

                    // Get the display control for the selected cell and make it invisible
                    Control _displayControl = _gridView.Rows[_rowIndex].Cells[_columnIndex].Controls[0];
                    _displayControl.Visible = false;
                    // Get the edit control for the selected cell and make it visible
                    Control _editControl = _gridView.Rows[_rowIndex].Cells[_columnIndex].Controls[1];
                    _editControl.Visible = true;
                    // Clear the attributes from the selected cell to remove the click event
                    _gridView.Rows[_rowIndex].Cells[_columnIndex].Attributes.Clear();

                    // Set focus on the selected edit control
                    ScriptManager.RegisterStartupScript(this, GetType(), "SetFocus",
                        "document.getElementById('" + _editControl.ClientID + "').focus();", true);
                    // If the edit control is a dropdownlist set the
                    // SelectedValue to the value of the display control
                    if (_editControl is DropDownList && _displayControl is Label)
                    {
                        ((DropDownList)_editControl).SelectedValue = ((Label)_displayControl).Text;
                    }
                    // If the edit control is a textbox then select the text
                    if (_editControl is TextBox)
                    {
                        ((TextBox)_editControl).Attributes.Add("onfocus", "this.select()");
                    }

                    break;
            }
        }

        #region Render Override

        // Register the dynamically created client scripts
        protected override void Render(HtmlTextWriter writer)
        {
            // The client events for GridView1 were created in GridView1_RowDataBound
            foreach (GridViewRow r in GrdCustomers.Rows)
            {
                if (r.RowType == DataControlRowType.DataRow)
                {
                    for (int columnIndex = _firstEditCellIndex; columnIndex < r.Cells.Count; columnIndex++)
                    {
                        if (_lsteditCell.Contains(columnIndex))
                        {
                            Page.ClientScript.RegisterForEventValidation(r.UniqueID + "$ctl00", columnIndex.ToString());
                        }
                    }
                }
            }

            base.Render(writer);
        }

        #endregion

        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                FilterUserEntity _FilterUserEntity = new FilterUserEntity();
                _FilterUserEntity.Active = true;
                _FilterUserEntity.UserNum = 0;
                _FilterUserEntity.IsManager = null;
                List<p_FilterUsers_Result> _UserList = UserServices.Instance.FilterUsers(_FilterUserEntity);
                var UserQuery = _UserList.Select(p => new { UserId = p.UserNum, DisplayText = p.FirstName + " " + p.LastName });

                DropDownList ddlgrdSalesRep = (e.Row.FindControl("ddlgrdSalesRep") as DropDownList);
                DropDownList ddlgrdShipTo = (e.Row.FindControl("ddlgrdShipTo") as DropDownList);
                HiddenField hdnAdressNum = (e.Row.FindControl("hdnAdressNum") as HiddenField);
                HiddenField hdnUserNum_SalesRep = (e.Row.FindControl("hdnUserNum_SalesRep") as HiddenField);


                ddlgrdSalesRep.AppendDataBoundItems = true;
                ddlgrdSalesRep.DataTextField = "DisplayText";
                ddlgrdSalesRep.DataValueField = "UserId";
                ddlgrdSalesRep.DataSource = UserQuery;
                ddlgrdSalesRep.DataBind();

                if (ddlgrdSalesRep.Items.FindByValue(hdnUserNum_SalesRep.Value) != null)
                {
                    ddlgrdSalesRep.ClearSelection();
                    ddlgrdSalesRep.Items.FindByValue(hdnUserNum_SalesRep.Value).Selected = true;
                }


                ddlgrdShipTo.AppendDataBoundItems = true;
                ddlgrdShipTo.DataTextField = "Name";
                ddlgrdShipTo.DataValueField = "AdressNum";
                ddlgrdShipTo.DataSource = AdressesServices.Instance.GetAdresses(0);
                ddlgrdShipTo.DataBind();

                if (ddlgrdShipTo.Items.FindByValue(hdnAdressNum.Value) != null)
                {
                    ddlgrdShipTo.ClearSelection();
                    ddlgrdShipTo.Items.FindByValue(hdnAdressNum.Value).Selected = true;
                }


                // Get the LinkButton control in the first cell
                LinkButton _singleClickButton = (LinkButton)e.Row.Cells[0].Controls[0];
                // Get the javascript which is assigned to this LinkButton
                string _jsSingle = Page.ClientScript.GetPostBackClientHyperlink(_singleClickButton, "");

                // If the page contains validator controls then call 
                // Page_ClientValidate before allowing a cell to be edited
                _jsSingle = _jsSingle.Insert(11, "");

                // Add events to each editable cell
                for (int columnIndex = _firstEditCellIndex; columnIndex < e.Row.Cells.Count; columnIndex++)
                {
                    if (_lsteditCell.Contains(columnIndex))
                    {
                        // Add the column index as the event argument parameter
                        string js = _jsSingle.Insert(_jsSingle.Length - 2, columnIndex.ToString());
                        // Add this javascript to the onclick Attribute of the cell
                        e.Row.Cells[columnIndex].Attributes["onclick"] = js;
                        // Add a cursor style to the cells
                        e.Row.Cells[columnIndex].Attributes["style"] += "cursor:pointer;cursor:hand;";
                    }
                }
            }
        }

        protected void GrdCustomers_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridView _gridView = (GridView)sender;

            if (e.RowIndex > -1)
            {
                // Loop though the columns to find a cell in edit mode
                for (int i = _firstEditCellIndex; i < _gridView.Columns.Count; i++)
                {
                    if (_lsteditCell.Contains(i))
                    {
                        // Get the editing control for the cell
                        Control _editControl = _gridView.Rows[e.RowIndex].Cells[i].Controls[1];
                        if (_editControl.Visible)
                        {
                            int _dataTableColumnIndex = i - 1;

                            try
                            {
                                // Get the id of the row
                                Label idLabel = (Label)_gridView.Rows[e.RowIndex].FindControl("IdLabel");
                                int PONum = int.Parse(idLabel.Text);
                                FilterPOEntity _FilterPOEntity = new FilterPOEntity();
                                _FilterPOEntity.PONum = PONum;
                                p_FilterPO_Result _PO = POServices.Instance.FilterPO(_FilterPOEntity).FirstOrDefault();

                                if (_PO != null)
                                {
                                    if (i == 3)
                                    {
                                        int salesrep = 0;
                                        if (_editControl is DropDownList)
                                        {
                                            int.TryParse(((DropDownList)_editControl).SelectedValue, out salesrep);
                                        }
                                        _PO.UserNum_SalesRep = salesrep;
                                        POServices.Instance.SavePO(_PO);
                                    }
                                    if (i == 4)
                                    {
                                        string customerref = "";
                                        if (_editControl is TextBox)
                                        {
                                            customerref = ((TextBox)_editControl).Text;

                                        }
                                        _PO.SORef = customerref;
                                         POServices.Instance.SavePO(_PO);

                                        //else if (_editControl is CheckBox)
                                        //{
                                        //    updatedvalue = ((CheckBox)_editControl).Checked;
                                        //}
                                    }

                                    if (i == 5)
                                    {
                                        int shipto = 0;
                                        if (_editControl is DropDownList)
                                        {
                                            int.TryParse(((DropDownList)_editControl).SelectedValue, out shipto);
                                        }
                                        _PO.AdressNum = shipto;
                                        POServices.Instance.SavePO(_PO);
                                    }

                                    if (i == 6)
                                    {
                                        string documentdate = "";
                                        if (_editControl is TextBox)
                                        {
                                            documentdate = ((TextBox)_editControl).Text;

                                        }
                                        try
                                        {
                                            _PO.SODate = DateTime.ParseExact(documentdate.Trim(), "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                                            POServices.Instance.SavePO(_PO);
                                        }
                                        catch
                                        {

                                        }

                                    }
                                    if (i == 7)
                                    {
                                        string duedate = "";
                                        if (_editControl is TextBox)
                                        {
                                            duedate = ((TextBox)_editControl).Text;

                                        }
                                        try
                                        {
                                            _PO.SODueDate = DateTime.ParseExact(duedate.Trim(), "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                                            POServices.Instance.SavePO(_PO);
                                        }
                                        catch
                                        { }
                                    }
                                }
                                _gridView.SelectedIndex = -1;

                                // Repopulate the GridView
                                BindPOOrder();
                            }
                            catch (ArgumentException)
                            {
                                BindPOOrder();
                            }
                        }
                    }
                }
            }
        }


        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindPOOrder();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindPOOrder();
        }
        #endregion

        #region--Search--
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindPOOrder();
        }
        #endregion

        #region--Reset--
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtOrderID.Text = "";
            txtDocumentStartdate.Text = "";
            txtDocumentEnddate.Text = "";
            txtDeliveryDateStartDate.Text = "";
            txtDeliveryEndDate.Text = "";
            ddlShipTo.ClearSelection();
            ddlShipTo.Items.FindByValue("0").Selected = true;
            txtCustomerRef.Text = "";
            txtBillToCode.Text = "";
            ddlStatus.ClearSelection();
            ddlStatus.Items.FindByValue("0").Selected = true;
            ddlSalesRep.ClearSelection();
            ddlSalesRep.Items.FindByValue("0").Selected = true;
            BindPOOrder();
        }
        #endregion
    }
}