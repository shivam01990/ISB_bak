﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class FilterUserEntity
    {
        #region--Private Properties--
        private int _UserNum;
        private string _UserName="";
        private int _GlobalCustomerNum;
        private string _Name="";
        private string _City="";
        private string _State="";
        private bool? _Active;
        private bool? _IsManager;
        private int _GenderNum;
        private string _OrderBy = "UserNum";
        private string _OrderDir = "DESC";
        private int _PageNumber = 0;
        private int _PageSize = 0;
        #endregion

        #region--Public Properties--
        public int UserNum
        {
            get
            {
                return _UserNum;
            }
            set
            {
                _UserNum = value;
            }
        }
        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }
        public int GlobalCustomerNum
        {
            get
            {
                return _GlobalCustomerNum;
            }
            set
            {
                _GlobalCustomerNum = value;
            }
        }
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }
        public string City
        {
            get
            {
                return _City;
            }
            set
            {
                _City = value;
            }
        }
        public string State
        {
            get
            {
                return _State;
            }
            set
            {
                _State = value;
            }
        }
        public bool? Active
        {
            get
            {
                return _Active;
            }
            set
            {
                _Active = value;
            }
        }

        public bool? IsManager
        {
            get
            {
                return _IsManager;
            }
            set
            {
                _IsManager = value;
            }
        }
        public int GenderNum
        {
            get
            {
                return _GenderNum;
            }
            set
            {
                _GenderNum = value;
            }
        }
        public string OrderBy
        {
            get
            {
                return _OrderBy;
            }
            set
            {
                _OrderBy = value;
            }
        }
        public string OrderDir
        {
            get
            {
                return _OrderDir;
            }
            set
            {
                _OrderDir = value;
            }
        }
        public int PageNumber
        {
            get
            {
                return _PageNumber;
            }
            set
            {
                _PageNumber = value;
            }
        }
        public int PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }
        #endregion
    }
}
