﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class FilterItemEntity
    {
        #region--Private Properties--
        private int _ItemNum;
        private int _GlobalCustomerNum;
        private string _Code;
        private string _EAN13;
        private int _ItemTypeNum;
        private int _CategoryNum;
        private int _SubCategoryNum;
        private int _DefaultSupplierBPNum;
        private int _CountryOfOriginNum;
        private string _OrderBy = "ItemNum";
        private string _OrderDir="DESC";
        private int _PageNumber=0;
        private int _PageSize=0;
        #endregion

        #region--Public Properties--
        public int ItemNum
        {
            get
            {
                return _ItemNum;
            }
            set
            {
                _ItemNum = value;
            }
        }
        public int GlobalCustomerNum
        {
            get
            {
                return _GlobalCustomerNum;
            }
            set
            {
                _GlobalCustomerNum = value;
            }
        }
        public string Code
        {
            get
            {
                return _Code;
            }
            set
            {
                _Code = value;
            }
        }
        public string EAN13
        {
            get
            {
                return _EAN13;
            }
            set
            {
                _EAN13 = value;
            }
        }
        public int ItemTypeNum
        {
            get
            {
                return _ItemTypeNum;
            }

            set
            {
                _ItemTypeNum = value;
            }
        }
        public int CategoryNum
        {
            get
            {
                return _CategoryNum;
            }
            set
            {
                _CategoryNum = value;
            }
        }
        public int SubCategoryNum
        {
            get
            {
                return _SubCategoryNum;
            }
            set
            {
                _SubCategoryNum = value;
            }
        }
        public int DefaultSupplierBPNum
        {
            get
            {
                return _DefaultSupplierBPNum;
            }
            set
            {
                _DefaultSupplierBPNum = value;
            }
        }
        public int CountryOfOriginNum
        {
            get
            {
                return _CountryOfOriginNum;
            }
            set
            {
                _CountryOfOriginNum = value;
            }
        }
        public string OrderBy
        {
            get
            {
                return _OrderBy;
            }
            set
            {
                _OrderBy = value;
            }
        }
        public string OrderDir
        {
            get
            {
                return _OrderDir;
            }
            set
            {
                _OrderDir = value;
            }
        }

        public int PageNumber
        {
            get
            {
                return _PageNumber;
            }
            set
            {
                _PageNumber = value;
            }
        }

        public int PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }        
        #endregion

    }
}
