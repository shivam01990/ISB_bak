﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class FilterBPEntity
    {

        #region--Private Properties--
        private int _BPNum = 0;
        private int _GlobalCustomerNum = 0;
        private string _Name="";
        private string _Code="";
        private string _City="";
        private string _State="";
        private string _ZipCode="";
        private string _Email="";
        private bool? _Active;
        private string _OrderBy = "BPNum";
        private string _OrderDir = "ASC";
        private int _PageNumber = 0;
        private int _PageSize = 0;
        #endregion

        #region--Public Properties--
        public int BPNum
        {
            get
            {
                return _BPNum;
            }
            set
            {
                _BPNum = value;
            }
        }

        public int GlobalCustomerNum
        {
            get
            {
                return _GlobalCustomerNum;
            }
            set
            {
                _GlobalCustomerNum = value;
            }
        }
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }
        public string Code
        {
            get
            {
                return _Code;
            }
            set
            {
                _Code = value;
            }
        }
        public string City
        {
            get
            {
                return _City;
            }
            set
            {
                _City = value;
            }
        }
        public string State
        {
            get
            {
                return _State;
            }
            set
            {
                _State = value;
            }
        }
        public string ZipCode
        {
            get
            {
                return _ZipCode;
            }
            set
            {
                _ZipCode = value;
            }
        }
        public string Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }
        public bool? Active
        {
            get
            {
                return _Active;
            }
            set
            {
                _Active = value;
            }
        }
        public string OrderBy
        {
            get
            {
                return _OrderBy;
            }
            set
            {
                _OrderBy = value;
            }
        }
        public string OrderDir
        {
            get
            {
                return _OrderDir;
            }
            set
            {
                _OrderDir = value;
            }
        }

        public int PageNumber
        {
            get
            {
                return _PageNumber;
            }
            set
            {
                _PageNumber = value;
            }
        }

        public int PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }
        #endregion

    }
}
