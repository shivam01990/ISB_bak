﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class EndUserTextProvider
    {

        #region--Instance--
        public static EndUserTextProvider Instance = new EndUserTextProvider();
        #endregion

        //********************************************************* 
        //Purpose:      Load the end user text(messages) from the database. 
        //Inputs:       intEndUserTextNum :  the value of the message number.    
        //              IntUserLanguage : User Language of the current user
        //Returns:      it will return the text value to show as a message to the user.
        //*********************************************************
        public string LoadEndUserText(int intEndUserTextNum, int IntUserLanguage)
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var listEnduserText = dbcontext.EndUserTexts.Where(x => x.UserLanguageNum == IntUserLanguage && x.EndUserTextNum == intEndUserTextNum);

                    if (listEnduserText != null)
                    {
                        return listEnduserText.FirstOrDefault().TextMessage;
                    }
                }

                return string.Empty;

            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
