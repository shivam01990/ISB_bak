﻿using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class SOProvider
    {
        #region--Instance--
        public static SOProvider Instance = new SOProvider();
        #endregion

        #region--Save SO--
        public bool SaveSO(p_FilterSO_Result _SO)
        {
            bool rType = false;
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    int SONum = (int)db.p_SaveSO(_SO.SONum, _SO.GlobalCustomerNum, _SO.BPNum, _SO.AdressNum, _SO.SODate, _SO.SODueDate, _SO.LanguageNum, _SO.DocSatesCode, _SO.SORef, _SO.InternNote, _SO.VisibleNote
                         , _SO.SOTotal, _SO.SOSubTotal, _SO.SOTaxTotal, _SO.SODiscountTotal, _SO.CreatedBy, _SO.UserNum, _SO.UserNum_SalesRep).FirstOrDefault();
                    if (SONum > 0)
                    {
                        rType = true;
                        _SO.SONum = SONum;
                    }
                }
                catch { rType = false; }
            }
            return rType;
        }
        #endregion

        #region--Get SO--
        public List<p_FilterSO_Result> FilterSO(FilterSOEntity _FilterSO)
        {
            List<p_FilterSO_Result> rType = new List<p_FilterSO_Result>();
            using (DBEntities db = new DBEntities())
            {
                rType = db.p_FilterSO(_FilterSO.SONum, _FilterSO.GlobalCustomerNum, _FilterSO.UserNum_SalesRep,_FilterSO.AdressNum,_FilterSO.DocSatesCode,_FilterSO.BPCode, _FilterSO.SORef, _FilterSO.SOStartDate, _FilterSO.SOEndDate,_FilterSO.SODueDateStartDate,_FilterSO.SODueDateEndDate, _FilterSO.OrderBy, _FilterSO.OrderDir, _FilterSO.PageNumber, _FilterSO.PageSize).ToList();
            }
            return rType;
        }
        #endregion

        #region--Get SO_L--
        public List<SO_L> GetSO_L(int SO_LNum, int SONum)
        {
            List<SO_L> rType = new List<SO_L>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from s in db.SO_L
                         where ((s.SO_LNum == SO_LNum || SO_LNum == 0)
                             && (SONum == 0 || s.SONum == SONum))
                         select s).ToList();
            }
            return rType;

        }
        #endregion

        #region--Save SO_L--
        public bool SaveSO_L(SO_L _SO_L)
        {
            bool rType = false;
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    int SO_LNum = (int)db.p_SaveSO_L(_SO_L.SO_LNum, _SO_L.SONum, _SO_L.ItemNum,_SO_L.ItemType, _SO_L.LineDesc, _SO_L.Discount, _SO_L.UnitPrice, _SO_L.ItemsPackMsrNum, _SO_L.Quantity,_SO_L.TaxGroupNum, _SO_L.TaxNum_1, _SO_L.TaxNum_2, _SO_L.LineTotal, _SO_L.DocSatesNum).FirstOrDefault();
                    if (SO_LNum > 0)
                    {
                        rType = true;
                        _SO_L.SO_LNum = SO_LNum;
                    }
                }
                catch { rType = false; }
            }
            return rType;
        }
        #endregion

        #region--Delete SO_L--
        public void DeleteSO_L(int SONum)
        {
            using (DBEntities db = new DBEntities())
            {
                SO_L temp = db.SO_L.Where(s=>s.SO_LNum==SONum).FirstOrDefault();
                if(temp!=null)
                {
                    db.SO_L.Remove(temp);
                    db.SaveChanges();
                }
                
            }
        }
        #endregion
    }
}
