﻿
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class POProvider
    {
        #region--Instance--
        public static POProvider Instance = new POProvider();
        #endregion

        #region--Save PO--
        public bool SavePO(p_FilterPO_Result _PO)
        {
            bool rType = false;
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    int PONum = (int)db.p_SavePO(_PO.PONum, _PO.GlobalCustomerNum, _PO.BPNum, _PO.AdressNum, _PO.SODate, _PO.SODueDate, _PO.LanguageNum, _PO.DocSatesCode, _PO.SORef, _PO.InternNote, _PO.VisibleNote
                         , _PO.SOTotal, _PO.SOSubTotal, _PO.SOTaxTotal, _PO.SODiscountTotal, _PO.CreatedBy, _PO.UserNum, _PO.UserNum_SalesRep).FirstOrDefault();
                    if (PONum > 0)
                    {
                        rType = true;
                        _PO.PONum = PONum;
                    }
                }
                catch { rType = false; }
            }
            return rType;
        }
        #endregion

        #region--Get SO--
        public List<p_FilterPO_Result> FilterPO(FilterPOEntity _FilterPO)
        {
            List<p_FilterPO_Result> rType = new List<p_FilterPO_Result>();
            using (DBEntities db = new DBEntities())
            {
                rType = db.p_FilterPO(_FilterPO.PONum, _FilterPO.GlobalCustomerNum, _FilterPO.UserNum_SalesRep, _FilterPO.AdressNum, _FilterPO.DocSatesCode, _FilterPO.BPCode, _FilterPO.SORef, _FilterPO.SOStartDate, _FilterPO.SOEndDate, _FilterPO.SODueDateStartDate, _FilterPO.SODueDateEndDate, _FilterPO.OrderBy, _FilterPO.OrderDir, _FilterPO.PageNumber, _FilterPO.PageSize).ToList();
            }
            return rType;
        }
        #endregion

        #region--Get PO_L--
        public List<PO_L> GetPO_L(int PO_LNum, int PONum)
        {
            List<PO_L> rType = new List<PO_L>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from s in db.PO_L
                         where ((s.PO_LNum == PO_LNum || PO_LNum == 0)
                             && (PONum == 0 || s.PONum == PONum))
                         select s).ToList();
            }
            return rType;

        }
        #endregion

        #region--Save PO_L--
        public bool SavePO_L(PO_L _PO_L)
        {
            bool rType = false;
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    int PO_LNum = (int)db.p_SavePO_L(_PO_L.PO_LNum, _PO_L.PONum, _PO_L.ItemNum,_PO_L.ItemType, _PO_L.LineDesc, _PO_L.Discount, _PO_L.UnitPrice, _PO_L.ItemsPackMsrNum, _PO_L.Quantity,_PO_L.TaxGroupNum, _PO_L.TaxNum_1, _PO_L.TaxNum_2, _PO_L.LineTotal, _PO_L.DocSatesNum).FirstOrDefault();
                    if (PO_LNum > 0)
                    {
                        rType = true;
                        _PO_L.PO_LNum = PO_LNum;
                    }
                }
                catch { rType = false; }
            }
            return rType;
        }
        #endregion

        #region--Delete PO_L--
        public void DeletePO_L(int PO_LNum)
        {
            using (DBEntities db = new DBEntities())
            {
                PO_L temp = db.PO_L.Where(s => s.PO_LNum == PO_LNum).FirstOrDefault();
                if (temp != null)
                {
                    db.PO_L.Remove(temp);
                    db.SaveChanges();
                }

            }
        }
        #endregion
    }
}
