﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class LanguagesProvider
    {
        #region--Instance--
        public static LanguagesProvider Instance = new LanguagesProvider();
        #endregion

        #region--Get Languages--
        public List<Language> GetLanguages(int LanguageNum)
        {
            List<Language> rType = new List<Language>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Languages where ((c.LanguageNum == LanguageNum || LanguageNum == 0) && (c.Active==true)) select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

       
    }
}
