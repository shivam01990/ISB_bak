﻿using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UserAccessesProvider
    {
        #region--Instance--
        public static UserAccessesProvider Instance = new UserAccessesProvider();
        #endregion

        #region--Get User Access--
        public List<UserAccess> GetUserAccess(int UserAccessNum, int AccessNum, int UserNum)
        {
            List<UserAccess> rType = new List<UserAccess>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.UserAccesses
                             where (c.UserAccessNum == UserAccessNum || UserAccessNum == 0)
                             && (c.AccessNum == AccessNum || AccessNum == 0)
                             && (c.UserNum == UserNum || UserNum == 0)
                             select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

        #region--Save User Access--
        public int CreateUpdateUserAccess(UserAccess ua)
        {
            int UserAccessNum = 0;
            using (DBEntities db = new DBEntities())
            {
                if (ua.UserAccessNum > 0)
                {
                    UserAccess temp = db.UserAccesses.Where(u => u.UserAccessNum == ua.UserAccessNum).FirstOrDefault();

                    if (temp != null)
                    {
                        temp.UserAccessNum = ua.UserAccessNum;
                        temp.GlobalCustomerNum = ua.GlobalCustomerNum;
                        temp.UserNum = ua.UserNum;
                        temp.CoreModuleNum = ua.CoreModuleNum;
                        temp.AccessNum = ua.AccessNum;
                        temp.ReadAccess = ua.ReadAccess;
                        temp.WriteAccess = ua.WriteAccess;
                    }
                }
                else
                {
                    db.UserAccesses.Add(ua);
                }

                int x = db.SaveChanges();
                if (x > 0)
                {
                    UserAccessNum = ua.UserAccessNum;
                }
            }

            return UserAccessNum;
        }
        #endregion      

    }
}
