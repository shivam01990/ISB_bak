﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class RatingValueProvider
    {
       #region--Instance--
       public static RatingValueProvider Instance = new RatingValueProvider();
       #endregion

       //********************************************************* 
       //Purpose:    Get all Rating Values from the database. 
       //Returns:    list of all the Ratung Values.
       //*********************************************************
       public List<RatingValue> GetRatingValues()
       {
           try
           {
               using (var dbcontext = new DBEntities())
               {
                   var listRatingValues = dbcontext.RatingValues;

                   if (listRatingValues != null)
                   {
                       return listRatingValues.ToList();
                   }
                   return null;
               }
           }
           catch (Exception)
           {
               throw;
           }
       }
        

    }
}
