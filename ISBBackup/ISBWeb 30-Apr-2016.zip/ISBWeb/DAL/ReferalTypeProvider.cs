﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class ReferalTypeProvider
    {
       #region--Instance--
       public static ReferalTypeProvider Instance = new ReferalTypeProvider();
       #endregion

       #region--Get RefralType--
       public List<ReferalType> GetReferalTypes(int ReferalTypeNum)
       {
           List<ReferalType> rType = new List<ReferalType>();
           using (DBEntities db = new DBEntities())
           {
               try
               {
                   rType = (from c in db.ReferalTypes where (c.ReferalTypeNum == ReferalTypeNum || ReferalTypeNum == 0) && c.Active == true select c).ToList();
               }
               catch { }
           }
           return rType;
       }
       #endregion
    }
}
