﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class DocStatesProvider
   {

       #region--Instance--
       public static DocStatesProvider Instance = new DocStatesProvider();

       #endregion

       #region --Get DocStates--
       public List<DocState> GetDocStates()
       {
           List<DocState> rtype = new List<DocState>();
           using (DBEntities db = new DBEntities())
           {
               rtype = (from d in db.DocStates where d.Active==true select d).ToList();
           }
           return rtype;
       }
       #endregion
   }
}
