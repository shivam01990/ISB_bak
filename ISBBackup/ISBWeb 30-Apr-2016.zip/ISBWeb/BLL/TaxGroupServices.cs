﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class TaxGroupServices
    {
        #region--Instance--
        public static TaxGroupServices Instance = new TaxGroupServices();
        #endregion

        #region--Get All TaxGroups--
        public List<TaxGroup> GetTaxGroups(int TaxNumId)
        {
            return TaxGroupProvider.Instance.GetTaxGroups(TaxNumId);
        }
        #endregion

        #region--Get All TaxGroups--
        public List<TaxGroup> GetAllTaxGroups()
        {
            return TaxGroupProvider.Instance.GetTaxGroups(0);
        }
        #endregion

    }
}
