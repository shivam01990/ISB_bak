﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ItemTypeServices
    {
        #region--Instance--
        public static ItemTypeServices Instance = new ItemTypeServices();
        #endregion

        #region--Get Item Type--
        public ItemType GetItemType(int itemTypeNum)
        {
            return ItemTypeProvider.Instance.GetItemType(itemTypeNum).FirstOrDefault();
        }
        #endregion


        #region--Get Item Type--
        public List<ItemType> GetAllItemType()
        {
            return ItemTypeProvider.Instance.GetItemType(0);
        }
        #endregion
    }
}
