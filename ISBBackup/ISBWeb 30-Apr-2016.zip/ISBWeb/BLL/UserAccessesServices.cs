﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UserAccessesServices
    {
        #region--Instance--
        public static UserAccessesServices Instance = new UserAccessesServices();
        #endregion

        #region--Get User Access--
        public List<UserAccess> GetUserAccess(int UserAccessNum, int AccessNum, int UserNum)
        {
            List<UserAccess> rType = new List<UserAccess>();
            rType = UserAccessesProvider.Instance.GetUserAccess(UserAccessNum, AccessNum, UserNum);
            return rType;
        }
        #endregion


        #region--Save User Access--
        public int CreateUpdateUserAccess(UserAccess ua)
        {
            return UserAccessesProvider.Instance.CreateUpdateUserAccess(ua);
        }
        #endregion

    }
}
