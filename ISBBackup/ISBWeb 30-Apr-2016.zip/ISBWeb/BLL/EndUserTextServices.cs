﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class EndUserTextServices
    {
        #region--Instance--
        public static EndUserTextServices Instance = new EndUserTextServices();
        #endregion

        #region--Load End User text--
        public string LoadEndUserText(int intEndUserTextNum, int IntUserLanguage)
        {
            try
            {
                return EndUserTextProvider.Instance.LoadEndUserText(intEndUserTextNum, IntUserLanguage);

            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion


    }
}
