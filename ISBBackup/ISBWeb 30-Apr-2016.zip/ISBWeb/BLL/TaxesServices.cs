﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class TaxesServices
    {
        #region--Instance--
        public static TaxesServices Instance = new TaxesServices();
        #endregion

        #region--Get Tax--
        public List<Tax> GetTax(int TaxNum)
        {
            return TaxesProvider.Instance.GetTax(TaxNum);
        }
        #endregion
    }
}
