﻿using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class POServices
    {
        #region--Instance--
        public static POServices Instance = new POServices();
        #endregion

        #region--Save PO--
        public bool SavePO(p_FilterPO_Result _PO)
        {
            return POProvider.Instance.SavePO(_PO);
        }
        #endregion

        #region--Get PO--
        public List<p_FilterPO_Result> FilterPO(FilterPOEntity _FilterPO)
        {
            List<p_FilterPO_Result> rType = new List<p_FilterPO_Result>();
            rType = POProvider.Instance.FilterPO(_FilterPO);
            return rType;
        }
        #endregion

        #region--Get SO_L--
        public List<PO_L> GetPO_L(int PO_LNum, int PONum)
        {
            List<PO_L> rType = new List<PO_L>();
            rType = POProvider.Instance.GetPO_L(PO_LNum, PONum);
            return rType;
        }
        #endregion

        #region--Save PO_L--
        public bool SavePO_L(PO_L _PO_L)
        {
            return POProvider.Instance.SavePO_L(_PO_L);
        }
        #endregion

        #region--Delete PO_L--
        public void DeletePO_L(int PO_LNum)
        {
            POProvider.Instance.DeletePO_L(PO_LNum);
        }
        #endregion
    }
}
