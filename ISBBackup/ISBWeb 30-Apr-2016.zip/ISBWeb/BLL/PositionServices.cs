﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class PositionServices
    {
        #region--Instance--
        public static PositionServices Instance = new PositionServices();
        #endregion

        #region--Get Position--
        public Position GetPosition(int PositionNum)
        {
            return PositionProvider.Instance.GetPosition(PositionNum).FirstOrDefault();
        }
        #endregion

        #region--Get All Position--
        public List<Position> GetAllPosition()
        {
            return PositionProvider.Instance.GetPosition(0);
        }
        #endregion
    }
}
