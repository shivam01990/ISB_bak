﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ReferalTypeServices
    {
        #region--Instance--
        public static ReferalTypeServices Instance = new ReferalTypeServices();
        #endregion

        #region--Get RefralType--
        public ReferalType GetReferalType(int ReferalTypeNum)
        {
            return ReferalTypeProvider.Instance.GetReferalTypes(ReferalTypeNum).FirstOrDefault();
        }
        #endregion

        #region--Get RefralType--
        public List<ReferalType> GetAllReferalType()
        {
            return ReferalTypeProvider.Instance.GetReferalTypes(0);
        }
        #endregion
    }
}
