﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class DocStatesServices
    {
        #region--Instance--
        public static DocStatesServices Instance = new DocStatesServices();
        #endregion

        #region --Get DocStates--
        public List<DocState> GetDocStates()
       {
           return DocStatesProvider.Instance.GetDocStates();
       }
        #endregion
    }
}
