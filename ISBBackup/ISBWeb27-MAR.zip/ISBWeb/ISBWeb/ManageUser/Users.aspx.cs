﻿using BLL;
using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.ManageUser
{
    public partial class Users : System.Web.UI.Page
    {
        #region ---Declaration---
        protected int PageSize = 25;
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }
        #endregion

        #region--Page Load--
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGender();
                BindUsers();
            }
        }
        #endregion

        #region--Bind Gender--
        protected void BindGender()
        {
            ddlGender.AppendDataBoundItems = true;
            ddlGender.DataSource = GenderServices.Instance.GetAllGender();
            ddlGender.DataTextField = "Name";
            ddlGender.DataValueField = "GenderNum";
            ddlGender.DataBind();
            ddlGender.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select All" }));
        }
        #endregion

        #region ---Bind Customers---
        public void BindUsers()
        {
            int GenderNum = 0;
            int.TryParse(ddlGender.SelectedValue, out GenderNum);

            FilterUserEntity _FilterUserEntity = new FilterUserEntity();
            _FilterUserEntity.UserNum = 0;
            _FilterUserEntity.GlobalCustomerNum = 0;
            _FilterUserEntity.Name = txtName.Text;
            _FilterUserEntity.UserName = txtUserName.Text;
            _FilterUserEntity.City = txtCity.Text;
            _FilterUserEntity.State = txtState.Text;
            if (chkIsManager.Checked)
            {
                _FilterUserEntity.IsManager = true;
            }
            else
            {
                _FilterUserEntity.IsManager = null;
            }

            _FilterUserEntity.GenderNum = GenderNum;

            if (ddlActive.SelectedValue != "0")
            {
                _FilterUserEntity.Active = bool.Parse(ddlActive.SelectedValue);
            }
            else
            {
                _FilterUserEntity.Active = null;
            }

            _FilterUserEntity.OrderBy = HdnOrderBy.Value;
            _FilterUserEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterUserEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterUserEntity.PageSize = PageSize;
            GrdCustomers.PageSize = PageSize;
            List<p_FilterUsers_Result> OfferList = UserServices.Instance.FilterUsers(_FilterUserEntity);

            if (OfferList != null && OfferList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = OfferList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = OfferList;
            GrdCustomers.DataBind();
        }
        #endregion


        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                //if (Offers.Instance.DeleteOffer(int.Parse(e.CommandArgument.ToString())))
                //{
                //    Common.ShowMessage(DivMsg, "Offer successfully deleted", Page.ResolveUrl("~"), true);
                //    BindOffers();
                //}
                //else
                //{
                //    Common.ShowMessage(DivMsg, "Unable to delete Offer", Page.ResolveUrl("~"), true);
                //}
            }
        }
        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    sp_GetOfferList_Result data = (sp_GetOfferList_Result)e.Row.DataItem;
            //    LinkButton LnkDelete = (LinkButton)e.Row.FindControl("LnkDelete");
            //    if (LnkDelete != null)
            //    {
            //        LnkDelete.CommandName = "Delete";
            //        LnkDelete.CommandArgument = data.OfferID.ToString();
            //        LnkDelete.Attributes.Add("onclick", "return ConfirmBoxWithPostBack('Are you sure to delete this Offer?','" + LnkDelete.UniqueID + "');");
            //    }
            //}
        }
        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindUsers();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindUsers();
        }
        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindUsers();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtUserName.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            ddlActive.ClearSelection();
            ddlActive.Items.FindByValue("0").Selected = true;
            ddlGender.ClearSelection();
            ddlGender.Items.FindByValue("0").Selected = true;
            chkIsManager.Checked = false;
            BindUsers();
        }

    }
}