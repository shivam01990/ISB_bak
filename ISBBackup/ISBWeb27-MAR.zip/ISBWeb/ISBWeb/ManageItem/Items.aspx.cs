﻿using BLL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;

namespace ISBWeb.ManageItem
{
    public partial class Items : System.Web.UI.Page
    {
        #region ---Declaration---
        protected int PageSize = 25;
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }


        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDropDown();
                BindItems();
            }
        }

        #region--Bind DropDown--
        public void BindDropDown()
        {
            ddlItemsType.AppendDataBoundItems = true;
            ddlItemsType.DataSource = ItemTypeServices.Instance.GetAllItemType();
            ddlItemsType.DataTextField = "Name";
            ddlItemsType.DataValueField = "ItemTypeNum";
            ddlItemsType.DataBind();
            ddlItemsType.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "Select All" }));

            ddlCategory.AppendDataBoundItems = true;
            ddlCategory.DataSource = CategoryServices.Instance.GetAllCategory();
            ddlCategory.DataTextField = "Name";
            ddlCategory.DataValueField = "CategoryNum";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "Select All" }));

            ddlSubcategory.AppendDataBoundItems = true;
            ddlSubcategory.DataSource = SubCategoryServices.Instance.GetAllSubCategory();
            ddlSubcategory.DataTextField = "Name";
            ddlSubcategory.DataValueField = "SubCategoryNum";
            ddlSubcategory.DataBind();
            ddlSubcategory.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "Select All" }));

            ddlDefaultSupplier.AppendDataBoundItems = true;
            ddlDefaultSupplier.DataSource = BPServices.Instance.GetAllBP();
            ddlDefaultSupplier.DataTextField = "Name";
            ddlDefaultSupplier.DataValueField = "BPNum";
            ddlDefaultSupplier.DataBind();
            ddlDefaultSupplier.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "Select All" }));

            ddlCountryOfOrigin.AppendDataBoundItems = true;
            ddlCountryOfOrigin.DataSource = CountryServices.Instance.GetAllCountry();
            ddlCountryOfOrigin.DataTextField = "Name";
            ddlCountryOfOrigin.DataValueField = "CountryNum";
            ddlCountryOfOrigin.DataBind();
            ddlCountryOfOrigin.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = "Select All" }));
        }
        #endregion

        #region ---Bind Items---
        public void BindItems()
        {
            FilterItemEntity _FilterItemEntity = new FilterItemEntity();
            _FilterItemEntity.ItemNum = 0;
            _FilterItemEntity.GlobalCustomerNum = 0;
            _FilterItemEntity.Code = txtCode.Text;
            _FilterItemEntity.EAN13 = txtEAN13.Text;
            _FilterItemEntity.ItemTypeNum = int.Parse(ddlItemsType.SelectedValue);
            _FilterItemEntity.CategoryNum = int.Parse(ddlCategory.SelectedValue);
            _FilterItemEntity.SubCategoryNum = int.Parse(ddlSubcategory.SelectedValue);
            _FilterItemEntity.DefaultSupplierBPNum = int.Parse(ddlDefaultSupplier.SelectedValue);
            _FilterItemEntity.CountryOfOriginNum = int.Parse(ddlCountryOfOrigin.SelectedValue);
            _FilterItemEntity.OrderBy = HdnOrderBy.Value;
            _FilterItemEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterItemEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterItemEntity.PageSize = PageSize;
            GrdCustomers.PageSize = PageSize;
            List<p_FilterItems_Result> OfferList = ItemsServices.Instance.FilterItems(_FilterItemEntity);

            if (OfferList != null && OfferList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = OfferList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = OfferList;
            GrdCustomers.DataBind();
        }
        #endregion


        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                //if (Offers.Instance.DeleteOffer(int.Parse(e.CommandArgument.ToString())))
                //{
                //    Common.ShowMessage(DivMsg, "Offer successfully deleted", Page.ResolveUrl("~"), true);
                //    BindOffers();
                //}
                //else
                //{
                //    Common.ShowMessage(DivMsg, "Unable to delete Offer", Page.ResolveUrl("~"), true);
                //}
            }
        }
        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    sp_GetOfferList_Result data = (sp_GetOfferList_Result)e.Row.DataItem;
            //    LinkButton LnkDelete = (LinkButton)e.Row.FindControl("LnkDelete");
            //    if (LnkDelete != null)
            //    {
            //        LnkDelete.CommandName = "Delete";
            //        LnkDelete.CommandArgument = data.OfferID.ToString();
            //        LnkDelete.Attributes.Add("onclick", "return ConfirmBoxWithPostBack('Are you sure to delete this Offer?','" + LnkDelete.UniqueID + "');");
            //    }
            //}
        }
        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindItems();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindItems();
        }
        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindItems();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtCode.Text = "";
            txtEAN13.Text = "";

            ddlItemsType.ClearSelection();
            ddlItemsType.Items.FindByValue("0").Selected = true;

            ddlCategory.ClearSelection();
            ddlCategory.Items.FindByValue("0").Selected = true;

            ddlSubcategory.ClearSelection();
            ddlSubcategory.Items.FindByValue("0").Selected = true;

            ddlDefaultSupplier.ClearSelection();
            ddlDefaultSupplier.Items.FindByValue("0").Selected = true;

            ddlCountryOfOrigin.ClearSelection();
            ddlCountryOfOrigin.Items.FindByValue("0").Selected = true;

            BindItems();
        }
    }
}