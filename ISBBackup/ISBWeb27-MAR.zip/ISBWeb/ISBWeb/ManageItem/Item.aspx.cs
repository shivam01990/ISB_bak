﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.ManageItem
{
    public partial class Item : System.Web.UI.Page
    {
        #region ---Initialize---
        int _itemnum = 0;
        public int ItemNum
        {
            get
            {
                if (Request.QueryString["ItemNum"] != null)
                {
                    int.TryParse(Request.QueryString["ItemNum"].ToString(), out _itemnum);
                }
                return _itemnum;
            }

        }

        protected string SesStrUsersMngRight
        {
            get
            {
                string u = "";
                if (Session[AppConstants.Instance.SesStrUsersMngRight] == null)
                {
                    u = "R";
                }
                else
                {
                    u = Session[AppConstants.Instance.SesStrUsersMngRight].ToString();
                }

                return u;
            }

            set
            {
                Session[AppConstants.Instance.SesStrUsersMngRight] = value;
            }
        }

        protected int SesGlobalCustomerNum
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesGlobalCustomerNum] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesGlobalCustomerNum].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesGlobalCustomerNum] = u;
                }
                return u;
            }
            set
            {
                Session["SesGlobalCustomerNum"] = value;
            }
        }

        protected int SesUserID
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesUserID] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesUserID].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesUserID] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesUserID] = value;
            }
        }

        protected int SesIntUserLanguage
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesIntUserLanguage] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesIntUserLanguage].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesIntUserLanguage] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesIntUserLanguage] = value;
            }
        }
        #endregion

        #region ---Page Load---
        protected void Page_Load(object sender, EventArgs e)
        {
            txtCostPrice.Enabled = false;
            if (!IsPostBack)
            {
                SesStrUsersMngRight = "RW";
                SesGlobalCustomerNum = 1;
                SesUserID = 1;
                SesIntUserLanguage = 1;
                BindLabelNames();
                BindDropDown();
                BindItem();
                CheckOtherFieldVisibility();
                CheckPermission();
                ItemMenu();
            }
            txtCostPrice.Attributes.Add("placeholder", "deadman");
        }
        #endregion

        #region--Item Menu--
        public void ItemMenu()
        {
            if (ItemNum == 0)
            {
                Helper.DisableLinkButton(lnkDelete);
                Helper.DisableLinkButton(lnkPrevious);
                Helper.DisableLinkButton(lnkNext);  
            }
            else
            {
                using (DBEntities db = new DBEntities())
                {
                    var next = (from x in db.Items where x.ItemNum > ItemNum && x.Active == true orderby x.ItemNum ascending select x).FirstOrDefault();
                    var prev = (from x in db.Items where x.ItemNum < ItemNum && x.Active == true orderby x.ItemNum descending select x).FirstOrDefault();
                    if (next != null)
                    {
                        lnkNext.Attributes.Add("href", Page.ResolveUrl("~") + "ManageItem/Item.aspx?ItemNum=" + next.ItemNum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkNext);
                    }
                    if (prev != null)
                    {
                        lnkPrevious.Attributes.Add("href", Page.ResolveUrl("~") + "ManageItem/Item.aspx?ItemNum=" + prev.ItemNum);
                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkPrevious);
                    }
                }
            }

            using (DBEntities db = new DBEntities())
            {
                var last = (from x in db.Items where x.Active == true orderby x.ItemNum descending select x).FirstOrDefault();
                var first = (from x in db.Items where x.Active == true orderby x.ItemNum ascending select x).FirstOrDefault();
                if (first != null)
                {
                    lnkFirst.Attributes.Add("href", Page.ResolveUrl("~") + "ManageItem/Item.aspx?ItemNum=" + first.ItemNum);

                }
                else
                {
                    Helper.DisableLinkButton(lnkFirst);
                }
                if (last != null)
                {
                    lnkLast.Attributes.Add("href", Page.ResolveUrl("~") + "ManageItem/Item.aspx?ItemNum=" + last.ItemNum);
                }
                else
                {
                    Helper.DisableLinkButton(lnkLast);
                }
            }


        }
        #endregion

        #region--Bind Drop Down--
        public void BindDropDown()
        {
            string dropDownDefault = VocabularyDisplayServices.Instance.LoadVocabulary(26, SesIntUserLanguage).TextValue;

            List<Country> dtCountry = CountryServices.Instance.GetAllCountry();

            drpCountryOfOrigin.AppendDataBoundItems = true;
            drpCountryOfOrigin.DataSource = dtCountry;
            drpCountryOfOrigin.DataTextField = "Name";
            drpCountryOfOrigin.DataValueField = "CountryNum";
            drpCountryOfOrigin.DataBind();
            drpCountryOfOrigin.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));

            drpItemType.AppendDataBoundItems = true;
            drpItemType.DataSource = ItemTypeServices.Instance.GetAllItemType();
            drpItemType.DataTextField = "Name";
            drpItemType.DataValueField = "ItemTypeNum";
            drpItemType.DataBind();
            drpItemType.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));

            drpCategory.AppendDataBoundItems = true;
            drpCategory.DataSource = CategoryServices.Instance.GetAllCategory();
            drpCategory.DataTextField = "Name";
            drpCategory.DataValueField = "CategoryNum";
            drpCategory.DataBind();
            drpCategory.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));

            drpSubCategory.AppendDataBoundItems = true;
            drpSubCategory.DataSource = SubCategoryServices.Instance.GetAllSubCategory();
            drpSubCategory.DataTextField = "Name";
            drpSubCategory.DataValueField = "SubCategoryNum";
            drpSubCategory.DataBind();
            drpSubCategory.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));

            drpDefaultUOM.AppendDataBoundItems = true;
            drpDefaultUOM.DataSource = UOMItemsServices.Instance.GetAllUOMItems();
            drpDefaultUOM.DataTextField = "Name";
            drpDefaultUOM.DataValueField = "UOMItemNum";
            drpDefaultUOM.DataBind();
            drpDefaultUOM.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));

            drpDefaultSupplier.AppendDataBoundItems = true;
            drpDefaultSupplier.DataSource = BPServices.Instance.GetAllBP();
            drpDefaultSupplier.DataTextField = "Name";
            drpDefaultSupplier.DataValueField = "BPNum";
            drpDefaultSupplier.DataBind();
            drpDefaultSupplier.Items.Insert(0, (new ListItem() { Value = AppConstants.Instance.DrpSelectValue, Text = dropDownDefault }));
        }
        #endregion

        #region--Bind Label Names--
        public void BindLabelNames()
        {
            lblItemCode.Text = VocabularyDisplayServices.Instance.LoadVocabulary(300, SesIntUserLanguage).TextValue;
            txtItemCode.Attributes.Add("placeholder", lblItemCode.Text);

            lblDescription.Text = VocabularyDisplayServices.Instance.LoadVocabulary(301, SesIntUserLanguage).TextValue;
            txtDescription.Attributes.Add("placeholder", lblDescription.Text);

            lblUPCNo.Text = VocabularyDisplayServices.Instance.LoadVocabulary(302, SesIntUserLanguage).TextValue;
            txtUPCNo.Attributes.Add("placeholder", lblUPCNo.Text);

            lblEAN.Text = VocabularyDisplayServices.Instance.LoadVocabulary(303, SesIntUserLanguage).TextValue;
            txtEAN.Attributes.Add("placeholder", lblEAN.Text);

            lblItemType.Text = VocabularyDisplayServices.Instance.LoadVocabulary(304, SesIntUserLanguage).TextValue;

            lblVolume.Text = VocabularyDisplayServices.Instance.LoadVocabulary(305, SesIntUserLanguage).TextValue;
            txtVolume.Attributes.Add("placeholder", lblVolume.Text);

            lblDefaultSupplier.Text = VocabularyDisplayServices.Instance.LoadVocabulary(306, SesIntUserLanguage).TextValue;

            lblGrossWeight.Text = VocabularyDisplayServices.Instance.LoadVocabulary(307, SesIntUserLanguage).TextValue;
            txtGrossWeight.Attributes.Add("placeholder", lblGrossWeight.Text);

            lblCostPrice.Text = VocabularyDisplayServices.Instance.LoadVocabulary(308, SesIntUserLanguage).TextValue;
            txtCostPrice.Attributes.Add("placeholder", lblCostPrice.Text);

            lblNetWeight.Text = VocabularyDisplayServices.Instance.LoadVocabulary(309, SesIntUserLanguage).TextValue;
            txtNetWeight.Attributes.Add("placeholder", lblNetWeight.Text);

            lblCountryOfOrigin.Text = VocabularyDisplayServices.Instance.LoadVocabulary(310, SesIntUserLanguage).TextValue;
            lblCategory.Text = VocabularyDisplayServices.Instance.LoadVocabulary(311, SesIntUserLanguage).TextValue;
            lblSubCategpry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(312, SesIntUserLanguage).TextValue;
            lblDefaultUOM.Text = VocabularyDisplayServices.Instance.LoadVocabulary(313, SesIntUserLanguage).TextValue;
            lblLogo.Text = VocabularyDisplayServices.Instance.LoadVocabulary(314, SesIntUserLanguage).TextValue;
            lblBuyItem.Text = VocabularyDisplayServices.Instance.LoadVocabulary(315, SesIntUserLanguage).TextValue;
            lblPurchaseItem.Text = VocabularyDisplayServices.Instance.LoadVocabulary(316, SesIntUserLanguage).TextValue;
            lblActive.Text = VocabularyDisplayServices.Instance.LoadVocabulary(317, SesIntUserLanguage).TextValue;
            lblCanBeReturned.Text = VocabularyDisplayServices.Instance.LoadVocabulary(318, SesIntUserLanguage).TextValue;
            lblCoumn1.Text = VocabularyDisplayServices.Instance.LoadVocabulary(319, SesIntUserLanguage).TextValue;
            lblCoumn2.Text = VocabularyDisplayServices.Instance.LoadVocabulary(320, SesIntUserLanguage).TextValue;
            btnSave.Text = VocabularyDisplayServices.Instance.LoadVocabulary(321, SesIntUserLanguage).TextValue;
            btnClose.Text = VocabularyDisplayServices.Instance.LoadVocabulary(322, SesIntUserLanguage).TextValue;


        }
        #endregion

        #region--Check Permissions--
        public void CheckPermission()
        {
            if (SesStrUsersMngRight == "R")
            {
                FUOfferImage.Enabled = false;
                btnClose.Enabled = false;
                btnSave.Enabled = false;
                txtItemCode.ReadOnly = true;
                txtDescription.ReadOnly = true;
                txtUPCNo.ReadOnly = true;
                txtEAN.ReadOnly = true;
                drpItemType.Enabled = false;
                txtVolume.ReadOnly = true;
                drpDefaultSupplier.Enabled = false;
                txtGrossWeight.ReadOnly = true;
                txtCostPrice.ReadOnly = true;
                txtNetWeight.ReadOnly = true;
                drpCountryOfOrigin.Enabled = false;
                drpCategory.Enabled = false;
                drpSubCategory.Enabled = false;
                drpDefaultUOM.Enabled = false;
                chkBuyItem.Enabled = false;
                chkPurchaseItem.Enabled = false;
                chkActive.Enabled = false;
                chkCanBeReturned.Enabled = false;

                txtField1Name.ReadOnly = true;
                txtField1Value.ReadOnly = true;

                txtField2Name.ReadOnly = true;
                txtField2Value.ReadOnly = true;

                txtField3Name.ReadOnly = true;
                txtField3Value.ReadOnly = true;

                txtField4Name.ReadOnly = true;
                txtField4Value.ReadOnly = true;

                txtField5Name.ReadOnly = true;
                txtField5Value.ReadOnly = true;

                txtField6Name.ReadOnly = true;
                txtField6Value.ReadOnly = true;

                txtField7Name.ReadOnly = true;
                txtField7Value.ReadOnly = true;

                txtField8Name.ReadOnly = true;
                txtField8Value.ReadOnly = true;
            }
        }
        #endregion

        #region--Initialize Web Form--
        public void InitializeForm()
        {
            txtItemCode.Text = "";
            txtDescription.Text = "";
            txtUPCNo.Text = "";
            txtEAN.Text = "";
            drpItemType.ClearSelection();
            drpItemType.SelectedIndex = 0;
            txtVolume.Text = "0";
            drpDefaultSupplier.ClearSelection();
            drpDefaultSupplier.Enabled = false;
            txtGrossWeight.Text = "0";
            txtCostPrice.Text = "0";
            txtNetWeight.Text = "0";
            drpCountryOfOrigin.ClearSelection();
            drpCountryOfOrigin.Enabled = false;
            drpCategory.ClearSelection();
            drpCategory.Enabled = false;
            drpSubCategory.ClearSelection();
            drpSubCategory.Enabled = false;
            drpDefaultUOM.ClearSelection();
            drpDefaultUOM.Enabled = false;
            chkBuyItem.Checked = true;
            chkPurchaseItem.Checked = true;
            chkActive.Checked = true;
            chkCanBeReturned.Checked = true;

            txtField1Name.Text = "";
            txtField1Value.Text = "";

            txtField2Name.Text = "";
            txtField2Value.Text = "";

            txtField3Name.Text = "";
            txtField3Value.Text = "";

            txtField4Name.Text = "";
            txtField4Value.Text = "";

            txtField5Name.Text = "";
            txtField5Value.Text = "";

            txtField6Name.Text = "";
            txtField6Value.Text = "";

            txtField7Name.Text = "";
            txtField7Value.Text = "";

            txtField8Name.Text = "";
            txtField8Value.Text = "";
        }
        #endregion

        #region--Bind Item--
        public void BindItem()
        {
            h1User.InnerText = "Add Item";
            if (ItemNum > 0)
            {
                DAL.Item _item = ItemsServices.Instance.GetItem(ItemNum);
                if (_item == null)
                {
                    Helper.ShowMessage(msgDiv, "Item does not exist.", false);
                    return;
                }
                h1User.InnerText = "Edit Item";
                txtItemCode.Text = _item.Code;
                txtDescription.Text = _item.Description;
                txtUPCNo.Text = _item.UPC;
                txtEAN.Text = _item.EAN13;

                if (_item.ItemTypeNum != null && drpItemType.Items.FindByValue(_item.ItemTypeNum.ToString()) != null)
                {
                    drpItemType.ClearSelection();
                    drpItemType.Items.FindByValue(_item.ItemTypeNum.ToString()).Selected = true;
                }

                txtVolume.Text = _item.Volume.ToString();

                if (_item.DefaultSupplierBPNum != null && drpDefaultSupplier.Items.FindByValue(_item.DefaultSupplierBPNum.ToString()) != null)
                {
                    drpDefaultSupplier.ClearSelection();
                    drpDefaultSupplier.Items.FindByValue(_item.DefaultSupplierBPNum.ToString()).Selected = true;
                }

                txtGrossWeight.Text = _item.GrossWeight.ToString();
                //txtCostPrice.Text = _item.CostPrice.ToString();
                txtNetWeight.Text = _item.NetWeight.ToString();

                if (_item.CountryOfOriginNum != null && drpCountryOfOrigin.Items.FindByValue(_item.CountryOfOriginNum.ToString()) != null)
                {
                    drpCountryOfOrigin.ClearSelection();
                    drpCountryOfOrigin.Items.FindByValue(_item.CountryOfOriginNum.ToString()).Selected = true;
                }

                if (_item.CategoryNum != null && drpCategory.Items.FindByValue(_item.CategoryNum.ToString()) != null)
                {
                    drpCategory.ClearSelection();
                    drpCategory.Items.FindByValue(_item.CategoryNum.ToString()).Selected = true;
                }
                if (_item.SubCategoryNum != null && drpSubCategory.Items.FindByValue(_item.SubCategoryNum.ToString()) != null)
                {
                    drpSubCategory.ClearSelection();
                    drpSubCategory.Items.FindByValue(_item.SubCategoryNum.ToString()).Selected = true;
                }

                if (_item.UMOItemNum != null && drpDefaultUOM.Items.FindByValue(_item.UMOItemNum.ToString()) != null)
                {
                    drpDefaultUOM.ClearSelection();
                    drpDefaultUOM.Items.FindByValue(_item.UOMItem.ToString()).Selected = true;
                }


                chkBuyItem.Checked = _item.IsBuyItem == null ? false : (bool)_item.IsBuyItem;
                chkPurchaseItem.Checked = _item.IsPurchaseItem == null ? false : (bool)_item.IsPurchaseItem;
                chkActive.Checked = _item.Active == null ? false : (bool)_item.Active;
                chkCanBeReturned.Checked = _item.AllowReturn == null ? false : (bool)_item.AllowReturn;

                if (_item.PicturePath != null)
                {
                    OfferImageImageprw.ImageUrl = _item.PicturePath.Trim() == "" ? "~/images/no_image.png" : _item.PicturePath.Trim();
                }

                txtField1Name.Text = _item.CustomField1Name;
                txtField1Value.Text = _item.CustomField1Value;

                txtField2Name.Text = _item.CustomField2Name;
                txtField2Value.Text = _item.CustomField2Value;

                txtField3Name.Text = _item.CustomField3Name;
                txtField3Value.Text = _item.CustomField3Value;

                txtField4Name.Text = _item.CustomField4Name;
                txtField4Value.Text = _item.CustomField4Value;

                txtField5Name.Text = _item.CustomField5Name;
                txtField5Value.Text = _item.CustomField5Value;

                txtField6Name.Text = _item.CustomField6Name;
                txtField6Value.Text = _item.CustomField6Value;

                txtField7Name.Text = _item.CustomField7Name;
                txtField7Value.Text = _item.CustomField7Value;

                txtField8Name.Text = _item.CustomField8Name;
                txtField8Value.Text = _item.CustomField8Value;
            }
        }
        #endregion

        #region--Check Other Field Visibility--
        public void CheckOtherFieldVisibility()
        {
            GeneralSetting ObjGenSet = GeneralSettingServices.Instance.GetGeneralSettings(SesGlobalCustomerNum);
            if (ObjGenSet != null)
            {
                if (ObjGenSet.CustomFieldVis1 == false)
                    pnlField1.Visible = false;
                if (ObjGenSet.CustomFieldVis2 == false)
                    pnlField2.Visible = false;
                if (ObjGenSet.CustomFieldVis3 == false)
                    pnlField3.Visible = false;
                if (ObjGenSet.CustomFieldVis4 == false)
                    pnlField4.Visible = false;
                if (ObjGenSet.CustomFieldVis5 == false)
                    pnlField5.Visible = false;
                if (ObjGenSet.CustomFieldVis6 == false)
                    pnlField6.Visible = false;
                if (ObjGenSet.CustomFieldVis7 == false)
                    pnlField7.Visible = false;
                if (ObjGenSet.CustomFieldVis8 == false)
                    pnlField8.Visible = false;
            }

        }
        #endregion

        #region--Save Item--
        protected void btnSave_Click(object sender, EventArgs e)
        {
            DAL.Item _item = new DAL.Item();
            if (ItemNum > 0)
            {
                _item = ItemsServices.Instance.GetItem(ItemNum);
                if (_item == null)
                {
                    Helper.ShowMessage(msgDiv, "Item does not exist.", false);
                    return;

                }
            }
            float grossWeight = 0;
            float.TryParse(txtGrossWeight.Text, out grossWeight);

            float netWeight = 0;
            float.TryParse(txtNetWeight.Text, out netWeight);

            int countryOfOriginNum = 0;
            int.TryParse(drpCountryOfOrigin.SelectedValue, out countryOfOriginNum);

            int itemTypeNum = 0;
            int.TryParse(drpItemType.SelectedValue, out itemTypeNum);

            int defaultSupplierNum = 0;
            int.TryParse(drpDefaultSupplier.SelectedValue, out defaultSupplierNum);

            int categoryNum = 0;
            int.TryParse(drpCategory.SelectedValue, out categoryNum);

            int subCategoryNum = 0;
            int.TryParse(drpSubCategory.SelectedValue, out subCategoryNum);

            int defaultUOMNum = 0;
            int.TryParse(drpDefaultUOM.SelectedValue, out defaultUOMNum);

            int volume = 0;
            int.TryParse(txtVolume.Text, out volume);

            _item.Code = txtItemCode.Text;
            _item.GlobalCustomerNum = SesGlobalCustomerNum;
            _item.Description = txtDescription.Text;
            _item.UPC = txtUPCNo.Text;
            _item.EAN13 = txtEAN.Text;
            _item.ItemTypeNum = Helper.GetNullableInteger(itemTypeNum);
            _item.Volume = volume;
            _item.DefaultSupplierBPNum = Helper.GetNullableInteger(defaultSupplierNum);
            _item.GrossWeight = grossWeight;
            _item.NetWeight = netWeight;
            _item.CountryOfOriginNum = Helper.GetNullableInteger(countryOfOriginNum);
            _item.CategoryNum = Helper.GetNullableInteger(categoryNum);
            _item.SubCategoryNum = Helper.GetNullableInteger(subCategoryNum);
            _item.UMOItemNum = Helper.GetNullableInteger(defaultUOMNum);
            _item.PicturePath = "";
            _item.IsBuyItem = chkBuyItem.Checked;
            _item.IsPurchaseItem = chkPurchaseItem.Checked;
            _item.Active = chkActive.Checked;
            _item.AllowReturn = chkCanBeReturned.Checked;

            if (pnlField1.Visible)
            {
                _item.CustomField1Name = txtField1Name.Text;
                _item.CustomField1Value = txtField1Value.Text;
                _item.CustomField1Vis = true;
            }
            else
            {
                _item.CustomField1Vis = false;
            }

            if (pnlField2.Visible)
            {
                _item.CustomField2Name = txtField2Name.Text;
                _item.CustomField2Value = txtField2Value.Text;
                _item.CustomField2Vis = true;
            }
            else
            {
                _item.CustomField2Vis = false;
            }

            if (pnlField3.Visible)
            {
                _item.CustomField3Name = txtField3Name.Text;
                _item.CustomField3Value = txtField3Value.Text;
                _item.CustomField3Vis = true;
            }
            else
            {
                _item.CustomField3Vis = false;
            }

            if (pnlField4.Visible)
            {
                _item.CustomField4Name = txtField4Name.Text;
                _item.CustomField4Value = txtField4Value.Text;
                _item.CustomField4Vis = true;
            }
            else
            {
                _item.CustomField4Vis = false;
            }

            if (pnlField5.Visible)
            {
                _item.CustomField5Name = txtField5Name.Text;
                _item.CustomField5Value = txtField5Value.Text;
                _item.CustomField5Vis = true;
            }
            else
            {
                _item.CustomField5Vis = false;
            }

            if (pnlField6.Visible)
            {
                _item.CustomField6Name = txtField6Name.Text;
                _item.CustomField6Value = txtField6Value.Text;
                _item.CustomField6Vis = true;
            }
            else
            {
                _item.CustomField6Vis = false;
            }

            if (pnlField7.Visible)
            {
                _item.CustomField7Name = txtField7Name.Text;
                _item.CustomField7Value = txtField7Value.Text;
                _item.CustomField7Vis = true;
            }
            else
            {
                _item.CustomField7Vis = false;
            }

            if (pnlField8.Visible)
            {
                _item.CustomField8Name = txtField8Name.Text;
                _item.CustomField8Value = txtField8Value.Text;
                _item.CustomField8Vis = true;
            }
            else
            {
                _item.CustomField8Vis = false;
            }

            if (ItemNum == 0)
            {
                int temp = ItemsServices.Instance.InsertItem(_item);
                if (temp > 0)
                {
                    if (FUOfferImage.HasFile)
                    {
                        try
                        {
                            _item = ItemsServices.Instance.GetItem(temp);
                            if (_item != null)
                            {
                                string filename = temp.ToString() + Path.GetExtension(FUOfferImage.FileName.ToString());
                                string OfferImageFolderpath = System.Web.HttpContext.Current.Server.MapPath("~" + AppConstants.Instance.ItemLogoVirtuelPath);
                                FUOfferImage.SaveAs(OfferImageFolderpath + "\\" + filename);
                                _item.PicturePath = AppConstants.Instance.ItemLogoVirtuelPath + filename;
                                ItemsServices.Instance.UpdateItem(_item);
                            }
                        }
                        catch
                        { }
                    }
                    //success
                    Helper.ShowMessage(msgDiv, "Item is successfully created.", true);
                    InitializeForm();
                }
                else
                {
                    //Fails
                    Helper.ShowMessage(msgDiv, "Unable to create Item.", false);

                }
            }
            else
            {
                try
                {
                    if (FUOfferImage.HasFile)
                    {
                        string filename = ItemNum.ToString() + Path.GetExtension(FUOfferImage.FileName.ToString());
                        string OfferImageFolderpath = System.Web.HttpContext.Current.Server.MapPath("~" + AppConstants.Instance.ItemLogoVirtuelPath);
                        FUOfferImage.SaveAs(OfferImageFolderpath + "\\" + filename);
                        _item.PicturePath = AppConstants.Instance.ItemLogoVirtuelPath + filename;
                    }
                }
                catch
                { }
                ItemsServices.Instance.UpdateItem(_item);
                BindItem();
                Helper.ShowMessage(msgDiv, "Item is successfully updated.", true);
            }

        }
        #endregion
    }
}