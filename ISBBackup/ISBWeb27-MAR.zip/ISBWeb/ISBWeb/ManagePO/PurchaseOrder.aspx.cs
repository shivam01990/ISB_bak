﻿using BLL;
using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.ManagePO
{
    public partial class PurchaseOrder : System.Web.UI.Page
    {
        #region--Decleration--
        int _ponum = 0;
        public int PONum
        {
            get
            {
                if (Request.QueryString["PONum"] != null)
                {
                    int.TryParse(Request.QueryString["PONum"].ToString(), out _ponum);
                }
                return _ponum;
            }

        }

        protected string SesStrUsersMngRight
        {
            get
            {
                string u = "";
                if (Session[AppConstants.Instance.SesStrUsersMngRight] == null)
                {
                    u = "R";
                }
                else
                {
                    u = Session[AppConstants.Instance.SesStrUsersMngRight].ToString();
                }

                return u;
            }

            set
            {
                Session[AppConstants.Instance.SesStrUsersMngRight] = value;
            }
        }

        protected int SesGlobalCustomerNum
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesGlobalCustomerNum] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesGlobalCustomerNum].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesGlobalCustomerNum] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesGlobalCustomerNum] = value;
            }
        }

        protected int SesUserID
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesUserID] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesUserID].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesUserID] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesUserID] = value;
            }
        }

        protected int SesIntUserLanguage
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesIntUserLanguage] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesIntUserLanguage].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesIntUserLanguage] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesIntUserLanguage] = value;
            }
        }

        string FieldSeprationSymbol = "%&()";
        string RecordSeprationSymbol = "!^#";
        #endregion

        #region--Page Load--
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["msg"] != null)
                {
                    if (Request.QueryString["msg"] == "1")
                    {
                        Helper.ShowMessage(DivMsg, "Purchase Order Successfully Saved.", true);
                    }
                }
                SesStrUsersMngRight = "RW";
                SesGlobalCustomerNum = 1;
                SesUserID = 1;
                SesIntUserLanguage = 1;
                BindDropDowns();
                BindSalesOrder();
                CheckPermission();
                POMenu();
            }
        }
        #endregion

        #region--Customer Menu--
        public void POMenu()
        {
            if (PONum == 0)
            {
                Helper.DisableLinkButton(lnkDelete);
                Helper.DisableLinkButton(lnkPrevious);
                Helper.DisableLinkButton(lnkNext);  
            }
            else
            {
                using (DBEntities db = new DBEntities())
                {
                    var next = (from x in db.POes where x.PONum > PONum orderby x.PONum ascending select x).FirstOrDefault();
                    var prev = (from x in db.POes where x.PONum < PONum orderby x.PONum descending select x).FirstOrDefault();
                    if (next != null)
                    {
                        lnkNext.Attributes.Add("href", Page.ResolveUrl("~") + "ManagePO/PurchaseOrder.aspx?PONum=" + next.PONum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkNext);
                    }
                    if (prev != null)
                    {
                        lnkPrevious.Attributes.Add("href", Page.ResolveUrl("~") + "ManagePO/PurchaseOrder.aspx?PONum=" + prev.PONum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkPrevious);
                    }
                }
            }
            using (DBEntities db = new DBEntities())
            {
                var last = (from x in db.POes orderby x.PONum descending select x).FirstOrDefault();
                var first = (from x in db.POes orderby x.PONum ascending select x).FirstOrDefault();
                if (first != null)
                {
                    lnkFirst.Attributes.Add("href", Page.ResolveUrl("~") + "ManagePO/PurchaseOrder.aspx?PONum=" + first.PONum);

                }
                else
                {
                    Helper.DisableLinkButton(lnkFirst);
                }

                if (last != null)
                {
                    lnkLast.Attributes.Add("href", Page.ResolveUrl("~") + "ManagePO/PurchaseOrder.aspx?PONum=" + last.PONum);
                }
                else
                {
                    Helper.DisableLinkButton(lnkLast);
                }
            }



        }
        #endregion

        #region--Check Permission--
        public void CheckPermission()
        {
            if (SesStrUsersMngRight == "R")
            {
                btnSave.Enabled = false;
                lnkAddNewItem.Enabled = false;
                txtCustomerNote.ReadOnly = true;
                txtInternalNote.ReadOnly = true;
                ddlBillTo.Enabled = false;
                ddlSalesRep.Enabled = false;
                txtCustomerRef.ReadOnly = true;
                ddlShipTo.Enabled = false;
                txtDocumentDate.Enabled = false;
                txtDeliveryDate.Enabled = false;
                ddlLanguage.Enabled = false;
                ddlStatus.Enabled = false;

            }
        }
        #endregion

        #region--Bind DropDown--
        protected void BindDropDowns()
        {
            FilterUserEntity _FilterUserEntity = new FilterUserEntity();
            _FilterUserEntity.Active = true;
            _FilterUserEntity.UserNum = 0;
            _FilterUserEntity.IsManager = null;
            List<p_FilterUsers_Result> _UserList = UserServices.Instance.FilterUsers(_FilterUserEntity);
            var UserQuery = _UserList.Select(p => new { UserId = p.UserNum, DisplayText = p.FirstName + " " + p.LastName });

            ddlSalesRep.AppendDataBoundItems = true;
            ddlSalesRep.DataTextField = "DisplayText";
            ddlSalesRep.DataValueField = "UserId";
            ddlSalesRep.DataSource = UserQuery;
            ddlSalesRep.DataBind();
            ddlSalesRep.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));

            FilterBPEntity _FilterBPEntity = new FilterBPEntity();
            _FilterBPEntity.BPNum = 0;
            _FilterBPEntity.Active = true;
            _FilterBPEntity.OrderBy = "Name";
            _FilterBPEntity.OrderDir = "ASC";
            List<p_FilterBP_Result> _BPList = BPServices.Instance.FilterBP(_FilterBPEntity);
            ddlBillTo.AppendDataBoundItems = true;
            ddlBillTo.DataTextField = "Name";
            ddlBillTo.DataValueField = "BPNum";
            ddlBillTo.DataSource = _BPList;
            ddlBillTo.DataBind();
            ddlBillTo.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));



            ddlShipTo.AppendDataBoundItems = true;
            ddlShipTo.DataTextField = "Name";
            ddlShipTo.DataValueField = "AdressNum";
            ddlShipTo.DataSource = AdressesServices.Instance.GetAdresses(0);
            ddlShipTo.DataBind();
            ddlShipTo.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));


            ddlLanguage.AppendDataBoundItems = true;
            ddlLanguage.DataTextField = "Name";
            ddlLanguage.DataValueField = "LanguageNum";
            ddlLanguage.DataSource = LanguagesServices.Instance.GetAllLanguages();
            ddlLanguage.DataBind();
            ddlLanguage.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));


            ddlItemCode.AppendDataBoundItems = true;
            ddlItemCode.DataTextField = "Code";
            ddlItemCode.DataValueField = "ItemNum";
            ddlItemCode.DataSource = ItemsServices.Instance.GetAllItem();
            ddlItemCode.DataBind();
            ddlItemCode.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));


            ddlTaxGroup.AppendDataBoundItems = true;
            ddlTaxGroup.DataTextField = "Name";
            ddlTaxGroup.DataValueField = "TaxGroupNum";
            ddlTaxGroup.DataSource = TaxGroupServices.Instance.GetAllTaxGroups();
            ddlTaxGroup.DataBind();
            ddlTaxGroup.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));



            ddlItemPackMsr.AppendDataBoundItems = true;
            ddlItemPackMsr.DataTextField = "Description";
            ddlItemPackMsr.DataValueField = "ItemsPackMsrNum";
            ddlItemPackMsr.DataSource = null; //ItemsPackMSRServices.Instance.GetItemsPackMSR()
            ddlItemPackMsr.DataBind();
            ddlItemPackMsr.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));

            ddlStatus.AppendDataBoundItems = true;
            ddlStatus.DataTextField = "Name";
            ddlStatus.DataValueField = "DocSatesNum";
            ddlStatus.DataSource = DocStatesServices.Instance.GetDocStates();
            ddlStatus.DataBind();
            ddlStatus.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));

        }
        #endregion

        #region--Bind Sales Orders--
        public void BindSalesOrder()
        {
            if (PONum > 0)
            {
                FilterPOEntity _FilterPOEntity = new FilterPOEntity();
                _FilterPOEntity.PONum = PONum;
                p_FilterPO_Result _PO = POServices.Instance.FilterPO(_FilterPOEntity).FirstOrDefault();
                lblOrderIdVal.Text = _PO.PONum.ToString();
                if (ddlSalesRep.Items.FindByValue(_PO.UserNum_SalesRep.ToString()) != null)
                {
                    ddlSalesRep.ClearSelection();
                    ddlSalesRep.Items.FindByValue(_PO.UserNum_SalesRep.ToString()).Selected = true;
                }

                if (ddlBillTo.Items.FindByValue(_PO.BPNum.ToString()) != null)
                {
                    ddlBillTo.ClearSelection();
                    ddlBillTo.Items.FindByValue(_PO.BPNum.ToString()).Selected = true;
                }

                txtCustomerRef.Text = _PO.SORef;
                if (ddlShipTo.Items.FindByValue(_PO.AdressNum.ToString()) != null)
                {
                    ddlShipTo.ClearSelection();
                    ddlShipTo.Items.FindByValue(_PO.AdressNum.ToString()).Selected = true;
                }
                txtDocumentDate.Text = _PO.SODate.ToString("dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
                txtDeliveryDate.Text = _PO.SODueDate.ToString("dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);

                if (ddlLanguage.Items.FindByValue(_PO.LanguageNum.ToString()) != null)
                {
                    ddlLanguage.ClearSelection();
                    ddlLanguage.Items.FindByValue(_PO.LanguageNum.ToString()).Selected = true;
                }


                if (ddlStatus.Items.FindByValue(_PO.DocSatesCode.ToString()) != null)
                {
                    ddlStatus.ClearSelection();
                    ddlStatus.Items.FindByValue(_PO.DocSatesCode.ToString()).Selected = true;
                }

                List<PO_L> ItemList = POServices.Instance.GetPO_L(0, PONum);
                List<TempPOItemDetails> TempItemsList = new List<TempPOItemDetails>();
                int j = 0;
                foreach (PO_L item in ItemList)
                {
                    j++;
                    Item tempitemobj = ItemsServices.Instance.GetItem((int)item.ItemNum);
                    TempPOItemDetails _temp = new TempPOItemDetails();
                    _temp.PO_LNum = item.PO_LNum;
                    _temp.SeqNum = j;
                    _temp.ItemNum = (int)item.ItemNum;
                    _temp.ItemType = item.ItemType;
                    _temp.ItemCode = tempitemobj.Code;
                    _temp.Description = item.LineDesc;
                    _temp.ItemsPackMsrNum = (int)item.ItemsPackMsrNum;
                    _temp.Discount = item.Discount == null ? 0 : double.Parse(item.Discount.ToString());
                    _temp.Qty = item.Quantity == null ? 0 : int.Parse(item.Quantity.ToString());
                    _temp.UnitPrice = item.UnitPrice == null ? 0 : double.Parse(item.UnitPrice.ToString());
                    _temp.TaxGroupNum = item.TaxGroupNum;
                    TempItemsList.Add(_temp);
                }

                txtInternalNote.Text = _PO.InternNote;
                txtCustomerNote.Text = _PO.VisibleNote;
                SaveItemHiddenField(TempItemsList);
                BindItems();
            }
        }
        #endregion

        #region--DropDown Bill To Select  Index Change--
        protected void ddlBillTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int _BPID = 0;
            int.TryParse(ddlBillTo.SelectedValue, out _BPID);
            if (_BPID > 0)
            {
                FilterBPEntity _FilterBPEntity = new FilterBPEntity();
                _FilterBPEntity.BPNum = _BPID;
                _FilterBPEntity.Active = true;
                p_FilterBP_Result _BP = BPServices.Instance.FilterBP(_FilterBPEntity).FirstOrDefault();
                if (_BP != null)
                {
                    lblAddressBillTo.Text = (string.IsNullOrEmpty(_BP.Adress1) ? "" : _BP.Adress1) + "<br/>" + _BP.Adress2 + "<br/>" + _BP.City + (string.IsNullOrEmpty(_BP.State) ? "" : "(" + _BP.State + ")") + "<br/>" + _BP.Country + " " + _BP.ZipCode;
                }
                else
                {
                    lblAddressBillTo.Text = "";
                }
            }
        }
        #endregion

        #region-- ddlType SelectedIndexChanged--
        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlType.SelectedValue == "F")
            {
                ddlItemCode.Enabled = false;
                ddlItemCode.ClearSelection();
                ddlItemCode.Items.FindByValue("1").Selected = true;
                txtItemDescription.ReadOnly = false;
            }
            else
            {
                ddlItemCode.Enabled = true;
                ddlItemCode.ClearSelection();
                ddlItemCode.Items.FindByValue("0").Selected = true;
                txtItemDescription.ReadOnly = true;
            }
            ddlItemCode_SelectedIndexChanged(sender, e);
        }
        #endregion

        #region--Add New Item--
        protected void lnkAddNewItem_Click(object sender, EventArgs e)
        {
            // Generate Hidden String like !^#Type%&()ItemNum%&()Description%&()Discount%&()Qty%&()Unit Price%&()UOM%&()Tax!^#
            AddNewItem();
        }
        #endregion

        #region--Create Items String--
        public void AddNewItem()
        {
            TempPOItemDetails _TempPOItemDetails = new TempPOItemDetails();
            int ItemNum = 0;
            int.TryParse(ddlItemCode.SelectedValue, out ItemNum);
            double UnitPrice = 0;
            double.TryParse(txtUnitPrice.Text, out UnitPrice);
            int Qty = 0;
            int.TryParse(txtQty.Text, out Qty);
            double Discount = 0;
            double.TryParse(txtItemDiscount.Text, out Discount);
            int TaxGroupNum = 0;
            int.TryParse(ddlTaxGroup.SelectedValue, out TaxGroupNum);
            int ItemsPackMsrNum = 0;
            int.TryParse(ddlItemPackMsr.SelectedValue, out ItemsPackMsrNum);

            List<TempPOItemDetails> ItemList = ReadItemList();
            _TempPOItemDetails.PO_LNum = 0;
            _TempPOItemDetails.ItemType = ddlType.SelectedValue;
            _TempPOItemDetails.ItemNum = ItemNum;
            _TempPOItemDetails.ItemCode = ddlItemCode.SelectedItem.Text;
            _TempPOItemDetails.Description = txtItemDescription.Text;
            _TempPOItemDetails.Discount = Discount;
            _TempPOItemDetails.Qty = Qty;
            _TempPOItemDetails.UnitPrice = UnitPrice;
            _TempPOItemDetails.ItemsPackMsrNum = ItemsPackMsrNum;
            _TempPOItemDetails.UOM = ddlItemPackMsr.SelectedItem.Text;
            _TempPOItemDetails.TaxGroupNum = TaxGroupNum;
            _TempPOItemDetails.TaxGroupName = ddlTaxGroup.SelectedItem.Text;
            _TempPOItemDetails.SeqNum = ItemList.Count + 1;
            ItemList.Add(_TempPOItemDetails);
            SaveItemHiddenField(ItemList);

            InitializeItems();
            BindItems();
        }
        #endregion

        #region--Bind Items--
        public void BindItems()
        {

            List<TempPOItemDetails> ItemList = ReadItemList();
            rptItemList.DataSource = ItemList;
            rptItemList.DataBind();

            if (ItemList.Count == 0)
            {
                pnlNoItem.Visible = true;
            }
            else
            {
                pnlNoItem.Visible = false;
            }
            lblSubTotalVal.Text = ItemList.Sum(s => s.SubTotal).ToString();
            lblDiscountVal.Text = ItemList.Sum(s => s.Discount).ToString();
            lblGrandTotalVal.Text = ItemList.Sum(s => s.Total).ToString();
        }
        #endregion

        #region--Read Item List--
        public List<TempPOItemDetails> ReadItemList()
        {
            List<TempPOItemDetails> TempItemList = new List<TempPOItemDetails>();
            string complexstr = hdnItems.Value;
            foreach (var item in complexstr.Split(new string[] { RecordSeprationSymbol }, StringSplitOptions.None))
            {
                if (!string.IsNullOrEmpty(item))
                {
                    string[] fields = item.Split(new string[] { FieldSeprationSymbol }, StringSplitOptions.None);
                    TempPOItemDetails temp = new TempPOItemDetails();
                    temp.PO_LNum = int.Parse(fields[0].ToString());
                    temp.SeqNum = int.Parse(fields[1].ToString());
                    temp.ItemType = fields[2].ToString();
                    temp.ItemNum = int.Parse(fields[3].ToString());
                    temp.ItemCode = fields[4].ToString();
                    temp.Description = fields[5].ToString();
                    temp.Discount = double.Parse(fields[6].ToString());
                    temp.Qty = int.Parse(fields[7].ToString());
                    temp.UnitPrice = double.Parse(fields[8].ToString());
                    temp.UOM = fields[9].ToString();
                    temp.ItemsPackMsrNum = int.Parse(fields[10].ToString());
                    temp.TaxGroupNum = int.Parse(fields[11].ToString());
                    temp.TaxGroupName = fields[12].ToString();
                    temp.Total = (temp.Qty * temp.UnitPrice) - ((temp.Qty * temp.UnitPrice) * temp.Discount * .01);
                    temp.SubTotal = (temp.Qty * temp.UnitPrice);
                    TempItemList.Add(temp);
                }
            }
            return TempItemList;
        }
        #endregion

        #region--Save Item to Hidden Field--
        public void SaveItemHiddenField(List<TempPOItemDetails> Items)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in Items)
            {
                sb.Append(item.PO_LNum + FieldSeprationSymbol + item.SeqNum + FieldSeprationSymbol + item.ItemType + FieldSeprationSymbol + item.ItemNum + FieldSeprationSymbol + item.ItemCode + FieldSeprationSymbol + item.Description + FieldSeprationSymbol + item.Discount + FieldSeprationSymbol + item.Qty + FieldSeprationSymbol + item.UnitPrice + FieldSeprationSymbol + item.UOM + FieldSeprationSymbol + item.ItemsPackMsrNum + FieldSeprationSymbol + item.TaxGroupNum + FieldSeprationSymbol + item.TaxGroupName + RecordSeprationSymbol);
            }

            string complexstr = sb.ToString();
            if (complexstr.EndsWith(RecordSeprationSymbol))
            {
                complexstr = complexstr.Substring(0, complexstr.Length - RecordSeprationSymbol.Length);
            }
            hdnItems.Value = complexstr;

        }
        #endregion

        #region--Initialize Item List--
        public void InitializeItems()
        {
            ddlType.ClearSelection();
            ddlType.SelectedIndex = 0;
            ddlItemCode.ClearSelection();
            ddlItemCode.SelectedIndex = 0;
            ddlItemCode.Enabled = true;
            txtItemDescription.Text = "";
            txtItemDescription.ReadOnly = true;
            txtItemDiscount.Text = "";
            txtQty.Text = "";
            txtUnitPrice.Text = "";
            ddlItemPackMsr.ClearSelection();
            ddlItemPackMsr.SelectedIndex = 0;
            ddlTaxGroup.ClearSelection();
            ddlTaxGroup.Items.FindByValue("0").Selected = true;
        }
        #endregion

        #region--rptItemList ItemDataBound --
        protected void rptItemList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                TempPOItemDetails data = (TempPOItemDetails)e.Item.DataItem;
                LinkButton LnkDelete = (LinkButton)e.Item.FindControl("LnkDelete");
                if (LnkDelete != null)
                {
                    LnkDelete.CommandName = "Delete";
                    LnkDelete.CommandArgument = data.SeqNum.ToString();
                }

                LinkButton lnkEdit = (LinkButton)e.Item.FindControl("lnkEdit");
                if (lnkEdit != null)
                {
                    lnkEdit.CommandName = "ItemEdit";
                    lnkEdit.CommandArgument = data.SeqNum.ToString();
                }

                LinkButton lnkSave = (LinkButton)e.Item.FindControl("lnkSave");
                if (lnkSave != null)
                {
                    lnkSave.CommandName = "ItemUpdate";
                    lnkSave.CommandArgument = data.SeqNum.ToString();
                }

            }
        }
        #endregion

        #region rptItemList ItemCommand
        protected void rptItemList_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int SeqNum = int.Parse(e.CommandArgument.ToString());
                List<TempPOItemDetails> Items = ReadItemList();
                TempPOItemDetails temp = Items.Where(i => i.SeqNum == SeqNum).FirstOrDefault();
                if (temp != null)
                {
                    Items.Remove(temp);
                    POServices.Instance.DeletePO_L(temp.PO_LNum);
                }
                int j = 0;

                List<TempPOItemDetails> NewItems = new List<TempPOItemDetails>();
                foreach (var item in Items)
                {
                    j++;
                    item.SeqNum = j;
                    NewItems.Add(item);
                }
                SaveItemHiddenField(NewItems);
                BindItems();
            }

            if (e.CommandName == "ItemEdit")
            {
                Label lblEditDiscount = (Label)e.Item.FindControl("lblEditDiscount");
                lblEditDiscount.Visible = false;

                TextBox txtEditDiscount = (TextBox)e.Item.FindControl("txtEditDiscount");
                txtEditDiscount.Visible = true;

                Label lblEditQty = (Label)e.Item.FindControl("lblEditQty");
                lblEditQty.Visible = false;

                TextBox txtEditQty = (TextBox)e.Item.FindControl("txtEditQty");
                txtEditQty.Visible = true;

                Label lblEditUnitPrice = (Label)e.Item.FindControl("lblEditUnitPrice");
                lblEditUnitPrice.Visible = false;

                TextBox txtUnitPrice = (TextBox)e.Item.FindControl("txtUnitPrice");
                txtUnitPrice.Visible = true;

                LinkButton lnkEdit = (LinkButton)e.Item.FindControl("lnkEdit");
                lnkEdit.Visible = false;

                LinkButton lnkSave = (LinkButton)e.Item.FindControl("lnkSave");
                lnkSave.Visible = true;
            }


            if (e.CommandName == "ItemUpdate")
            {
                int SeqNum = int.Parse(e.CommandArgument.ToString());
                Label lblEditDiscount = (Label)e.Item.FindControl("lblEditDiscount");
                lblEditDiscount.Visible = true;

                TextBox txtEditDiscount = (TextBox)e.Item.FindControl("txtEditDiscount");
                txtEditDiscount.Visible = false;

                Label lblEditQty = (Label)e.Item.FindControl("lblEditQty");
                lblEditQty.Visible = true;

                TextBox txtEditQty = (TextBox)e.Item.FindControl("txtEditQty");
                txtEditQty.Visible = false;

                Label lblEditUnitPrice = (Label)e.Item.FindControl("lblEditUnitPrice");
                lblEditUnitPrice.Visible = true;

                TextBox txtUnitPrice = (TextBox)e.Item.FindControl("txtUnitPrice");
                txtUnitPrice.Visible = false;

                LinkButton lnkEdit = (LinkButton)e.Item.FindControl("lnkEdit");
                lnkEdit.Visible = true;

                LinkButton lnkSave = (LinkButton)e.Item.FindControl("lnkSave");
                lnkSave.Visible = false;

                List<TempPOItemDetails> Items = ReadItemList();
                TempPOItemDetails temp = Items.Where(i => i.SeqNum == SeqNum).FirstOrDefault();
                if (temp != null)
                {
                    double discount = 0;
                    double.TryParse(txtEditDiscount.Text, out discount);

                    int Qty = 0;
                    int.TryParse(txtEditQty.Text, out Qty);

                    double UnitPrice = 0;
                    double.TryParse(txtUnitPrice.Text, out UnitPrice);

                    temp.Discount = discount;
                    temp.Qty = Qty;
                    temp.UnitPrice = UnitPrice;

                }
                SaveItemHiddenField(Items);
                BindItems();
            }
        }
        #endregion

        #region--Save SO--
        protected void btnSave_Click(object sender, EventArgs e)
        {
            int UserNum_SalesRep = 0;
            int.TryParse(ddlSalesRep.SelectedValue, out UserNum_SalesRep);
            int BPNum = 0;
            int.TryParse(ddlBillTo.SelectedValue, out BPNum);

            int AddressNum = 0;
            int.TryParse(ddlShipTo.SelectedValue, out AddressNum);

            int LanguageNum = 0;
            int.TryParse(ddlLanguage.SelectedValue, out LanguageNum);

            int DocSatesNum = 0;
            int.TryParse(ddlStatus.SelectedValue, out DocSatesNum);

            p_FilterPO_Result _PO = new p_FilterPO_Result();
            _PO.PONum = PONum;
            _PO.UserNum_SalesRep = UserNum_SalesRep;
            _PO.BPNum = BPNum;
            _PO.SORef = txtCustomerRef.Text;
            _PO.AdressNum = AddressNum;
            _PO.DocSatesCode = DocSatesNum;
            try
            {
                _PO.SODate = DateTime.ParseExact(txtDocumentDate.Text.Trim(), "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                Helper.ShowMessage(DivMsg, "Please Input valid Document Date.", false);
                return;
            }

            try
            {
                _PO.SODueDate = DateTime.ParseExact(txtDeliveryDate.Text.Trim(), "dd'/'MM'/'yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                Helper.ShowMessage(DivMsg, "Please Input valid Delivery Date.", false);
                return;
            }

            _PO.LanguageNum = LanguageNum;
            _PO.InternNote = txtInternalNote.Text;
            _PO.VisibleNote = txtCustomerNote.Text;

            double _SubTotal = 0;
            double.TryParse(lblSubTotalVal.Text, out _SubTotal);

            double _Total = 0;
            double.TryParse(lblGrandTotalVal.Text, out _Total);

            double _Discount = 0;
            double.TryParse(lblDiscountVal.Text, out _Discount);

            double _Taxes = 0;
            double.TryParse(lblTaxesVal.Text, out _Taxes);

            _PO.SOSubTotal = _SubTotal;
            _PO.SOTotal = _Total;
            _PO.SOTaxTotal = _Taxes;
            _PO.SODiscountTotal = _Discount;

            bool flag = POServices.Instance.SavePO(_PO);
            if (flag)
            {

                List<TempPOItemDetails> ItemDetails = ReadItemList();
                foreach (var item in ItemDetails)
                {
                    PO_L temp = new PO_L();
                    temp.PO_LNum = item.PO_LNum;
                    temp.PONum = _PO.PONum;
                    temp.ItemNum = item.ItemNum;
                    temp.ItemType = item.ItemType;
                    temp.LineDesc = item.Description;
                    temp.Discount = item.Discount;
                    temp.Quantity = item.Qty;
                    temp.UnitPrice = item.UnitPrice;
                    temp.ItemsPackMsrNum = item.ItemsPackMsrNum;
                    temp.UnitPrice = item.UnitPrice;
                    temp.TaxGroupNum = item.TaxGroupNum;
                    temp.TaxNum_1 = 0;
                    temp.TaxNum_2 = 0;
                    temp.LineTotal = item.Total;
                    temp.DocSatesNum = DocSatesNum;
                    POServices.Instance.SavePO_L(temp);
                }
                Helper.ShowMessage(DivMsg, "Purchase Order Details Successfully Saved.", false);
                Response.Redirect("~/ManagePO/PurchaseOrder.aspx?msg=1");
            }
            else
            {
                Helper.ShowMessage(DivMsg, "Unable to save Sale Order Details.", false);
            }


        }
        #endregion

        #region--ddlItemCode SelectedIndexChanged--
        protected void ddlItemCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ItemNum = 0;
            int.TryParse(ddlItemCode.SelectedValue, out ItemNum);

            if (ItemNum > 0)
            {
                ddlItemPackMsr.ClearSelection();
                ddlItemPackMsr.Items.Clear();
                ddlItemPackMsr.AppendDataBoundItems = true;
                ddlItemPackMsr.DataTextField = "Description";
                ddlItemPackMsr.DataValueField = "ItemsPackMsrNum";
                ddlItemPackMsr.DataSource = ItemsPackMSRServices.Instance.GetItemsPackMsrForItem(ItemNum);
                ddlItemPackMsr.DataBind();
                ddlItemPackMsr.Items.Insert(0, (new ListItem() { Value = "0", Text = "Select" }));
            }
        }
        #endregion

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ManagePO/PurchaseOrder.aspx");
        }
    }
}

public class TempPOItemDetails
{
    public int PO_LNum { get; set; }
    public int SeqNum { get; set; }
    public string ItemType { get; set; }
    public int ItemNum { get; set; }
    public string ItemCode { get; set; }
    public string Description { get; set; }
    public double Discount { get; set; }
    public int Qty { get; set; }
    public double UnitPrice { get; set; }
    public string UOM { get; set; }
    public int ItemsPackMsrNum { get; set; }
    public int TaxGroupNum { get; set; }
    public string TaxGroupName { get; set; }
    public double SubTotal { get; set; }
    public double Total { get; set; }
}