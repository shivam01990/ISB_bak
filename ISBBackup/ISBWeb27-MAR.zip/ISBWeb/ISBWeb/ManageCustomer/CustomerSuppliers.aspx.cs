﻿using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL;

namespace ISBWeb.ManageCustomer
{
    public partial class CustomerSuppliers : System.Web.UI.Page
    {
        #region ---Declaration---
        protected int PageSize = 25;
        public SortDirection Sortdir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Descending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCustomers();
            }
        }

        #region ---Bind Customers---
        public void BindCustomers()
        {
            FilterBPEntity _FilterBPEntity = new FilterBPEntity();
            _FilterBPEntity.BPNum = 0;
            _FilterBPEntity.GlobalCustomerNum = 0;
            _FilterBPEntity.Name = txtName.Text;
            _FilterBPEntity.Code = txtCode.Text;
            _FilterBPEntity.City = txtCity.Text;
            _FilterBPEntity.State = txtState.Text;
            _FilterBPEntity.ZipCode = txtZipCode.Text;
            _FilterBPEntity.Email = txtEmail.Text;
            if (ddlActive.SelectedValue != "0")
            {
                _FilterBPEntity.Active = bool.Parse(ddlActive.SelectedValue);
            }
            else
            {
                _FilterBPEntity.Active = null;
            }

            _FilterBPEntity.OrderBy = HdnOrderBy.Value;
            _FilterBPEntity.OrderDir = Sortdir == SortDirection.Ascending ? "ASC" : "DESC";
            _FilterBPEntity.PageNumber = int.Parse(HdnPageNo.Value) + 1;
            _FilterBPEntity.PageSize = PageSize;
            GrdCustomers.PageSize = PageSize;
            List<p_FilterBP_Result> OfferList = BPServices.Instance.FilterBP(_FilterBPEntity);

            if (OfferList != null && OfferList.Count > 0)
            {
                GrdCustomers.VirtualItemCount = OfferList[0].TotalRecords.Value;
            }
            else
            {
                GrdCustomers.VirtualItemCount = 0;
            }

            GrdCustomers.PageIndex = int.Parse(HdnPageNo.Value);
            GrdCustomers.DataSource = OfferList;
            GrdCustomers.DataBind();
        }
        #endregion


        #region ---Grid Methods---
        protected void GrdCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                //if (Offers.Instance.DeleteOffer(int.Parse(e.CommandArgument.ToString())))
                //{
                //    Common.ShowMessage(DivMsg, "Offer successfully deleted", Page.ResolveUrl("~"), true);
                //    BindOffers();
                //}
                //else
                //{
                //    Common.ShowMessage(DivMsg, "Unable to delete Offer", Page.ResolveUrl("~"), true);
                //}
            }
        }
        protected void GrdCustomers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    sp_GetOfferList_Result data = (sp_GetOfferList_Result)e.Row.DataItem;
            //    LinkButton LnkDelete = (LinkButton)e.Row.FindControl("LnkDelete");
            //    if (LnkDelete != null)
            //    {
            //        LnkDelete.CommandName = "Delete";
            //        LnkDelete.CommandArgument = data.OfferID.ToString();
            //        LnkDelete.Attributes.Add("onclick", "return ConfirmBoxWithPostBack('Are you sure to delete this Offer?','" + LnkDelete.UniqueID + "');");
            //    }
            //}
        }
        protected void GrdCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            HdnPageNo.Value = e.NewPageIndex.ToString();
            BindCustomers();
        }
        protected void GrdCustomers_Sorting(object sender, GridViewSortEventArgs e)
        {

            if (Sortdir == SortDirection.Ascending)
            {
                Sortdir = SortDirection.Descending;
            }
            else
            {
                Sortdir = SortDirection.Ascending;
            }
            HdnOrderBy.Value = e.SortExpression.ToString();
            BindCustomers();
        }
        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindCustomers();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtCode.Text = "";
            txtCode.Text = "";
            txtState.Text = "";
            txtZipCode.Text = "";
            ddlActive.ClearSelection();
            ddlActive.Items.FindByValue("0").Selected = true;
            txtEmail.Text = "";
            BindCustomers();
        }


    }
}