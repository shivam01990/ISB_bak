﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using System.IO;
using BLL;

namespace ISBWeb.ManageCustomer
{
    public partial class CustomerSupplier : System.Web.UI.Page
    {
        #region Variables Decleration
        int IntGlobalCustomerNum;
        int IntUserLanguage;
        string StrCustomerMngRight;
        int UserID;
        int IntEditBPNum;
        int PageSize = 10;

        #endregion

        #region "PageLoad"
        protected void Page_Load(object sender, EventArgs e)
        {
            #region "Assigning Session Varibales for Development purpose"
            Session["SesIntUserLanguage"] = 1; //User Language
            Session["SesStrCustomerMngRight"] = "RW"; //Read mode
            Session["SesUserID"] = 1; // User ID
            Session["SesGlobalCustomerNum"] = 1; //Global Custometr Number
            Session["SesIntResultsPerSearch"] = 10; //Number of Records per search            
            #endregion

            #region "Get the values of the Session Varibale"
            IntGlobalCustomerNum = Convert.ToInt32(Session["SesGlobalCustomerNum"]);
            IntUserLanguage = Convert.ToInt32(Session["SesIntUserLanguage"]);
            UserID = Convert.ToInt32(Session["SesUserID"]);
            StrCustomerMngRight = Session["SesStrCustomerMngRight"].ToString();
            IntEditBPNum = Convert.ToInt32(Session["SesEditBPNum"]);
            PageSize = Convert.ToInt32(Session["SesIntResultsPerSearch"]);

            #endregion

            if (!Page.IsPostBack)
            {
                LoadVocabulary(IntUserLanguage);
                PopulateDropdownListAll();
                LoadGeneralSettings(IntGlobalCustomerNum, IntUserLanguage);

                #region "If IntEditBPNum> 0 , it will assume as edit mode"

                if (Request.QueryString["BPNum"] != null)
                {
                    int.TryParse(Request.QueryString["BPNum"].ToString(), out IntEditBPNum);
                    if (IntEditBPNum > 0)
                    {
                        Session["SesEditBPNum"] = IntEditBPNum.ToString();
                        hdnBpNum.Value = IntEditBPNum.ToString();
                        GetCustomerData(IntEditBPNum);
                        btnSave.Text = "Edit";
                    }
                }
              #endregion


                if (StrCustomerMngRight == "R")
                {
                    DisableControls(Page, false);
                    btnClose.Enabled = true;
                    chkActive.Enabled = false;

                }

                CustomerMenu();
              
                
            }
        }
        #endregion

        #region--Customer Menu--
        public void CustomerMenu()
        {
            if (IntEditBPNum == 0)
            {
                Helper.DisableLinkButton(lnkDelete);
                Helper.DisableLinkButton(lnkPrevious);
                Helper.DisableLinkButton(lnkNext);  
            }
            else
            {
                using (DBEntities db = new DBEntities())
                {
                    var next = (from x in db.BPs where x.BPNum > IntEditBPNum && x.Active == true orderby x.BPNum ascending select x).FirstOrDefault();
                    var prev = (from x in db.BPs where x.BPNum < IntEditBPNum && x.Active == true orderby x.BPNum descending select x).FirstOrDefault();
                    if (next != null)
                    {
                        lnkNext.Attributes.Add("href", Page.ResolveUrl("~") + "ManageCustomer/CustomerSupplier.aspx?BPNum=" + next.BPNum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkNext);
                    }
                    if (prev != null)
                    {
                        lnkPrevious.Attributes.Add("href", Page.ResolveUrl("~") + "ManageCustomer/CustomerSupplier.aspx?BPNum=" + prev.BPNum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkPrevious);
                    }
                }
            }
                using (DBEntities db = new DBEntities())
                {
                    var last = (from x in db.BPs where x.Active == true orderby x.BPNum descending select x).FirstOrDefault();
                    var first = (from x in db.BPs where x.Active == true orderby x.BPNum ascending select x).FirstOrDefault();
                    if (first != null)
                    {
                        lnkFirst.Attributes.Add("href", Page.ResolveUrl("~") + "ManageCustomer/CustomerSupplier.aspx?BPNum=" + first.BPNum);

                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkFirst);
                    }
                    if (last != null)
                    {
                        lnkLast.Attributes.Add("href", Page.ResolveUrl("~") + "ManageCustomer/CustomerSupplier.aspx?BPNum=" + last.BPNum);
                    }
                    else
                    {
                        Helper.DisableLinkButton(lnkLast);
                    }
                }


            
        }
        #endregion

        //********************************************************* 
        //Purpose:      Upload the image into server path. 
        //*********************************************************
        private void UploadLogo()
        {
            if (fuLogo.HasFile)
            {
                try
                {
                    string StrLogoName;
                    if (fuLogo.PostedFile.ContentLength < 2100000)
                    {
                        if (IntEditBPNum == 0)
                        {
                            StrLogoName = CustomerServices.Instance.GetMaxBPNum().ToString();
                            fuLogo.SaveAs(Server.MapPath("~/LogoDB//") + StrLogoName + Path.GetExtension(fuLogo.FileName.ToString()));
                            hdnFileName.Value = @"~/LogoDB/" + StrLogoName + Path.GetExtension(fuLogo.FileName.ToString());
                        }
                        else
                        {

                            fuLogo.SaveAs(Server.MapPath("~/LogoDB//") + IntEditBPNum + Path.GetExtension(fuLogo.FileName.ToString()));
                            hdnFileName.Value = @"~/LogoDB/" + IntEditBPNum + ".jpg";
                        }
                        // imgLogo.ImageUrl = hdnFileName.Value;
                    }
                    else
                    {
                        Helper.ShowMessage(msgDiv, EndUserTextServices.Instance.LoadEndUserText(4, IntUserLanguage), true);
                    }
                }
                catch (Exception)
                {

                }
            }

            else if (hdnNewFile.Value == "1")
            {
                hdnFileName.Value = @"~/LogoDB/" + IntEditBPNum + ".jpg";
            }
        }

        //********************************************************* 
        //Purpose:      Load the vocubulary details of each label control. 
        //Inputs:       IntUserLanguage : User Language of the current user
        //*********************************************************
        private void LoadVocabulary(int IntUserLanguage)
        {
            lblName.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(1, IntUserLanguage);
            lblAddress1.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(2, IntUserLanguage);
            lblAddress2.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(3, IntUserLanguage);
            lblCity.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(4, IntUserLanguage);
            lblState.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(5, IntUserLanguage);
            lblZipCode.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(6, IntUserLanguage);
            lblCountry.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(7, IntUserLanguage);
            lblCreditLimit.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(8, IntUserLanguage);
            lblUploadLogo.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(10, IntUserLanguage);
            lblInternalNote.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(11, IntUserLanguage);
            lblActive.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(12, IntUserLanguage);
            lblCode.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(13, IntUserLanguage);
            lblGlobalCategories.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(14, IntUserLanguage);
            lblBusinessCategories.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(15, IntUserLanguage);
            lblEmail.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(16, IntUserLanguage);
            lblWebsite.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(17, IntUserLanguage);
            lblFacebook.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(18, IntUserLanguage);
            lblTaxGroups.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(19, IntUserLanguage);
            lblCurrencies.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(20, IntUserLanguage);
            lblPaymentTerms.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(21, IntUserLanguage);
            lblOrderNote.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(22, IntUserLanguage);
            lblRatingValues.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(23, IntUserLanguage);
            lblCustomeField.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(24, IntUserLanguage);
            lblCustomValue.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(25, IntUserLanguage);
            hdnDropdownValue.Value = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(26, IntUserLanguage);

            //lblNameSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(1, IntUserLanguage);
            //lblCitySearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(4, IntUserLanguage);
            //lblStateSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(5, IntUserLanguage);
            //lblZipCodeSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(6, IntUserLanguage);
            //lblInternalNoteSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(11, IntUserLanguage);
            //lblActive.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(12, IntUserLanguage);
            //lblCodeSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(13, IntUserLanguage);
            //lblGlobalCategoriesSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(14, IntUserLanguage);
            //lblBusinessCategoriesSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(15, IntUserLanguage);
            //lblEmailSearch.Text = VocabularyDisplayServices.Instance.LoadVocabularyDisplay(16, IntUserLanguage);

        }

        //********************************************************* 
        //Purpose:      Load all the drpdwonlist values from the database. 
        //*********************************************************
        private void PopulateDropdownListAll()
        {
            ddlBusinessCategories.DataTextField = "Name";
            ddlBusinessCategories.DataValueField = "BusinessCategoryNum";
            ddlBusinessCategories.DataSource = BusinessCategoryServices.Instance.GetBusinessCategories();
            ddlBusinessCategories.DataBind();
            ddlBusinessCategories.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));

            ddlGlobalCategories.DataTextField = "Name";
            ddlGlobalCategories.DataValueField = "GlobalCategoryNum";
            ddlGlobalCategories.DataSource = GlobalCategoryServices.Instance.GetGlobalCategories();
            ddlGlobalCategories.DataBind();
            ddlGlobalCategories.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));

            ddlPaymentTerms.DataTextField = "Name";
            ddlPaymentTerms.DataValueField = "PaymentTermNum";
            ddlPaymentTerms.DataSource = PaymentTermsServices.Instance.GetPaymentTerms();
            ddlPaymentTerms.DataBind();
            ddlPaymentTerms.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));

            ddlCurrencies.DataTextField = "Name";
            ddlCurrencies.DataValueField = "CurrencyNum";
            ddlCurrencies.DataSource = CurrencyServices.Instance.GetCurrencies();
            ddlCurrencies.DataBind();
            ddlCurrencies.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));

            ddlRatingValues.DataTextField = "Name";
            ddlRatingValues.DataValueField = "RatingValueNum";
            ddlRatingValues.DataSource = RatingValuesServices.Instance.GetRatingValues();
            ddlRatingValues.DataBind();
            ddlRatingValues.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));


            ddlTaxGroups.DataTextField = "Name";
            ddlTaxGroups.DataValueField = "TaxGroupNum";
            ddlTaxGroups.DataSource = TaxGroupServices.Instance.GetAllTaxGroups();
            ddlTaxGroups.DataBind();
            ddlTaxGroups.Items.Insert(0, new ListItem(hdnDropdownValue.Value, "0"));

           

        }
        //********************************************************* 
        //Purpose:      Load the General settings from tne database. 
        //Inputs:       IntGlobalCustomerNum : Global customer Number of the current user
        //              IntUserLanguage : User Language of the current user
        //*********************************************************
        private void LoadGeneralSettings(int IntGlobalCustomerNum, int IntUserLanguage)
        {
            var objGeneralSetting = GeneralSettingServices.Instance.LoadGeneralSettings(IntGlobalCustomerNum, IntUserLanguage);
            if (objGeneralSetting != null)
            {
                row1.Visible = objGeneralSetting.CustomFieldVis1.Value;
                row2.Visible = objGeneralSetting.CustomFieldVis2.Value;
                row3.Visible = objGeneralSetting.CustomFieldVis3.Value;
                row4.Visible = objGeneralSetting.CustomFieldVis4.Value;
                row5.Visible = objGeneralSetting.CustomFieldVis5.Value;
                row6.Visible = objGeneralSetting.CustomFieldVis6.Value;
                row7.Visible = objGeneralSetting.CustomFieldVis7.Value;
                row8.Visible = objGeneralSetting.CustomFieldVis8.Value;
            }
        }

        #region Save event
        protected void btnSave_Click(object sender, EventArgs e)
        {
            IntEditBPNum = Convert.ToInt32(Session["SesEditBPNum"]);
            if (IntEditBPNum > 0)
            {
                SaveCustomer(true);
            }
            else
            {
                SaveCustomer(false);
            }
        }
        #endregion

        //********************************************************* 
        //Purpose:      Load the Custome Data using BPnumber and populate the values in all input controls. 
        //Inputs:       IntBPNumber :  the value of the BP numer.    
        //*********************************************************
        private void GetCustomerData(int IntBPNumber)
        {
            try
            {
                var objBP = CustomerServices.Instance.GetCustomer(IntBPNumber);
                if (objBP != null)
                {

                    txtName.Text = objBP.Name;
                    txtCode.Text = objBP.Code;
                    txtAddress1.Text = objBP.Adress1;
                    txtAddress2.Text = objBP.Adress2;
                    txtCity.Text = objBP.City;
                    txtCountry.Text = objBP.Country;
                    txtState.Text = objBP.State;
                    txtZipCode.Text = objBP.ZipCode;
                    txtFacebook.Text = objBP.FaceBook;
                    txtEmail.Text = objBP.Email;
                    txtWebsite.Text = objBP.WebSite;
                    txtInternalNote.Text = objBP.InternNote;
                    txtOrderNote.Text = objBP.OrderNote;
                    txtBalance.Text = objBP.Balance.ToString();
                    txtTotalCredit.Text = objBP.TotalCredit.ToString();
                    if (!string.IsNullOrEmpty(objBP.LogoPath))
                    {
                        imgLogo.ImageUrl = @objBP.LogoPath;
                        hdnNewFile.Value = "1";
                    }
                    else
                    {
                        imgLogo.ImageUrl = "~/images/no_image.png";
                    }


                    ddlBusinessCategories.SelectedValue = null;
                    if (objBP.BusinessCategoryNum != null) ddlBusinessCategories.Items.FindByValue(objBP.BusinessCategoryNum.ToString()).Selected = true;
                    ddlGlobalCategories.SelectedValue = null;
                    if (objBP.GlobalCategoryNum != null) ddlGlobalCategories.Items.FindByValue(objBP.GlobalCategoryNum.ToString()).Selected = true;
                    ddlTaxGroups.SelectedValue = null;
                    if (objBP.TaxGroupNum != null) ddlTaxGroups.Items.FindByValue(objBP.TaxGroupNum.ToString()).Selected = true;
                    ddlCurrencies.SelectedValue = null;
                    if (objBP.CurrencyNum != null) ddlCurrencies.Items.FindByValue(objBP.CurrencyNum.ToString()).Selected = true;
                    ddlPaymentTerms.SelectedValue = null;
                    if (objBP.PaymentTermsNum != null) ddlPaymentTerms.Items.FindByValue(objBP.PaymentTermsNum.ToString()).Selected = true;
                    ddlRatingValues.SelectedValue = null;
                    if (objBP.RatingValueNum != null) ddlRatingValues.Items.FindByValue(objBP.RatingValueNum.ToString()).Selected = true;
                    chkActive.Checked = objBP.Active.Value;
                    row1.Visible = objBP.CustomField1Vis.Value;
                    row2.Visible = objBP.CustomField2Vis.Value;
                    row3.Visible = objBP.CustomField3Vis.Value;
                    row4.Visible = objBP.CustomField4Vis.Value;
                    row5.Visible = objBP.CustomField5Vis.Value;
                    row6.Visible = objBP.CustomField6Vis.Value;
                    row7.Visible = objBP.CustomField7Vis.Value;
                    row8.Visible = objBP.CustomField8Vis.Value;
                    lblField1.Text = objBP.CustomField1Name;
                    txtField1.Text = objBP.CustomField1Value;
                    lblField2.Text = objBP.CustomField2Name;
                    txtField2.Text = objBP.CustomField3Value;
                    lblField3.Text = objBP.CustomField3Name;
                    txtField3.Text = objBP.CustomField3Value;
                    lblField4.Text = objBP.CustomField4Name;
                    txtField4.Text = objBP.CustomField4Value;
                    lblField5.Text = objBP.CustomField5Name;
                    txtField5.Text = objBP.CustomField5Value;
                    lblField6.Text = objBP.CustomField6Name;
                    txtField6.Text = objBP.CustomField6Value;
                    lblField7.Text = objBP.CustomField7Name;
                    txtField7.Text = objBP.CustomField7Value;
                    lblField8.Text = objBP.CustomField8Name;
                    txtField8.Text = objBP.CustomField8Value;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //********************************************************* 
        //Purpose:      Save or update the BP data into DB. 
        //Inputs:       blnUpdate: it will check the value is true or false to make update/save
        //*********************************************************
        private void SaveCustomer(bool isUpdate)
        {
            try
            {
                string StrMessage = string.Empty;

                UploadLogo();
                var objBP = new BPEntity()
                {
                    BPNum = Convert.ToInt32(hdnBpNum.Value),
                    GlobalCustomerNum = Convert.ToInt32(Session["SesGlobalCustomerNum"]),
                    Name = txtName.Text,
                    Code = txtCode.Text,
                    Adress1 = txtAddress1.Text,
                    Adress2 = txtAddress2.Text,
                    City = txtCity.Text,
                    State = txtState.Text,
                    ZipCode = txtZipCode.Text,
                    Country = txtCountry.Text,
                    GlobalCategoryNum = ddlGlobalCategories.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlGlobalCategories.SelectedItem.Value) : null,
                    BusinessCategoryNum = ddlBusinessCategories.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlBusinessCategories.SelectedItem.Value) : null,
                    Email = txtEmail.Text,
                    WebSite = txtWebsite.Text,
                    FaceBook = txtFacebook.Text,
                    TaxGroupNum = ddlTaxGroups.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlTaxGroups.SelectedItem.Value) : null,
                    CurrencyNum = ddlCurrencies.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlCurrencies.SelectedItem.Value) : null,
                    Balance = Convert.ToDouble(txtBalance.Text),
                    TotalCredit = Convert.ToDouble(txtTotalCredit.Text),
                    LogoPath = hdnFileName.Value,
                    PaymentTermsNum = ddlPaymentTerms.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlPaymentTerms.SelectedItem.Value) : null,
                    InternNote = txtInternalNote.Text,
                    OrderNote = txtOrderNote.Text,
                    Active = chkActive.Checked,
                    RatingValueNum = ddlRatingValues.SelectedItem.Value != "0" ? (int?)Convert.ToInt32(ddlRatingValues.SelectedItem.Value) : null,

                    CustomField1Vis = txtField1.Visible,
                    CustomField2Vis = txtField2.Visible,
                    CustomField3Vis = txtField3.Visible,
                    CustomField4Vis = txtField4.Visible,
                    CustomField5Vis = txtField5.Visible,
                    CustomField6Vis = txtField6.Visible,
                    CustomField7Vis = txtField7.Visible,
                    CustomField8Vis = txtField8.Visible,

                    CustomField1Name = lblField1.Text,
                    CustomField2Name = lblField2.Text,
                    CustomField3Name = lblField3.Text,
                    CustomField4Name = lblField4.Text,
                    CustomField5Name = lblField5.Text,
                    CustomField6Name = lblField6.Text,
                    CustomField7Name = lblField7.Text,
                    CustomField8Name = lblField8.Text,

                    CustomField1Value = txtField1.Text,
                    CustomField2Value = txtField2.Text,
                    CustomField3Value = txtField3.Text,
                    CustomField4Value = txtField4.Text,
                    CustomField5Value = txtField5.Text,
                    CustomField6Value = txtField6.Text,
                    CustomField7Value = txtField7.Text,
                    CustomField8Value = txtField8.Text,
                };

                bool blnIsSuccess = false;
                StrMessage = CustomerServices.Instance.SaveCustomer(objBP, isUpdate, UserID, IntUserLanguage, out blnIsSuccess);
                Helper.ShowMessage(msgDiv, StrMessage, blnIsSuccess);

            }
            catch (Exception)
            {
                throw;
            }
        }

        //********************************************************* 
        //Purpose:      Disable all the controls based on state value . 
        //Inputs:       parent: t pass the parent control object
        //              state: boolean value to decide enable/disabled
        //*********************************************************
        protected void DisableControls(Control parent, bool State)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is DropDownList || c is TextBox || c is FileUpload || c is Button)
                {
                    ((WebControl)(c)).Enabled = State;
                }

                DisableControls(c, State);
            }
        }



        #region "Search functionality"

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {

                GetCustomer();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void GetCustomer(int PageIndex = 1)
        {
            var SearchParameters = new BPEntitySearch()
            {
                //Name = !String.IsNullOrEmpty(txtNameSearch.Text) ? txtNameSearch.Text : null,
                //Code = !String.IsNullOrEmpty(txtCodeSearch.Text) ? txtCodeSearch.Text : null,
                //City = !String.IsNullOrEmpty(txtCitySearch.Text) ? txtCitySearch.Text : null,
                //State = !String.IsNullOrEmpty(txtStateSearch.Text) ? txtStateSearch.Text : null,
                //ZipCode = !String.IsNullOrEmpty(txtZipCodeSearch.Text) ? txtZipCodeSearch.Text : null,
                //InternalNote = !String.IsNullOrEmpty(txtInternalNoteSearch.Text) ? txtInternalNoteSearch.Text : null,
                //Email = !String.IsNullOrEmpty(txtEmailSearch.Text) ? txtEmailSearch.Text : null,
                //GlobalCategoryNum = Convert.ToInt32(ddlGlobalCategoriesSearch.SelectedItem.Value),
                //BusinessCategoryNum = Convert.ToInt32(ddlBusinessCategoriesSearch.SelectedItem.Value),
                //IsActive = Convert.ToBoolean(chkActiveSearch.Checked),
                RecordsPerPage = 10,
                Page = PageIndex
            };

            var listCustomers = CustomerServices.Instance.SearchCustomer(SearchParameters);
            if (listCustomers != null && listCustomers.Count() > 0)
            {
                //   rptPager.Visible = true;

                //    if (!chkShowPictures.Checked)
                //    {
                //        dlCustomerSearch.Visible = false;
                //        gvCustomerSearch.Visible = true;
                //        gvCustomerSearch.DataSource = listCustomers;
                //        gvCustomerSearch.DataBind();
                //        gvCustomerSearch.EmptyDataText = "No records found";
                //    }
                //    else
                //    {
                //        gvCustomerSearch.Visible = false;
                //        dlCustomerSearch.Visible = true;
                //        dlCustomerSearch.DataSource = listCustomers;
                //        dlCustomerSearch.DataBind();
                //    }

                //    this.PopulatePager(listCustomers[0].TotalRecords, PageIndex);
                //}

                //else
                //{
                //    dlCustomerSearch.DataSource = null;
                //    dlCustomerSearch.DataBind();
                //    gvCustomerSearch.DataSource = null;
                //    gvCustomerSearch.DataBind();
                //    this.PopulatePager(0, PageIndex);
                //    // rptPager.Visible = false;


                //}

            }
        }

        private void PopulatePager(int recordCount, int currentPage)
        {
            List<ListItem> pages = new List<ListItem>();
            int startIndex, endIndex;
            int pagerSpan = 5;

            //Calculate the Start and End Index of pages to be displayed.
            double dblPageCount = (double)((decimal)recordCount / Convert.ToDecimal(PageSize));
            int pageCount = (int)Math.Ceiling(dblPageCount);
            startIndex = currentPage > 1 && currentPage + pagerSpan - 1 < pagerSpan ? currentPage : 1;
            endIndex = pageCount > pagerSpan ? pagerSpan : pageCount;
            if (currentPage > pagerSpan % 2)
            {
                if (currentPage == 2)
                {
                    endIndex = 5;
                }
                else
                {
                    endIndex = currentPage + 2;
                }
            }
            else
            {
                endIndex = (pagerSpan - currentPage) + 1;
            }

            if (endIndex - (pagerSpan - 1) > startIndex)
            {
                startIndex = endIndex - (pagerSpan - 1);
            }

            if (endIndex > pageCount)
            {
                endIndex = pageCount;
                startIndex = ((endIndex - pagerSpan) + 1) > 0 ? (endIndex - pagerSpan) + 1 : 1;
            }

            //Add the First Page Button.
            if (currentPage > 1)
            {
                pages.Add(new ListItem("First", "1"));
            }

            //Add the Previous Button.
            if (currentPage > 1)
            {
                pages.Add(new ListItem("<<", (currentPage - 1).ToString()));
            }

            for (int i = startIndex; i <= endIndex; i++)
            {
                pages.Add(new ListItem(i.ToString(), i.ToString(), i != currentPage));
            }

            //Add the Next Button.
            if (currentPage < pageCount)
            {
                pages.Add(new ListItem(">>", (currentPage + 1).ToString()));
            }

            //Add the Last Button.
            if (currentPage != pageCount)
            {
                pages.Add(new ListItem("Last", pageCount.ToString()));
            }
            //rptPager.DataSource = pages;
            //rptPager.DataBind();
        }

        protected void Page_Changed(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as Button).CommandArgument);
            this.GetCustomer(pageIndex);
        }

        protected void btnResest_Click(object sender, EventArgs e)
        {
            ClearSearch();

        }

        private void ClearSearch()
        {
            //txtNameSearch.Text = "";
            //txtCodeSearch.Text = "";
            //txtCitySearch.Text = "";
            //txtStateSearch.Text = "";
            //txtZipCodeSearch.Text = "";
            //txtInternalNoteSearch.Text = "";
            //txtEmailSearch.Text = "";
            //ddlGlobalCategoriesSearch.SelectedValue = null;
            //ddlBusinessCategoriesSearch.SelectedValue = null;
            //chkActiveSearch.Checked = true;
            //chkShowPictures.Checked = false;

            //dlCustomerSearch.Visible = false;
            //gvCustomerSearch.Visible = false;
            //gvCustomerSearch.DataSource = null;
            //gvCustomerSearch.DataBind();
            //dlCustomerSearch.DataSource = null;
            //dlCustomerSearch.DataBind();
        }

        protected void gvCustomerSearch_Unload(object sender, EventArgs e)
        {

        }

        public SortDirection direction
        {
            get
            {
                if (ViewState["directionState"] == null)
                {
                    ViewState["directionState"] = SortDirection.Ascending;
                }
                return (SortDirection)ViewState["directionState"];
            }
            set
            {
                ViewState["directionState"] = value;
            }
        }

        protected void gvCustomerSearch_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortingDirection = string.Empty;
            if (direction == SortDirection.Ascending)
            {
                direction = SortDirection.Descending;
                sortingDirection = "Desc";

            }
            else
            {
                direction = SortDirection.Ascending;
                sortingDirection = "Asc";

            }
            //    DataView sortedView = new DataView();
            //    sortedView.Sort = e.SortExpression + " " + sortingDirection;
            //    Session["SortedView"] = sortedView;
            //    gvCustomerSearch.DataSource = sortedView;
            //    gvCustomerSearch.DataBind(); 
        }


        #endregion

        protected void dlCustomerSearch_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "link")
            {
                int BpNum;
                Label hdnBpnum = (Label)e.Item.FindControl("hdnBpNum");
                BpNum = Convert.ToInt32(hdnBpnum.Text);
                Response.Redirect("VendorSupplier.aspx?BPNum=" + BpNum);
            }
        }

        protected void gvCustomerSearch_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "link")
            {

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), UniqueID, "$('#dialog').dialog('close');", true);
                int BpNum;
                BpNum = Convert.ToInt32(e.CommandArgument.ToString());
                Response.Redirect("VendorSupplier.aspx?BPNum=" + BpNum);
            }
        }
    }
}