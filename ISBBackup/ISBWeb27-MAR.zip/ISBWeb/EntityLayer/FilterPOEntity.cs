﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
   public class FilterPOEntity
    {
        #region--Private Properties--
        private int _PONum = 0;
        private int _GlobalCustomerNum = 0;
        private int _UserNum_SalesRep = 0;
        private int _AdressNum = 0;
        private int _DocSatesCode = 0;
        private string _BPCode = "";
        private string _SORef = "";
        private DateTime? _SOStartDate = null;
        private DateTime? _SOEndDate = null;
        private DateTime? _SODueDateStartDate = null;
        private DateTime? _SODueDateEndDate = null;
        private string _OrderBy = "SODate";
        private string _OrderDir = "ASC";
        private int _PageNumber = 0;
        private int _PageSize = 0;
        #endregion

        #region--Public Properties--
        public int PONum
        {
            get
            {
                return _PONum;
            }
            set
            {
                _PONum = value;
            }
        }

        public int GlobalCustomerNum
        {
            get
            {
                return _GlobalCustomerNum;
            }
            set
            {
                _GlobalCustomerNum = value;
            }
        }

        public int UserNum_SalesRep
        {
            get
            {
                return _UserNum_SalesRep;
            }
            set
            {
                _UserNum_SalesRep = value;
            }
        }

        public int AdressNum
        {
            get
            {
                return _AdressNum;
            }
            set
            {
                _AdressNum = value;
            }
        }

        public int DocSatesCode
        {
            get
            {
                return _DocSatesCode;
            }
            set
            {
                _DocSatesCode = value;
            }
        }

        public string BPCode
        {
            get
            {
                return _BPCode;
            }
            set
            {
                _BPCode = value;
            }
        }

        public DateTime? SODueDateStartDate
        {
            get
            {
                return _SODueDateStartDate;
            }
            set
            {
                _SODueDateStartDate = value;
            }
        }

        public DateTime? SODueDateEndDate
        {
            get
            {
                return _SODueDateEndDate;
            }
            set
            {
                _SODueDateEndDate = value;
            }
        }

        public string SORef
        {
            get
            {
                return _SORef;
            }
            set
            {
                _SORef = value;
            }
        }

        public DateTime? SOStartDate
        {
            get
            {
                return _SOStartDate;
            }
            set
            {
                _SOStartDate = value;
            }
        }

        public DateTime? SOEndDate
        {
            get
            {
                return _SOEndDate;
            }
            set
            {
                _SOEndDate = value;
            }
        }

        public string OrderBy
        {
            get
            {
                return _OrderBy;
            }
            set
            {
                _OrderBy = value;
            }
        }

        public string OrderDir
        {
            get
            {
                return _OrderDir;
            }
            set
            {
                _OrderDir = value;
            }
        }

        public int PageNumber
        {
            get
            {
                return _PageNumber;
            }
            set
            {
                _PageNumber = value;
            }
        }

        public int PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }
        #endregion
    }
}

