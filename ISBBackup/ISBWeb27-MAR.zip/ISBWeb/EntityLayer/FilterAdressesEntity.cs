﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class FilterAdressesEntity
    {
        #region--Private Properties--
        private int _AdressNum=0;
        private string _OrderBy = "AdressNum";
        private string _OrderDir = "ASC";
        private int _PageNumber = 0;
        private int _PageSize = 0;
        #endregion

        #region--Public Properties--
        public int AdressNum
        {
            get
            {
                return _AdressNum;
            }
            set
            {
                _AdressNum = value;
            }
        }
        public string OrderBy
        {
            get
            {
                return _OrderBy;
            }
            set
            {
                _OrderBy = value;
            }
        }

        public string OrderDir
        {
            get
            {
                return _OrderDir;
            }
            set
            {
                _OrderDir = value;
            }
        }

        public int PageNumber
        {
            get
            {
                return _PageNumber;
            }
            set
            {
                _PageNumber = value;
            }
        }

        public int PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }
        #endregion
    }
}
