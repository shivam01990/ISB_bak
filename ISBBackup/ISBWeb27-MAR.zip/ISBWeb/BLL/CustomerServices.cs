﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class CustomerServices
    {
        #region--Instance--
        public static CustomerServices Instance = new CustomerServices();
        #endregion

        #region--BAL Methods --

        public string SaveCustomer(BPEntity objBP, bool blnUpdate, int IntUserID, int IntUserLanguage, out bool blnIsSuccess)
        {
            try
            {
                return CustomerProvider.Instance.SaveCustomer(objBP, blnUpdate, IntUserID, IntUserLanguage, out blnIsSuccess);
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        
        public BPEntity GetCustomer(int IntBPNumber)
        {
            try
            {
                return CustomerProvider.Instance.GetCustomer(IntBPNumber);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<BPEntitySearch> SearchCustomer(BPEntitySearch objBP)
        {
            try
            {
                return CustomerProvider.Instance.SearchCustomer(objBP);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public int GetMaxBPNum()
        {
            try
            {
                return CustomerProvider.Instance.GetMaxBPNum();
               
            }
            catch (Exception)
            {
                throw;
            }
        }
     
        #endregion
        
    }
}
