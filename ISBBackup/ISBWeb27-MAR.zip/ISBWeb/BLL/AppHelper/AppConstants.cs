﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class AppConstants
    {
        #region--Instance--
        public static AppConstants Instance = new AppConstants();
        #endregion

        public string SesStrUsersMngRight = "SesStrUsersMngRight";
        public string SesGlobalCustomerNum = "SesGlobalCustomerNum";
        public string SesUserID = "SesUserID";
        public string SesIntUserLanguage = "SesIntUserLanguage";

        public string DrpSelectName = "Select";
        public string DrpSelectValue = "0";

        #region--Item Settings--
        public string ItemLogoVirtuelPath
        {
            get { return (ConfigurationManager.AppSettings["ItemLogoVirtuelPath"] != null ? ConfigurationManager.AppSettings["ItemLogoVirtuelPath"].ToString() : "/PictureDB/"); }
        }      
        #endregion

        #region--User Settings--
        public string UserLogoVirtuelPath
        {
            get { return (ConfigurationManager.AppSettings["UserLogoVirtuelPath"] != null ? ConfigurationManager.AppSettings["UserLogoVirtuelPath"].ToString() : "/LogoDB/"); }
        }    
        #endregion



    }
}
