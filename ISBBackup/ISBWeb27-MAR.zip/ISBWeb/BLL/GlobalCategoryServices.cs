﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class GlobalCategoryServices
    {
        #region--Instance--
        public static GlobalCategoryServices Instance = new GlobalCategoryServices();
        #endregion

        #region--Get All GlobalCategoryServices--
        public List<GlobalCategory> GetGlobalCategories()
        {
            return GlobalCategoryProvider.Instance.GetGlobalCategories();
        }
        #endregion

    }
}
