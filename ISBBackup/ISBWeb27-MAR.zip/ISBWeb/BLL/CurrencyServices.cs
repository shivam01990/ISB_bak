﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class CurrencyServices
    {
        #region--Instance--
        public static CurrencyServices Instance = new CurrencyServices();
        #endregion

        #region--Get All Currency--
        public List<Currency> GetCurrencies()
        {
            return CurrencyProvider.Instance.GetCurrencies();
        }
        #endregion

    }
}
