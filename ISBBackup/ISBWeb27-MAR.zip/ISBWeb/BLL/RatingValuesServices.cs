﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class RatingValuesServices
    {
        #region--Instance--
        public static RatingValuesServices Instance = new RatingValuesServices();
        #endregion

        #region--Get All RatingValues--
        public List<RatingValue> GetRatingValues()
        {
            return RatingValueProvider.Instance.GetRatingValues();
        }
        #endregion

    }
}
