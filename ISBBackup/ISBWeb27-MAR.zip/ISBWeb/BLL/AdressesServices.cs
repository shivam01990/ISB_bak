﻿using DAL;
using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class AdressesServices
    {
        #region--Instance--
       public static AdressesServices Instance = new AdressesServices();
        #endregion

        #region--Get Adress--
        public List<Adress> GetAdresses(int AdressNum)
        {
            return AdressesProvider.Instance.GetAdresses(AdressNum);
        }
        #endregion

        #region--Filter Adresses--
        public List<p_FilterAdresses_Result> FilterAdresses(FilterAdressesEntity _FilterAdressesEntity)
        {
            return AdressesProvider.Instance.FilterAdresses(_FilterAdressesEntity);
        }
        #endregion

        #region--Save Adresses--
        public bool SaveAdresses(p_FilterAdresses_Result _AdressEntity)
        {
            return AdressesProvider.Instance.SaveAdresses(_AdressEntity);
        }
        #endregion

        #region--Delete Address--
        public bool DeleteAddress(int AddressNum)
        {
          return  AdressesProvider.Instance.DeleteAddress(AddressNum);
        }
        #endregion
    }
}
