﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class PaymentTermsProvider
    {
        #region--Instance--
        public static PaymentTermsProvider Instance = new PaymentTermsProvider();
        #endregion

        //********************************************************* 
        //Purpose:    Get all the Payment Terms from the database. 
        //Returns:    list of all the Payment Terms.
        //*********************************************************
        public List<PaymentTerm> GetPaymentTerms()
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var listPaymentTerms = dbcontext.PaymentTerms;

                    if (listPaymentTerms != null)
                    {
                        return listPaymentTerms.ToList();
                    }
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }




    }
}
