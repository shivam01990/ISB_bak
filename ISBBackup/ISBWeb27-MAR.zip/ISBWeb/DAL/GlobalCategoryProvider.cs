﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
  public  class GlobalCategoryProvider
    {
      #region--Instance--
      public static GlobalCategoryProvider Instance = new GlobalCategoryProvider();
      #endregion


      //********************************************************* 
      //Purpose:      Load the end user text(messages) from the database. 
      //Inputs:       intEndUserTextNum :  the value of the message number.    
      //              IntUserLanguage : User Language of the current user
      //Returns:      It will return the text value to show as a message to the user.
      //*********************************************************
      public List<GlobalCategory> GetGlobalCategories()
      {
          try
          {
              using (var dbcontext = new DBEntities())
              {
                  var listGlobalCategories = dbcontext.GlobalCategories;

                  if (listGlobalCategories != null)
                  {
                      return listGlobalCategories.ToList();
                  }
                  return null;
              }
          }
          catch (Exception)
          {
              throw;
          }
      }



    }
}
