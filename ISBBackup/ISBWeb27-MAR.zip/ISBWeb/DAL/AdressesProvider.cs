﻿using EntityLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class AdressesProvider
    {
        #region--Instance--
        public static AdressesProvider Instance = new AdressesProvider();
        #endregion

        #region--Get Adresses--
        public List<Adress> GetAdresses(int AdressNum)
        {
            List<Adress> rType = new List<Adress>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Adresses where ((c.AdressNum == AdressNum || AdressNum == 0) && (c.Active == true)) select c).ToList();
                }
                catch (Exception ex) { }
            }
            return rType;
        }
        #endregion

        #region--Filter Adresses--
        public List<p_FilterAdresses_Result> FilterAdresses(FilterAdressesEntity _FilterAdressesEntity)
        {
            List<p_FilterAdresses_Result> rType = new List<p_FilterAdresses_Result>();
            using (DBEntities db = new DBEntities())
            {
                rType = db.p_FilterAdresses(_FilterAdressesEntity.AdressNum, _FilterAdressesEntity.OrderBy, _FilterAdressesEntity.OrderDir, _FilterAdressesEntity.PageNumber, _FilterAdressesEntity.PageSize).ToList();
            }
            return rType;
        }
        #endregion

        #region--Save Adresses--
        public bool SaveAdresses(p_FilterAdresses_Result _AdressEntity)
        {
            bool rType = false;
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    int AdressNum = (int)db.p_SaveAdresses(_AdressEntity.AdressNum, _AdressEntity.Name, _AdressEntity.AdressType, _AdressEntity.Adress1, _AdressEntity.Adress2, _AdressEntity.City, _AdressEntity.StateNum, _AdressEntity.ZipCode, _AdressEntity.CountryNum, _AdressEntity.Active, _AdressEntity.Deleted).FirstOrDefault();
                    if (AdressNum > 0)
                    {
                        rType = true;
                        _AdressEntity.AdressNum = AdressNum;
                    }
                }
                catch { rType = false; }
            }
            return rType;
        }
        #endregion


        #region--Delete Address--
        public bool DeleteAddress(int AddressNum)
        {
            bool flag = false;
            try
            {
                using (DBEntities db = new DBEntities())
                {
                    Adress obj = db.Adresses.Where(s => s.AdressNum == AddressNum).FirstOrDefault();
                    if (obj != null)
                    {
                        db.Adresses.Remove(obj);
                        db.SaveChanges();
                        flag = true;
                    }
                }
            }
            catch
            { }
            return flag;

        }
        #endregion
    }
}
