﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class GenderProvider
    {
        #region--Instance--
        public static GenderProvider Instance = new GenderProvider();
        #endregion

        #region--Get Gender--
        public List<Gender> GetGender(int GenderNum)
        {
            List<Gender> rType = new List<Gender>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Genders where (c.GenderNum == GenderNum || GenderNum == 0) && c.Active==true select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

    }
}
