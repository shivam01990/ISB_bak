﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UOMItemsProvider
    {
        #region--Instance--
        public static UOMItemsProvider Instance = new UOMItemsProvider();
        #endregion

        #region--Get UOM Items--
        public List<UOMItem> GetUOMItems(int uomItemNum)
        {
            List<UOMItem> rType = new List<UOMItem>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.UOMItems where (c.UOMItemNum == uomItemNum || uomItemNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
