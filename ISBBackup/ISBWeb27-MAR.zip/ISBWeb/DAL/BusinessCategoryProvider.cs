﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class BusinessCategoryProvider
    {
       #region--Instance--
       public static BusinessCategoryProvider Instance = new BusinessCategoryProvider();
       #endregion


       //********************************************************* 
       //Purpose:    Get all the business Categories from the database. 
       //Returns:    list of all the business categories.
       //*********************************************************
       public List<BusinessCategory> GetBusinessCategories()
       {
           try
           {
               using (var dbcontext = new DBEntities())
               {
                   var listBusinessCategories = dbcontext.BusinessCategories;

                   if (listBusinessCategories != null)
                   {
                       return listBusinessCategories.ToList();
                   }
                   return null;
               }
           }
           catch (Exception)
           {
               throw;
           }
       }




    }
}
