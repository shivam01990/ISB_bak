﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CurrencyProvider
    {

        #region--Instance--
        public static CurrencyProvider Instance = new CurrencyProvider();
        #endregion

        //********************************************************* 
        //Purpose:    Get all the Currencies  from the database. 
        //Returns:    list of all the Currencies.
        //*********************************************************
        public List<Currency> GetCurrencies()
        {
            try
            {
                using (var dbcontext = new DBEntities())
                {
                    var listCurrencies = dbcontext.Currencies;

                    if (listCurrencies != null)
                    {
                        return listCurrencies.ToList();
                    }
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
