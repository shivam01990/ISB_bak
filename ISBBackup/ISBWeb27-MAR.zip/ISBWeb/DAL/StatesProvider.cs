﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class StatesProvider
    {
        #region--Instance--
        public static StatesProvider Instance = new StatesProvider();
        #endregion

        #region--Get Address--
        public List<State> GetStates(int StateNum, int CountryNum)
        {
            List<State> rType = new List<State>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.States where ((c.StateNum == StateNum || StateNum == 0) && ((c.CountryNum == CountryNum) || (CountryNum == 0))) select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

    }
}
