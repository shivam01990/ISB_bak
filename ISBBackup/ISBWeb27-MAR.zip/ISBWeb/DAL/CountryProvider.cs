﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CountryProvider
    {
        #region--Instance--
        public static CountryProvider Instance = new CountryProvider();
        #endregion

        #region--Get Country--
        public List<Country> GetCountry(int CountryNum)
        {
            List<Country> rType = new List<Country>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Countries where (c.CountryNum == CountryNum || CountryNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
