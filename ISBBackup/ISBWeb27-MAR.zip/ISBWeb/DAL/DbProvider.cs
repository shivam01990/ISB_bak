﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DbProvider
    {
        public static DbProvider Instance = new DbProvider();
        public int DBType
        {
            get { return this._dbtype; }
            set { this._dbtype = value; }
        }
        private int _dbtype = 1;
        private SqlConnection conn = null;
        public DbProvider()
        {
            this.DBType = 1;
        }
        public DbProvider(int _dbType)
        {
            this.DBType = _dbType;
        }
        private void OpenConn()
        {
            conn = new SqlConnection();
            if (DBType == 1)
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString();
            }
            else if (DBType == 2)
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString();
            }
            conn.Open();
        }

        private void CloseConn()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        public void ExecuteNonQuery(string sp_name, SqlParameter[] param)
        {
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sp_name, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                for (int i = 0; i <= param.Length - 1; i++)
                {
                    cmd.Parameters.Add(param[i]);
                }

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConn();
            }
        }

        public DataSet ExecuteDataSet(string sp_name, SqlParameter[] param)
        {
            DataSet ds = new DataSet();
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sp_name, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                for (int i = 0; i <= param.Length - 1; i++)
                {
                    cmd.Parameters.Add(param[i]);
                }
                SqlDataAdapter adp = new SqlDataAdapter(cmd);


                adp.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConn();
            }
            return ds;
        }

        public DataTable ExecuteDataTable(string sp_name, SqlParameter[] param)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sp_name, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                for (int i = 0; i <= param.Length - 1; i++)
                {
                    cmd.Parameters.Add(param[i]);
                }
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                if ((ds != null) & ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConn();
            }
            return dt;
        }

        public DataTable ExecuteDataTable(string SQLQuery)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(SQLQuery, conn);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                if ((ds != null) & ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConn();
            }
            return dt;
        }

        public string ExecuteScaler(string sp_name, SqlParameter[] param)
        {
            string _result = string.Empty;
            try
            {
                OpenConn();
                SqlCommand cmd = new SqlCommand(sp_name, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                for (int i = 0; i <= param.Length - 1; i++)
                {
                    cmd.Parameters.Add(param[i]);
                }
                _result = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                CloseConn();
            }
            return _result;
        }

        public void BatchBulkCopy(DataTable dataTable, string DestinationTbl, int batchSize, Dictionary<string, string> MapColumns, int BatchTimeout)
        {
            // Get the DataTable 
            DataTable dtInsertRows = dataTable;
            OpenConn();
            //  SqlTransaction transaction = conn.BeginTransaction();
            try
            {
                TotalRows = 0;
                SqlBulkProgressRow = 0;
                using (SqlBulkCopy sbc = new SqlBulkCopy(conn))
                {
                    sbc.DestinationTableName = DestinationTbl;

                    // Number of records to be processed in one go
                    sbc.BatchSize = batchSize;
                    sbc.BulkCopyTimeout = BatchTimeout;
                    sbc.SqlRowsCopied += new SqlRowsCopiedEventHandler(OnSqlRowsCopied);
                    sbc.NotifyAfter = 50;
                    TotalRows = dataTable.Rows.Count;
                    // Add your column mappings here
                    //sbc.ColumnMappings.Add("product_name", "ProductName");
                    foreach (KeyValuePair<string, string> item in MapColumns)
                    {
                        sbc.ColumnMappings.Add(item.Key, item.Value);
                    }
                    // Finally write to server
                    sbc.WriteToServer(dtInsertRows);
                    //transaction.Commit();

                }
            }
            catch (Exception ex)
            {
                //transaction.Rollback();
                //throw;
            }
            finally
            {
                //transaction.Dispose();
                CloseConn();
            }
        }

        public static Int64 SqlBulkProgressRow;
        public static Int64 TotalRows;
        private void OnSqlRowsCopied(object sender, SqlRowsCopiedEventArgs e)
        {
            SqlBulkProgressRow = e.RowsCopied;
        }

    }
}
