﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
namespace DAL
{
    public class BPProvider
    {
        #region--Instance--
        public static BPProvider Instance = new BPProvider();
        #endregion

        #region--Get BP--
        public List<BP> GetBP(int globalCategoryNum)
        {
            List<BP> rType = new List<BP>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.BPs where (c.GlobalCategoryNum == globalCategoryNum || globalCategoryNum == 0) select c).ToList();
                }
                catch (Exception ex) { }
            }
            return rType;
        }
        #endregion

        #region--Filter BP--
        public List<p_FilterBP_Result> FilterBP(FilterBPEntity _FilterBPEntity)
        {
            List<p_FilterBP_Result> rType = new List<p_FilterBP_Result>();
            using (DBEntities db = new DBEntities())
            {
                rType = db.p_FilterBP(_FilterBPEntity.BPNum, _FilterBPEntity.GlobalCustomerNum, _FilterBPEntity.Name, _FilterBPEntity.Code, _FilterBPEntity.City, _FilterBPEntity.State, _FilterBPEntity.ZipCode, _FilterBPEntity.Email, _FilterBPEntity.Active, _FilterBPEntity.OrderBy, _FilterBPEntity.OrderDir, _FilterBPEntity.PageNumber, _FilterBPEntity.PageSize).ToList();
            }
            return rType;
        }
        #endregion

    }
}
