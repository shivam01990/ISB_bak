﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class VocabularyDisplayProvider
    {
        #region--Instance--
        public static VocabularyDisplayProvider Instance = new VocabularyDisplayProvider();
        #endregion

        #region--Get Vocabulary Display--
        public List<VocabularyDisplay> LoadVocabulary(int VocabularyDisplayNum, int UserLanguageNum)
        {
            List<VocabularyDisplay> rType = new List<VocabularyDisplay>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.VocabularyDisplays where (c.VocabularyDisplayNum == VocabularyDisplayNum || VocabularyDisplayNum == 0) && (c.UserLanguageNum == UserLanguageNum || UserLanguageNum == 0)  select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

    }
}
