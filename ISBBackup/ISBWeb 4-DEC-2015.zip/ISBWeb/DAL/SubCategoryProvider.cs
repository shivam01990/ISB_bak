﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class SubCategoryProvider
    {
        #region--Instance--
        public static SubCategoryProvider Instance = new SubCategoryProvider();
        #endregion

        #region--Get Sub Category--
        public List<SubCategory> GetSubCategory(int subCategoryNum)
        {
            List<SubCategory> rType = new List<SubCategory>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.SubCategories where (c.SubCategoryNum == subCategoryNum || subCategoryNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
