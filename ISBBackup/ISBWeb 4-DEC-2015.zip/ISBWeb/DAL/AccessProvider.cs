﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;

namespace DAL
{
    public class AccessProvider
    {
        #region--Instance--
        public static AccessProvider Instance = new AccessProvider();
        #endregion

        #region--Get Access--
        public List<Access> GetAccess(int AccessNum, int AccessGroupNum)
        {
            List<Access> rType = new List<Access>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.Accesses where (c.AccessNum == AccessNum || AccessNum == 0) && (c.AccessGroupNum == AccessGroupNum || AccessGroupNum == 0) && c.Active == true select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

        //#region--Get Access User--
        //public List<UserAccessesEntity> GetAccessUser(int AccessNum, int AccessGroupNum,int UserNum)
        //{
        //    List<UserAccessesEntity> rType = new List<UserAccessesEntity>();
        //    using (DBEntities db = new DBEntities())
        //    {
        //        try
        //        {
        //            rType = (from a in db.Accesses 
        //                     join u in db.UserAccesses on a.AccessNum equals u.AccessNum into lj
        //                     from t in lj.Where(t => t.UserNum == UserNum).DefaultIfEmpty()
        //                     where (a.AccessNum == AccessNum || AccessNum == 0) && (a.AccessGroupNum == AccessGroupNum || AccessGroupNum == 0) && a.Active == true
        //                     select new UserAccessesEntity { }).ToList();
        //        }
        //        catch { }
        //    }
        //    return rType;
        //}
        //#endregion
    }
}
