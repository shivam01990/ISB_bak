﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UserProvider
    {
        #region--Instance--
        public static UserProvider Instance = new UserProvider();
        #endregion

        #region--Insert User--
        public int InsertUser(User _User)
        {
            int UserID = 0;
            using (DBEntities db = new DBEntities())
            {
                int.TryParse(db.p_InsertUsers(_User.GlobalCustomerNum, _User.FirstName, _User.LastName, _User.Adress1, _User.City, _User.State, _User.ZipCode, _User.CountryNum, _User.HourlyRate, _User.HourlyRateOT, _User.LogoPath, _User.PrimaryPhone, _User.GenderNum, _User.BirthDate, _User.BirthCountryNum, _User.ReferalTypeNum, _User.SocialID, (bool)_User.Active, _User.UserName, _User.Password, _User.PasswordExpDate, _User.Title, _User.LanguageNum, _User.IsManager, _User.PositionNum, _User.CitizenshipCountryNum, _User.CitizenshipID, _User.CitizenshipExpDate, _User.PassportCountryNum, _User.PassportID, _User.PassportExpDate, _User.ResidentCountryNum, _User.ResidentCountryID, _User.ResidentIDExpDate, _User.WorkVisaID, _User.WorkVisaExpDate, _User.ReferalName, _User.SASId, _User.Commission, _User.ResidentID, _User.CustomField1Name, _User.CustomField1Value, (bool)_User.CustomField1Vis, _User.CustomField2Name, _User.CustomField2Value, (bool)_User.CustomField2Vis, _User.CustomField3Name, _User.CustomField3Value, (bool)_User.CustomField3Vis, _User.CustomField4Name, _User.CustomField4Value, (bool)_User.CustomField4Vis, _User.CustomField5Name, _User.CustomField5Value, (bool)_User.CustomField5Vis, _User.CustomField6Name, _User.CustomField6Value, (bool)_User.CustomField6Vis, _User.CustomField7Name, _User.CustomField7Value, (bool)_User.CustomField7Vis, _User.CustomField8Name, _User.CustomField8Value, (bool)_User.CustomField8Vis).FirstOrDefault().ToString(), out UserID);
            }
            return UserID;
        }
        #endregion

        #region--Update User--
        public void UpdateUser(User _User)
        {
            using (DBEntities db = new DBEntities())
            {
                db.p_UpdateUser(_User.UserNum, _User.GlobalCustomerNum, _User.FirstName, _User.LastName, _User.Adress1, _User.City, _User.State, _User.ZipCode, _User.CountryNum, _User.HourlyRate, _User.HourlyRateOT, _User.LogoPath, _User.PrimaryPhone, _User.GenderNum, _User.BirthDate, _User.BirthCountryNum, _User.ReferalTypeNum, _User.SocialID, (bool)_User.Active, _User.UserName, _User.Password, _User.PasswordExpDate, _User.Title, _User.LanguageNum, _User.IsManager, _User.PositionNum, _User.CitizenshipCountryNum, _User.CitizenshipID, _User.CitizenshipExpDate, _User.PassportCountryNum, _User.PassportID, _User.PassportExpDate, _User.ResidentCountryNum, _User.ResidentCountryID, _User.ResidentIDExpDate, _User.WorkVisaID, _User.WorkVisaExpDate, _User.ReferalName, _User.SASId, _User.Commission, _User.ResidentID, _User.CustomField1Name, _User.CustomField1Value, (bool)_User.CustomField1Vis, _User.CustomField2Name, _User.CustomField2Value, (bool)_User.CustomField2Vis, _User.CustomField3Name, _User.CustomField3Value, (bool)_User.CustomField3Vis, _User.CustomField4Name, _User.CustomField4Value, (bool)_User.CustomField4Vis, _User.CustomField5Name, _User.CustomField5Value, (bool)_User.CustomField5Vis, _User.CustomField6Name, _User.CustomField6Value, (bool)_User.CustomField6Vis, _User.CustomField7Name, _User.CustomField7Value, (bool)_User.CustomField7Vis, _User.CustomField8Name, _User.CustomField8Value, (bool)_User.CustomField8Vis);
            }
        }
        #endregion

        #region--Get User--
        public List<User> GetUser(int UserNum)
        {
            List<User> rType = new List<User>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from u in db.Users where (u.UserNum == UserNum || UserNum == 0)  select u).ToList();
            }
            return rType;
        }

        #endregion
    }
}
