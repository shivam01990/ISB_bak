﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class GeneralSettingProvider
    {
        #region--Instance--
        public static GeneralSettingProvider Instance = new GeneralSettingProvider();
        #endregion

        #region--Get Gender--
        public List<GeneralSetting> GetGeneralSettings(int GlobalCustomerNum)
        {
            List<GeneralSetting> rType = new List<GeneralSetting>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.GeneralSettings where (c.GlobalCustomerNum == GlobalCustomerNum || GlobalCustomerNum == 0) select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion

    }
}
