﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BPProvider
    {
        #region--Instance--
        public static BPProvider Instance = new BPProvider();
        #endregion

        #region--Get BP--
        public List<BP> GetBP(int globalCategoryNum)
        {
            List<BP> rType = new List<BP>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.BPs where (c.GlobalCategoryNum == globalCategoryNum || globalCategoryNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
