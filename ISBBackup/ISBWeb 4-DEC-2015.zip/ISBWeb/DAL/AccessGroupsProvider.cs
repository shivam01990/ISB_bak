﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class AccessGroupsProvider
    {
        #region--Instance--
        public static AccessGroupsProvider Instance = new AccessGroupsProvider();
        #endregion

        #region--Get Access Group--
        public List<AccessGroup> GetAccessGroup(int AccessGroupNum)
        {
            List<AccessGroup> rType = new List<AccessGroup>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.AccessGroups where (c.AccessGroupNum == AccessGroupNum || AccessGroupNum == 0) && c.Active==true select c).ToList();
                }
                catch { }
            }
            return rType;
        }
        #endregion
    }
}
