﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ItemsProvider
    {
        #region--Instance--
        public static ItemsProvider Instance = new ItemsProvider();
        #endregion

        #region--Insert Item--
        public int InsertItem(Item _item)
        {
            int itemID = 0;
            using (DBEntities db = new DBEntities())
            {
                //if (_item.ItemNum == 0)
                //    db.Items.Add(_item);

                //db.SaveChanges();
                //itemID = _item.ItemNum;

                int.TryParse(db.p_SaveItem(_item.ItemNum, _item.GlobalCustomerNum, _item.Code, _item.Description, _item.UPC, _item.EAN13,
                    _item.ItemTypeNum, _item.CategoryNum, _item.SubCategoryNum, _item.DefaultSupplierBPNum, _item.PicturePath,
                    _item.CountryOfOriginNum, _item.UMOItemNum, _item.Volume, _item.NetWeight, _item.GrossWeight, _item.IsBuyItem,
                    _item.IsPurchaseItem, _item.AllowReturn, _item.CustomField1Name, _item.CustomField1Value, _item.CustomField1Vis,
                    _item.CustomField2Name, _item.CustomField2Value, _item.CustomField2Vis, _item.CustomField3Name, _item.CustomField3Value, _item.CustomField3Vis,
                    _item.CustomField4Name, _item.CustomField4Value, _item.CustomField4Vis, _item.CustomField5Name, _item.CustomField5Value, _item.CustomField5Vis,
                    _item.CustomField6Name, _item.CustomField6Value, _item.CustomField6Vis, _item.CustomField7Name, _item.CustomField7Value, _item.CustomField7Vis,
                    _item.CustomField8Name, _item.CustomField8Value, _item.CustomField8Vis, _item.Active).FirstOrDefault().ToString(), out itemID);
            }
            return itemID;
        }
        #endregion

        #region--Update Item--
        public void UpdateItem(Item _item)
        {
            int itemID = 0;
            using (DBEntities db = new DBEntities())
            {
                int.TryParse(db.p_SaveItem(_item.ItemNum, _item.GlobalCustomerNum, _item.Code, _item.Description, _item.UPC, _item.EAN13,
                    _item.ItemTypeNum, _item.CategoryNum, _item.SubCategoryNum, _item.DefaultSupplierBPNum, _item.PicturePath,
                    _item.CountryOfOriginNum, _item.UMOItemNum, _item.Volume, _item.NetWeight, _item.GrossWeight, _item.IsBuyItem,
                    _item.IsPurchaseItem, _item.AllowReturn, _item.CustomField1Name, _item.CustomField1Value, _item.CustomField1Vis,
                    _item.CustomField2Name, _item.CustomField2Value, _item.CustomField2Vis, _item.CustomField3Name, _item.CustomField3Value, _item.CustomField3Vis,
                    _item.CustomField4Name, _item.CustomField4Value, _item.CustomField4Vis, _item.CustomField5Name, _item.CustomField5Value, _item.CustomField5Vis,
                    _item.CustomField6Name, _item.CustomField6Value, _item.CustomField6Vis, _item.CustomField7Name, _item.CustomField7Value, _item.CustomField7Vis,
                    _item.CustomField8Name, _item.CustomField8Value, _item.CustomField8Vis, _item.Active).FirstOrDefault().ToString(), out itemID);

                //Item currItem = db.Items.Where(x => x.ItemNum == _item.ItemNum).FirstOrDefault();
                //if (currItem != null)
                //{
                //    currItem.Active = _item.Active;
                //    currItem.AllowReturn = _item.AllowReturn;
                //    currItem.CategoryNum = _item.CategoryNum;
                //    currItem.Code = _item.Code;
                //    currItem.CountryOfOriginNum = _item.CountryOfOriginNum;
                //    currItem.CustomField1Name = _item.CustomField1Name;
                //    currItem.CustomField1Value = _item.CustomField1Value;
                //    currItem.CustomField1Vis = _item.CustomField1Vis;
                //    currItem.CustomField2Name = _item.CustomField2Name;
                //    currItem.CustomField2Value = _item.CustomField2Value;
                //    currItem.CustomField2Vis = _item.CustomField2Vis;
                //    currItem.CustomField3Name = _item.CustomField3Name;
                //    currItem.CustomField3Value = _item.CustomField3Value;
                //    currItem.CustomField3Vis = _item.CustomField3Vis;
                //    currItem.CustomField4Name = _item.CustomField4Name;
                //    currItem.CustomField4Value = _item.CustomField4Value;
                //    currItem.CustomField4Vis = _item.CustomField4Vis;
                //    currItem.CustomField5Name = _item.CustomField5Name;
                //    currItem.CustomField5Value = _item.CustomField5Value;
                //    currItem.CustomField5Vis = _item.CustomField5Vis;
                //    currItem.CustomField6Name = _item.CustomField6Name;
                //    currItem.CustomField6Value = _item.CustomField6Value;
                //    currItem.CustomField6Vis = _item.CustomField6Vis;
                //    currItem.CustomField7Name = _item.CustomField7Name;
                //    currItem.CustomField7Value = _item.CustomField7Value;
                //    currItem.CustomField7Vis = _item.CustomField7Vis;
                //    currItem.CustomField8Name = _item.CustomField8Name;
                //    currItem.CustomField8Value = _item.CustomField8Value;
                //    currItem.CustomField8Vis = _item.CustomField8Vis;
                //    currItem.DefaultSupplierBPNum = _item.DefaultSupplierBPNum;
                //    currItem.Description = _item.Description;
                //    currItem.EAN13 = _item.EAN13;
                //    currItem.GlobalCustomerNum = _item.GlobalCustomerNum;
                //    currItem.GrossWeight = _item.GrossWeight;
                //    currItem.IsBuyItem = _item.IsBuyItem;
                //    currItem.IsPurchaseItem = _item.IsPurchaseItem;
                //    currItem.ItemTypeNum = _item.ItemTypeNum;
                //    currItem.NetWeight = _item.NetWeight;
                //    currItem.PicturePath = _item.PicturePath;
                //    currItem.SubCategoryNum = _item.SubCategoryNum;
                //    currItem.UMOItemNum = _item.UMOItemNum;
                //    currItem.UPC = _item.UPC;
                //    currItem.Volume = _item.Volume;
                //}

                //db.SaveChanges();
            }
        }
        #endregion

        #region--Get Item--
        public List<Item> GetItem(int itemNum)
        {
            List<Item> rType = new List<Item>();
            using (DBEntities db = new DBEntities())
            {
                rType = (from u in db.Items where (u.ItemNum == itemNum || itemNum == 0) select u).ToList();
            }
            return rType;
        }

        #endregion
    }
}
