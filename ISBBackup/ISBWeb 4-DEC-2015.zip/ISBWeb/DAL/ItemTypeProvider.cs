﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ItemTypeProvider
    {
        #region--Instance--
        public static ItemTypeProvider Instance = new ItemTypeProvider();
        #endregion

        #region--Get Item Type--
        public List<ItemType> GetItemType(int itemTypeNum)
        {
            List<ItemType> rType = new List<ItemType>();
            using (DBEntities db = new DBEntities())
            {
                try
                {
                    rType = (from c in db.ItemTypes where (c.ItemTypeNum == itemTypeNum || itemTypeNum == 0) select c).ToList();
                }
                catch (Exception ex){ }
            }
            return rType;
        }
        #endregion

     
    }
}
