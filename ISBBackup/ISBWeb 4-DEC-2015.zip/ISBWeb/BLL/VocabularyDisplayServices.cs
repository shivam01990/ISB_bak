﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class VocabularyDisplayServices
    {
        #region--Instance--
        public static VocabularyDisplayServices Instance = new VocabularyDisplayServices();
        #endregion

        #region--Get Vocabulary Display--
        public VocabularyDisplay LoadVocabulary(int VocabularyDisplayNum, int UserLanguageNum)
        {
            return VocabularyDisplayProvider.Instance.LoadVocabulary(VocabularyDisplayNum, UserLanguageNum).FirstOrDefault();
        }
        #endregion
    }
}
