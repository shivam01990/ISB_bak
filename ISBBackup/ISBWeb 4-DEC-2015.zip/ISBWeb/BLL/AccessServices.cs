﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class AccessServices
    {
        #region--Instance--
       public static AccessServices Instance = new AccessServices();
        #endregion

       #region--Get Access--
       public List<Access> GetAccess(int AccessNum, int AccessGroupNum)
       {
           List<Access> rType = new List<Access>();
           rType = AccessProvider.Instance.GetAccess(AccessNum, AccessGroupNum);
           return rType;
       }
       #endregion
    }
}
