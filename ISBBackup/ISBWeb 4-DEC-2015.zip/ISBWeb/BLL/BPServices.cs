﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BPServices
    {
        #region--Instance--
        public static BPServices Instance = new BPServices();
        #endregion

        #region--Get BP--
        public BP GetBP(int globalCategoryNum)
        {
            return BPProvider.Instance.GetBP(globalCategoryNum).FirstOrDefault();
        }
        #endregion


        #region--Get BP--
        public List<BP> GetAllBP()
        {
            return BPProvider.Instance.GetBP(0);
        }
        #endregion
    }
}
