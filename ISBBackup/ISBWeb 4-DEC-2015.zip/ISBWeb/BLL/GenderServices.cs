﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class GenderServices
    {
        #region--Instance--
       public static GenderServices Instance = new GenderServices();
        #endregion

        #region--Get Gender--
        public Gender GetGender(int GenderNum)
        {
            return GenderProvider.Instance.GetGender(GenderNum).FirstOrDefault();
        }
        #endregion


        #region--Get Gender--
        public List<Gender> GetAllGender()
        {
            return GenderProvider.Instance.GetGender(0);
        }
        #endregion
    }
}
