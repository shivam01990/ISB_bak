﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class GeneralSettingServices
    {
        #region--Instance--
        public static GeneralSettingServices Instance = new GeneralSettingServices();
        #endregion

        #region--Get General Settings--
        public GeneralSetting GetGeneralSettings(int GlobalCustomerNum)
        {
            return GeneralSettingProvider.Instance.GetGeneralSettings(GlobalCustomerNum).FirstOrDefault();
        }
        #endregion
    }
}
