﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class LanguagesServices
    {
        #region--Instance--
        public static LanguagesServices Instance = new LanguagesServices();
        #endregion

        #region--Get Languages--
        public Language GetLanguage(int LanguageNum)
        {
            return LanguagesProvider.Instance.GetLanguages(LanguageNum).FirstOrDefault();
        }
        #endregion

        #region--Get All Languages--
        public List<Language> GetAllLanguages()
        {
            return LanguagesProvider.Instance.GetLanguages(0);
        }
        #endregion
    }
}
