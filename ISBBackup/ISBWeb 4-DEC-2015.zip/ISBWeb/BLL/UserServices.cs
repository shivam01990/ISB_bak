﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UserServices
    {
        #region--Instance--
        public static UserServices Instance = new UserServices();
        #endregion

        #region--Insert User--
        public int InsertUser(User _User)
        {
            return UserProvider.Instance.InsertUser(_User);
        }
        #endregion

        #region--Update User--
        public void UpdateUser(User _User)
        {
            UserProvider.Instance.UpdateUser(_User);
        }
        #endregion

        #region--Get User--
        public User GetUser(int UserNum)
        {
            return UserProvider.Instance.GetUser(UserNum).FirstOrDefault();
        }
        #endregion

        #region--Get All User--
        public List<User> GetAllUser()
        {
            return UserProvider.Instance.GetUser(0);
        }

        #endregion
    }
}
