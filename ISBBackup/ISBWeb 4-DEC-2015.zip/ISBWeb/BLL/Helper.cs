﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.HtmlControls;

namespace BLL
{
   public class Helper
    {
       public static void ShowMessage(HtmlGenericControl msgDiv, string msg,  bool success)
       {
           if (success == true)
           {
               msgDiv.InnerHtml = " <div class=\"alert alert-success\"> "+msg+"</div>";
           }
           else
           {
               msgDiv.InnerHtml = "<div class=\"alert alert-danger\">"+msg+"</div>";
           }

           msgDiv.Visible = true;
       }

        public static Nullable<int> GetNullableInteger(int intValue)
        {
            return (intValue == 0 || intValue == -1) ? new Nullable<int>() : intValue;
        }
    }
}
