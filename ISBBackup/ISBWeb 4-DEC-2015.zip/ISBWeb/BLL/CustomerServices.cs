﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class CustomerServices
    {
        #region--Instance--
        public static CustomerServices Instance = new CustomerServices();
        #endregion

        #region--BAL Methods --

        public string SaveCustomer(BPEntity objBP, bool blnUpdate, int IntUserID, int IntUserLanguage, out bool blnIsSuccess)
        {
            try
            {
                return CustomerProvider.Instance.SaveCustomer(objBP, blnUpdate, IntUserID, IntUserLanguage, out blnIsSuccess);
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        
        public BPEntity GetCustomer(int IntBPNumber)
        {
            try
            {
                return CustomerProvider.Instance.GetCustomer(IntBPNumber);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public int GetMaxBPNum()
        {
            try
            {
                return CustomerProvider.Instance.GetMaxBPNum();
               
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string LoadVocabulary(int intVocabularyDisplayNum, int IntUserLanguage)
        {
            try
            {
                return CustomerProvider.Instance.LoadVocabulary( intVocabularyDisplayNum, IntUserLanguage);

            }
            catch (Exception)
            {
                throw;
            }
        }

        public string LoadEndUserText(int intEndUserTextNum, int IntUserLanguage)
        {
            try
            {
                return CustomerProvider.Instance.LoadEndUserText(intEndUserTextNum, IntUserLanguage);

            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<GlobalCategory> GetGlobalCategories()
        {
            try
            {
                return CustomerProvider.Instance.GetGlobalCategories();
                
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<BusinessCategory> GetBusinessCategories()
        {
            try
            {
                return CustomerProvider.Instance.GetBusinessCategories();
               
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<TaxGroup> GetTaxGroups()
        {
            try
            {
                return CustomerProvider.Instance.GetTaxGroups();
               
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Currency> GetCurrencies()
        {
            try
            {
                return CustomerProvider.Instance.GetCurrencies();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<PaymentTerm> GetPaymentTerms()
        {
            try
            {
                return CustomerProvider.Instance.GetPaymentTerms();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<RatingValue> GetRatingValues()
        {
            try
            {
                return CustomerProvider.Instance.GetRatingValues();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public GeneralSetting LoadGeneralSettings(int IntGlobalCustomerNum, int IntUserLanguage)
        {
            try
            {
                return CustomerProvider.Instance.LoadGeneralSettings(IntGlobalCustomerNum, IntUserLanguage);
            }
            catch (Exception)
            {

                throw;
            }
        }

        #endregion

   

    }
}
