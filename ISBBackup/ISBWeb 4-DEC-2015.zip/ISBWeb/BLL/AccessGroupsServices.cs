﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class AccessGroupsServices
    {
        #region--Instance--
        public static AccessGroupsServices Instance = new AccessGroupsServices();
        #endregion

        #region--Get Access Group--
        public AccessGroup GetAccessGroup(int AccessGroupNum)
        {
            AccessGroup rType = new AccessGroup();
            AccessGroupsProvider.Instance.GetAccessGroup(AccessGroupNum).FirstOrDefault();
            return rType;
        }
        #endregion

        #region--Get All Access Group--
        public List<AccessGroup> GetAllAccessGroup()
        {
            List<AccessGroup> rType = new List<AccessGroup>();
            rType = AccessGroupsProvider.Instance.GetAccessGroup(0);
            return rType;
        }
        #endregion
    }
}
