﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISBWeb.Account
{
    public partial class AddEditUser : System.Web.UI.Page
    {
        #region ---Initialize---
        int _usernum = 0;
        public int UserNum
        {
            get
            {
                if (Request.QueryString["UserNum"] != null)
                {
                    int.TryParse(Request.QueryString["UserNum"].ToString(), out _usernum);
                }
                return _usernum;
            }

        }

        protected string SesStrUsersMngRight
        {
            get
            {
                string u = "";
                if (Session[AppConstants.Instance.SesStrUsersMngRight] == null)
                {
                    u = "R";
                }
                else
                {
                    u = Session[AppConstants.Instance.SesStrUsersMngRight].ToString();
                }

                return u;
            }

            set
            {
                Session[AppConstants.Instance.SesStrUsersMngRight] = value;
            }
        }

        protected int SesGlobalCustomerNum
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesGlobalCustomerNum] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesGlobalCustomerNum].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesGlobalCustomerNum] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesGlobalCustomerNum] = value;
            }
        }

        protected int SesUserID
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesUserID] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesUserID].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesUserID] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesUserID] = value;
            }
        }

        protected int SesIntUserLanguage
        {
            get
            {
                int u = 0;
                if (Session[AppConstants.Instance.SesIntUserLanguage] != null)
                {
                    int.TryParse(Session[AppConstants.Instance.SesIntUserLanguage].ToString(), out u);
                }
                else
                {
                    Session[AppConstants.Instance.SesIntUserLanguage] = u;
                }
                return u;
            }
            set
            {
                Session[AppConstants.Instance.SesIntUserLanguage] = value;
            }
        }
        #endregion

        #region ---Page Load---
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SesStrUsersMngRight = "RW";
                SesGlobalCustomerNum = 1;
                SesUserID = 1;
                SesIntUserLanguage = 1;
                BindLabelNames();
                BindDropDown();
                BindUser();
                BindRepeater();
                CheckOtherFieldVisibility();
                CheckPermission();
            }
        }
        #endregion

        #region--Bind Drop Down--
        public void BindDropDown()
        {
            List<Country> dtCountry = CountryServices.Instance.GetAllCountry();

            ddlCountry.AppendDataBoundItems = true;
            ddlCountry.DataSource = dtCountry;
            ddlCountry.DataTextField = "Name";
            ddlCountry.DataValueField = "CountryNum";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));


            ddlGender.AppendDataBoundItems = true;
            ddlGender.DataSource = GenderServices.Instance.GetAllGender();
            ddlGender.DataTextField = "Name";
            ddlGender.DataValueField = "GenderNum";
            ddlGender.DataBind();
            ddlGender.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlBoarnCountry.AppendDataBoundItems = true;
            ddlBoarnCountry.DataSource = dtCountry;
            ddlBoarnCountry.DataTextField = "Name";
            ddlBoarnCountry.DataValueField = "CountryNum";
            ddlBoarnCountry.DataBind();
            ddlBoarnCountry.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlReferalType.AppendDataBoundItems = true;
            ddlReferalType.DataSource = ReferalTypeServices.Instance.GetAllReferalType();
            ddlReferalType.DataTextField = "Name";
            ddlReferalType.DataValueField = "ReferalTypeNum";
            ddlReferalType.DataBind();
            ddlReferalType.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));


            ddlDefaultLang.AppendDataBoundItems = true;
            ddlDefaultLang.DataSource = LanguagesServices.Instance.GetAllLanguages();
            ddlDefaultLang.DataTextField = "Name";
            ddlDefaultLang.DataValueField = "LanguageNum";
            ddlDefaultLang.DataBind();
            ddlDefaultLang.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlCitizenshipCountry.AppendDataBoundItems = true;
            ddlCitizenshipCountry.DataSource = dtCountry;
            ddlCitizenshipCountry.DataTextField = "Name";
            ddlCitizenshipCountry.DataValueField = "CountryNum";
            ddlCitizenshipCountry.DataBind();
            ddlCitizenshipCountry.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlPassportCountry.AppendDataBoundItems = true;
            ddlPassportCountry.DataSource = dtCountry;
            ddlPassportCountry.DataTextField = "Name";
            ddlPassportCountry.DataValueField = "CountryNum";
            ddlPassportCountry.DataBind();
            ddlPassportCountry.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlResidentCountry.AppendDataBoundItems = true;
            ddlResidentCountry.DataSource = dtCountry;
            ddlResidentCountry.DataTextField = "Name";
            ddlResidentCountry.DataValueField = "CountryNum";
            ddlResidentCountry.DataBind();
            ddlResidentCountry.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));

            ddlPosition.AppendDataBoundItems = true;
            ddlPosition.DataSource = PositionServices.Instance.GetAllPosition();
            ddlPosition.DataTextField = "Name";
            ddlPosition.DataValueField = "PositionNum";
            ddlPosition.DataBind();
            ddlPosition.Items.Insert(0, (new ListItem() { Value = "-1", Text = "Select" }));


            ddlAccessGroup.AppendDataBoundItems = true;
            ddlAccessGroup.DataSource = AccessGroupsServices.Instance.GetAllAccessGroup();
            ddlAccessGroup.DataTextField = "Name";
            ddlAccessGroup.DataValueField = "AccessGroupNum";
            ddlAccessGroup.DataBind();
        }
        #endregion

        #region--Bind Label Names--
        public void BindLabelNames()
        {
            lblFirstName.Text = VocabularyDisplayServices.Instance.LoadVocabulary(100, SesIntUserLanguage).TextValue;
            lbllastName.Text = VocabularyDisplayServices.Instance.LoadVocabulary(101, SesIntUserLanguage).TextValue;
            lblAddress1.Text = VocabularyDisplayServices.Instance.LoadVocabulary(102, SesIntUserLanguage).TextValue;
            lblCity.Text = VocabularyDisplayServices.Instance.LoadVocabulary(103, SesIntUserLanguage).TextValue;
            lblState.Text = VocabularyDisplayServices.Instance.LoadVocabulary(104, SesIntUserLanguage).TextValue;
            lblZipCode.Text = VocabularyDisplayServices.Instance.LoadVocabulary(105, SesIntUserLanguage).TextValue;
            lblCountry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(106, SesIntUserLanguage).TextValue;
            lblHourlyRate.Text = VocabularyDisplayServices.Instance.LoadVocabulary(107, SesIntUserLanguage).TextValue;
            lblOverTime.Text = VocabularyDisplayServices.Instance.LoadVocabulary(108, SesIntUserLanguage).TextValue;
            lblLogo.Text = VocabularyDisplayServices.Instance.LoadVocabulary(109, SesIntUserLanguage).TextValue;
            lblPrimaryPhone.Text = VocabularyDisplayServices.Instance.LoadVocabulary(110, SesIntUserLanguage).TextValue;
            lblGender.Text = VocabularyDisplayServices.Instance.LoadVocabulary(111, SesIntUserLanguage).TextValue;
            lblBornDate.Text = VocabularyDisplayServices.Instance.LoadVocabulary(112, SesIntUserLanguage).TextValue;
            lblBornCountry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(113, SesIntUserLanguage).TextValue;
            lblReferalType.Text = VocabularyDisplayServices.Instance.LoadVocabulary(114, SesIntUserLanguage).TextValue;
            lblActive.Text = VocabularyDisplayServices.Instance.LoadVocabulary(116, SesIntUserLanguage).TextValue;
            lblUserName.Text = VocabularyDisplayServices.Instance.LoadVocabulary(117, SesIntUserLanguage).TextValue;
            lblPassword.Text = VocabularyDisplayServices.Instance.LoadVocabulary(118, SesIntUserLanguage).TextValue;
            lblPasswordExp.Text = VocabularyDisplayServices.Instance.LoadVocabulary(119, SesIntUserLanguage).TextValue;
            lblTitle.Text = VocabularyDisplayServices.Instance.LoadVocabulary(120, SesIntUserLanguage).TextValue;
            lblDefaultLang.Text = VocabularyDisplayServices.Instance.LoadVocabulary(121, SesIntUserLanguage).TextValue;
            lblManager.Text = VocabularyDisplayServices.Instance.LoadVocabulary(122, SesIntUserLanguage).TextValue;
            lblPosition.Text = VocabularyDisplayServices.Instance.LoadVocabulary(123, SesIntUserLanguage).TextValue;
            lblCitizenshipCountry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(124, SesIntUserLanguage).TextValue;
            lblCitizenshipID.Text = VocabularyDisplayServices.Instance.LoadVocabulary(125, SesIntUserLanguage).TextValue;
            lblCitizenShipExpiration.Text = VocabularyDisplayServices.Instance.LoadVocabulary(126, SesIntUserLanguage).TextValue;
            lblPassportCountry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(127, SesIntUserLanguage).TextValue;
            lblPassportID.Text = VocabularyDisplayServices.Instance.LoadVocabulary(128, SesIntUserLanguage).TextValue;
            lblPasswordExp.Text = VocabularyDisplayServices.Instance.LoadVocabulary(129, SesIntUserLanguage).TextValue;
            lblResidentCountry.Text = VocabularyDisplayServices.Instance.LoadVocabulary(130, SesIntUserLanguage).TextValue;
            lblResidentNumber.Text = VocabularyDisplayServices.Instance.LoadVocabulary(131, SesIntUserLanguage).TextValue;
            lblResidentExpiration.Text = VocabularyDisplayServices.Instance.LoadVocabulary(132, SesIntUserLanguage).TextValue;
            lblWorkVisaID.Text = VocabularyDisplayServices.Instance.LoadVocabulary(133, SesIntUserLanguage).TextValue;
            lblWorkVisaExpiration.Text = VocabularyDisplayServices.Instance.LoadVocabulary(134, SesIntUserLanguage).TextValue;
            lblCoumn1.Text = VocabularyDisplayServices.Instance.LoadVocabulary(135, SesIntUserLanguage).TextValue;
            lblCoumn2.Text = VocabularyDisplayServices.Instance.LoadVocabulary(136, SesIntUserLanguage).TextValue;
            btnSave.Text = VocabularyDisplayServices.Instance.LoadVocabulary(137, SesIntUserLanguage).TextValue;
            btnClose.Text = VocabularyDisplayServices.Instance.LoadVocabulary(138, SesIntUserLanguage).TextValue;
            lblReferalName.Text = VocabularyDisplayServices.Instance.LoadVocabulary(139, SesIntUserLanguage).TextValue;
            lblSASNum.Text = VocabularyDisplayServices.Instance.LoadVocabulary(140, SesIntUserLanguage).TextValue;
            lblCommision.Text = VocabularyDisplayServices.Instance.LoadVocabulary(141, SesIntUserLanguage).TextValue;
            lblAccessGroup.Text = VocabularyDisplayServices.Instance.LoadVocabulary(5001, SesIntUserLanguage).TextValue;
        }
        #endregion

        #region--Check Permissions--
        public void CheckPermission()
        {
            if (SesStrUsersMngRight == "R")
            {
                FUOfferImage.Enabled = false;
                btnClose.Enabled = false;
                btnSave.Enabled = false;
                txtFirstname.ReadOnly = true;
                txtLastName.ReadOnly = true;
                txtAddress1.ReadOnly = true;
                txtCity.ReadOnly = true;
                txtState.ReadOnly = true;
                txtZipCode.ReadOnly = true;
                txtPrimaryPhone.ReadOnly = true;
                txtRefralName.ReadOnly = true;
                ddlCountry.Enabled = false;
                txtHourlyRate.ReadOnly = true;
                txtOverTime.ReadOnly = true;
                txtCommision.ReadOnly = true;
                txtPrimaryPhone.ReadOnly = true;
                ddlGender.Enabled = false;
                txtBornDate.ReadOnly = true;
                ddlBoarnCountry.Enabled = false;
                ddlReferalType.Enabled = false;
                txtRefralName.ReadOnly = true;
                ddlDefaultLang.Enabled = false;
                txtSasNum.ReadOnly = true;
                chkActive.Enabled = false;
                txtUserName.ReadOnly = true;
                txtPassword.ReadOnly = true;
                txtPasswordExp.ReadOnly = true;
                txtTitle.ReadOnly = true;
                ddlPosition.Enabled = false;
                chkManager.Enabled = false;
                ddlCitizenshipCountry.Enabled = false;
                txtCitizenshipID.ReadOnly = true;
                txtCitizenShipExpiration.ReadOnly = true;
                ddlPassportCountry.Enabled = false;
                txtPassportID.ReadOnly = true;
                txtPassportExpiration.ReadOnly = true;
                txtPasswordExp.ReadOnly = true;
                txtResidentNumber.ReadOnly = true;
                txtResidentExpiration.ReadOnly = true;
                ddlResidentCountry.Enabled = false;

                txtWorkVisaID.ReadOnly = true;
                txtWorkVisaExpiration.ReadOnly = true;

                txtField1Name.ReadOnly = true;
                txtField1Value.ReadOnly = true;

                txtField2Name.ReadOnly = true;
                txtField2Value.ReadOnly = true;

                txtField3Name.ReadOnly = true;
                txtField3Value.ReadOnly = true;

                txtField4Name.ReadOnly = true;
                txtField4Value.ReadOnly = true;

                txtField5Name.ReadOnly = true;
                txtField5Value.ReadOnly = true;

                txtField6Name.ReadOnly = true;
                txtField6Value.ReadOnly = true;

                txtField7Name.ReadOnly = true;
                txtField7Value.ReadOnly = true;

                txtField8Name.ReadOnly = true;
                txtField8Value.ReadOnly = true;
            }
        }
        #endregion

        #region--Initialize Web Form--
        public void InitializeForm()
        {
            txtFirstname.Text = "";
            txtLastName.Text = "";
            txtAddress1.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtZipCode.Text = "";
            txtPrimaryPhone.Text = "";
            txtRefralName.Text = "";
            ddlCountry.ClearSelection();
            ddlCountry.SelectedIndex = 0;
            txtHourlyRate.Text = "";
            txtOverTime.Text = "";
            txtCommision.Text = "";
            txtPrimaryPhone.Text = "";
            ddlGender.ClearSelection();
            ddlGender.SelectedIndex = 0;
            txtBornDate.Text = "";
            ddlBoarnCountry.ClearSelection();
            ddlBoarnCountry.SelectedIndex = 0;
            ddlReferalType.ClearSelection();
            ddlReferalType.SelectedIndex = 0;
            txtRefralName.Text = "";
            ddlDefaultLang.ClearSelection();
            ddlDefaultLang.SelectedIndex = 0;
            txtSasNum.Text = "";
            chkActive.Checked = false;
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtPasswordExp.Text = "";
            txtTitle.Text = "";
            ddlPosition.ClearSelection();
            ddlPosition.SelectedIndex = 0;
            chkManager.Checked = false;
            ddlCitizenshipCountry.ClearSelection();
            ddlCitizenshipCountry.SelectedIndex = 0;
            txtCitizenshipID.Text = "";
            txtCitizenShipExpiration.Text = "";
            ddlPassportCountry.ClearSelection();
            ddlPassportCountry.SelectedIndex = 0;
            txtPassportID.Text = "";
            txtPassportExpiration.Text = "";
            txtPasswordExp.Text = "";
            txtResidentNumber.Text = "";
            txtResidentExpiration.Text = "";
            ddlResidentCountry.ClearSelection();
            ddlResidentCountry.SelectedIndex = 0;

            txtWorkVisaID.Text = "";
            txtWorkVisaExpiration.Text = "";

            txtField1Name.Text = "";
            txtField1Value.Text = "";

            txtField2Name.Text = "";
            txtField2Value.Text = "";

            txtField3Name.Text = "";
            txtField3Value.Text = "";

            txtField4Name.Text = "";
            txtField4Value.Text = "";

            txtField5Name.Text = "";
            txtField5Value.Text = "";

            txtField6Name.Text = "";
            txtField6Value.Text = "";

            txtField7Name.Text = "";
            txtField7Value.Text = "";

            txtField8Name.Text = "";
            txtField8Value.Text = "";
        }
        #endregion

        #region--Bind User--
        public void BindUser()
        {
            if (UserNum > 0)
            {
                User _user = UserServices.Instance.GetUser(UserNum);
                if (_user == null)
                {
                    Helper.ShowMessage(msgDiv, "User not exit.", false);
                    return;
                }
                txtFirstname.Text = _user.FirstName;
                txtLastName.Text = _user.LastName;
                txtAddress1.Text = _user.Adress1;
                txtCity.Text = _user.City;
                txtState.Text = _user.State;
                txtZipCode.Text = _user.ZipCode;
                txtPrimaryPhone.Text = _user.PrimaryPhone;
                txtRefralName.Text = _user.ReferalName;
                if (ddlCountry.Items.FindByValue(_user.CountryNum.ToString()) != null)
                {
                    ddlCountry.ClearSelection();
                    ddlCountry.Items.FindByValue(_user.CountryNum.ToString()).Selected = true;
                }

                txtHourlyRate.Text = _user.HourlyRate.ToString();
                txtOverTime.Text = _user.HourlyRateOT.ToString();
                txtCommision.Text = _user.Commission.ToString();
                txtPrimaryPhone.Text = _user.PrimaryPhone;

                if (ddlGender.Items.FindByValue(_user.GenderNum.ToString()) != null)
                {
                    ddlGender.ClearSelection();
                    ddlGender.Items.FindByValue(_user.GenderNum.ToString()).Selected = true;
                }

                txtBornDate.Text = _user.BirthDate == null ? "" : ((DateTime)_user.BirthDate).ToString("dd/MM/yyyy");
                if (ddlBoarnCountry.Items.FindByValue(_user.BirthCountryNum.ToString()) != null)
                {
                    ddlBoarnCountry.ClearSelection();
                    ddlBoarnCountry.Items.FindByValue(_user.BirthCountryNum.ToString()).Selected = true;
                }
                if (ddlReferalType.Items.FindByValue(_user.ReferalTypeNum.ToString()) != null)
                {
                    ddlReferalType.ClearSelection();
                    ddlReferalType.Items.FindByValue(_user.ReferalTypeNum.ToString()).Selected = true;
                }


                txtRefralName.Text = _user.ReferalName;
                if (ddlDefaultLang.Items.FindByValue(_user.LanguageNum.ToString()) != null)
                {
                    ddlDefaultLang.ClearSelection();
                    ddlDefaultLang.Items.FindByValue(_user.LanguageNum.ToString()).Selected = true;
                }

                txtSasNum.Text = _user.SASId;
                chkActive.Checked = _user.Active == null ? false : (bool)_user.Active;
                txtUserName.Text = _user.UserName;
                txtPassword.Text = _user.Password;


                txtPasswordExp.Text = _user.PasswordExpDate == null ? "" : ((DateTime)_user.PasswordExpDate).ToString("dd/MM/yyyy");
                txtTitle.Text = _user.Title;
                if (ddlPosition.Items.FindByValue(_user.PositionNum.ToString()) != null)
                {
                    ddlPosition.ClearSelection();
                    ddlPosition.Items.FindByValue(_user.PositionNum.ToString()).Selected = true;
                }

                chkManager.Checked = _user.IsManager == null ? false : (bool)_user.IsManager;
                if (ddlCitizenshipCountry.Items.FindByValue(_user.CitizenshipCountryNum.ToString()) != null)
                {
                    ddlCitizenshipCountry.ClearSelection();
                    ddlCitizenshipCountry.Items.FindByValue(_user.CitizenshipCountryNum.ToString()).Selected = true;
                }

                txtCitizenshipID.Text = _user.CitizenshipID;

                txtCitizenShipExpiration.Text = _user.CitizenshipExpDate == null ? "" : ((DateTime)_user.CitizenshipExpDate).ToString("dd/MM/yyyy");


                if (ddlPassportCountry.Items.FindByValue(_user.PassportCountryNum.ToString()) != null)
                {
                    ddlPassportCountry.ClearSelection();
                    ddlPassportCountry.Items.FindByValue(_user.PassportCountryNum.ToString()).Selected = true;
                }

                txtPassportID.Text = _user.PassportID;
                txtPassportExpiration.Text = _user.PassportExpDate == null ? "" : ((DateTime)_user.PassportExpDate).ToString("dd/MM/yyyy");
                txtPasswordExp.Text = _user.PasswordExpDate == null ? "" : ((DateTime)_user.PasswordExpDate).ToString("dd/MM/yyyy");

                txtResidentNumber.Text = _user.ResidentID;
                txtResidentExpiration.Text = _user.ResidentIDExpDate == null ? "" : ((DateTime)_user.ResidentIDExpDate).ToString("dd/MM/yyyy");


                if (ddlResidentCountry.Items.FindByValue(_user.ResidentCountryNum.ToString()) != null)
                {
                    ddlResidentCountry.ClearSelection();
                    ddlResidentCountry.Items.FindByValue(_user.ResidentCountryNum.ToString()).Selected = true;
                }

                if (_user.LogoPath != null)
                {
                    OfferImageImageprw.ImageUrl = _user.LogoPath == "" ? "~/images/no_image.png" : _user.LogoPath;
                }


                txtWorkVisaID.Text = _user.WorkVisaID;
                txtWorkVisaExpiration.Text = _user.WorkVisaExpDate == null ? "" : ((DateTime)_user.WorkVisaExpDate).ToString("dd/MM/yyyy");

                txtField1Name.Text = _user.CustomField1Name;
                txtField1Value.Text = _user.CustomField1Value;

                txtField2Name.Text = _user.CustomField2Name;
                txtField2Value.Text = _user.CustomField2Value;

                txtField3Name.Text = _user.CustomField3Name;
                txtField3Value.Text = _user.CustomField3Value;

                txtField4Name.Text = _user.CustomField4Name;
                txtField4Value.Text = _user.CustomField4Value;

                txtField5Name.Text = _user.CustomField5Name;
                txtField5Value.Text = _user.CustomField5Value;

                txtField6Name.Text = _user.CustomField6Name;
                txtField6Value.Text = _user.CustomField6Value;

                txtField7Name.Text = _user.CustomField7Name;
                txtField7Value.Text = _user.CustomField7Value;

                txtField8Name.Text = _user.CustomField8Name;
                txtField8Value.Text = _user.CustomField8Value;
            }
            else { btnUserAccessManagement.Enabled = false; }
        }
        #endregion

        #region--Check Other Field Visibility--
        public void CheckOtherFieldVisibility()
        {
            GeneralSetting ObjGenSet = GeneralSettingServices.Instance.GetGeneralSettings(SesGlobalCustomerNum);
            if (ObjGenSet != null)
            {
                if (ObjGenSet.CustomFieldVis1 == false)
                    pnlField1.Visible = false;
                if (ObjGenSet.CustomFieldVis2 == false)
                    pnlField2.Visible = false;
                if (ObjGenSet.CustomFieldVis3 == false)
                    pnlField3.Visible = false;
                if (ObjGenSet.CustomFieldVis4 == false)
                    pnlField4.Visible = false;
                if (ObjGenSet.CustomFieldVis5 == false)
                    pnlField5.Visible = false;
                if (ObjGenSet.CustomFieldVis6 == false)
                    pnlField6.Visible = false;
                if (ObjGenSet.CustomFieldVis7 == false)
                    pnlField7.Visible = false;
                if (ObjGenSet.CustomFieldVis8 == false)
                    pnlField8.Visible = false;
            }

        }
        #endregion

        #region--Save User--
        protected void btnSave_Click(object sender, EventArgs e)
        {
            User _user = new User();
            if (UserNum > 0)
            {
                _user = UserServices.Instance.GetUser(UserNum);
                if (_user == null)
                {
                    Helper.ShowMessage(msgDiv, "User not exit.", false);
                    return;

                }
            }
            int CountryID = 0;
            int.TryParse(ddlCountry.SelectedValue, out CountryID);

            float HourlyRate = 0;
            float.TryParse(txtHourlyRate.Text, out HourlyRate);

            float HourlyRateOT = 0;
            float.TryParse(txtOverTime.Text, out HourlyRateOT);

            int GenderNum = 0;
            int.TryParse(ddlGender.SelectedValue, out GenderNum);

            int BirthCountryID = 0;
            int.TryParse(ddlBoarnCountry.SelectedValue, out BirthCountryID);

            int ReferalTypeNum = 0;
            int.TryParse(ddlReferalType.SelectedValue, out ReferalTypeNum);

            int languageNum = 0;
            int.TryParse(ddlDefaultLang.SelectedValue, out languageNum);

            int PositionNum = 0;
            int.TryParse(ddlPosition.SelectedValue, out PositionNum);

            int CitizenshipCountryNum = 0;
            int.TryParse(ddlCitizenshipCountry.SelectedValue, out CitizenshipCountryNum);

            int PassportCountryNum = 0;
            int.TryParse(ddlPassportCountry.SelectedValue, out PassportCountryNum);

            int ResidentCountryNum = 0;
            int.TryParse(ddlResidentCountry.SelectedValue, out ResidentCountryNum);

            int Commission = 0;
            int.TryParse(txtCommision.Text, out Commission);

            _user.GlobalCustomerNum = SesGlobalCustomerNum;
            _user.FirstName = txtFirstname.Text;
            _user.LastName = txtLastName.Text;
            _user.Adress1 = txtAddress1.Text;
            _user.City = txtCity.Text;
            _user.State = txtState.Text;
            _user.ZipCode = txtZipCode.Text;
            _user.CountryNum = CountryID;
            _user.HourlyRate = HourlyRate;
            _user.HourlyRateOT = HourlyRateOT;
            _user.Commission = Commission;
            _user.PrimaryPhone = txtPrimaryPhone.Text;
            _user.GenderNum = GenderNum;
            try
            {
                _user.BirthDate = DateTime.ParseExact(txtBornDate.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            _user.BirthCountryNum = BirthCountryID;
            _user.ReferalTypeNum = ReferalTypeNum;
            _user.ReferalName = txtRefralName.Text;
            _user.LanguageNum = languageNum;
            _user.SASId = txtSasNum.Text;
            _user.Active = chkActive.Checked;
            _user.UserName = txtUserName.Text;
            _user.Password = txtPassword.Text;
            try
            {
                _user.PasswordExpDate = DateTime.ParseExact(txtPasswordExp.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            _user.Title = txtTitle.Text;
            _user.PositionNum = PositionNum;
            _user.IsManager = chkManager.Checked;
            _user.CitizenshipCountryNum = CitizenshipCountryNum;
            _user.CitizenshipID = txtCitizenshipID.Text;
            try
            {
                _user.CitizenshipExpDate = DateTime.ParseExact(txtCitizenShipExpiration.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            _user.PassportCountryNum = PassportCountryNum;
            _user.PassportID = txtPassportID.Text;
            try
            {
                _user.PassportExpDate = DateTime.ParseExact(txtPassportExpiration.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            _user.ResidentID = txtResidentNumber.Text;
            try
            {
                _user.ResidentIDExpDate = DateTime.ParseExact(txtResidentExpiration.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            _user.ResidentCountryNum = ResidentCountryNum;
            _user.WorkVisaID = txtWorkVisaID.Text;
            try
            {
                _user.WorkVisaExpDate = DateTime.ParseExact(txtWorkVisaExpiration.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch { }
            if (pnlField1.Visible)
            {
                _user.CustomField1Name = txtField1Name.Text;
                _user.CustomField1Value = txtField1Value.Text;
                _user.CustomField1Vis = true;
            }
            else
            {
                _user.CustomField1Vis = false;
            }

            if (pnlField2.Visible)
            {
                _user.CustomField2Name = txtField2Name.Text;
                _user.CustomField2Value = txtField2Value.Text;
                _user.CustomField2Vis = true;
            }
            else
            {
                _user.CustomField2Vis = false;
            }

            if (pnlField3.Visible)
            {
                _user.CustomField3Name = txtField3Name.Text;
                _user.CustomField3Value = txtField3Value.Text;
                _user.CustomField3Vis = true;
            }
            else
            {
                _user.CustomField3Vis = false;
            }

            if (pnlField4.Visible)
            {
                _user.CustomField4Name = txtField4Name.Text;
                _user.CustomField4Value = txtField4Value.Text;
                _user.CustomField4Vis = true;
            }
            else
            {
                _user.CustomField4Vis = false;
            }

            if (pnlField5.Visible)
            {
                _user.CustomField5Name = txtField5Name.Text;
                _user.CustomField5Value = txtField5Value.Text;
                _user.CustomField5Vis = true;
            }
            else
            {
                _user.CustomField5Vis = false;
            }

            if (pnlField6.Visible)
            {
                _user.CustomField6Name = txtField6Name.Text;
                _user.CustomField6Value = txtField6Value.Text;
                _user.CustomField6Vis = true;
            }
            else
            {
                _user.CustomField6Vis = false;
            }

            if (pnlField7.Visible)
            {
                _user.CustomField7Name = txtField7Name.Text;
                _user.CustomField7Value = txtField7Value.Text;
                _user.CustomField7Vis = true;
            }
            else
            {
                _user.CustomField7Vis = false;
            }

            if (pnlField8.Visible)
            {
                _user.CustomField8Name = txtField8Name.Text;
                _user.CustomField8Value = txtField8Value.Text;
                _user.CustomField8Vis = true;
            }
            else
            {
                _user.CustomField8Vis = false;
            }

            if (UserNum == 0)
            {
                int temp = UserServices.Instance.InsertUser(_user);
                if (temp > 0)
                {
                    if (FUOfferImage.HasFile)
                    {
                        try
                        {
                            _user = UserServices.Instance.GetUser(temp);
                            if (_user != null)
                            {
                                string filename = temp.ToString() + Path.GetExtension(FUOfferImage.FileName.ToString());
                                string OfferImageFolderpath = System.Web.HttpContext.Current.Server.MapPath("~" + AppConstants.Instance.UserLogoVirtuelPath);
                                FUOfferImage.SaveAs(OfferImageFolderpath + "\\" + filename);
                                _user.LogoPath = AppConstants.Instance.UserLogoVirtuelPath + filename;
                                UserServices.Instance.UpdateUser(_user);
                            }
                        }
                        catch
                        { }
                    }
                    //success
                    Helper.ShowMessage(msgDiv, "User is successfully created.", true);
                    InitializeForm();

                }
                else
                {
                    //Fails
                    Helper.ShowMessage(msgDiv, "Unable to create User.", false);

                }
            }
            else
            {
                try
                {
                    if (FUOfferImage.HasFile)
                    {
                        string filename = UserNum.ToString() + Path.GetExtension(FUOfferImage.FileName.ToString());
                        string OfferImageFolderpath = System.Web.HttpContext.Current.Server.MapPath("~" + AppConstants.Instance.UserLogoVirtuelPath);
                        FUOfferImage.SaveAs(OfferImageFolderpath + "\\" + filename);
                        _user.LogoPath = AppConstants.Instance.UserLogoVirtuelPath + filename;
                    }
                }
                catch
                { }
                UserServices.Instance.UpdateUser(_user);
                BindUser();
                Helper.ShowMessage(msgDiv, "User is successfully updated.", true);
            }

        }
        #endregion

        #region --AccessGroup DropDown Change Event--
        protected void ddlAccessGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindRepeater();
        }
        #endregion

        #region--Bind Repeater--
        protected void BindRepeater()
        {
            int AccessGroupNum = int.Parse(ddlAccessGroup.SelectedValue);
            List<Access> UserAccess = new List<Access>();
            if (AccessGroupNum > 0)
            {
                UserAccess = AccessServices.Instance.GetAccess(0, AccessGroupNum);
            }
            rtpUserModule.DataSource = UserAccess;
            rtpUserModule.DataBind();
        }
        #endregion

        protected void btnUpSave_Click(object sender, EventArgs e)
        {
            if (UserNum > 0)
            {
                try
                {
                    foreach (RepeaterItem item in rtpUserModule.Items)
                    {
                        CheckBox chkReadAccess = item.FindControl("chkReadAccess") as CheckBox;
                        CheckBox chkWriteAccess = item.FindControl("chkWriteAccess") as CheckBox;
                        HiddenField hdnAccessNum = item.FindControl("hdnAccessNum") as HiddenField;
                        if (chkReadAccess != null && chkWriteAccess != null && hdnAccessNum != null)
                        {
                            int AccessNum = int.Parse(hdnAccessNum.Value);
                            UserAccess useraccess = UserAccessesServices.Instance.GetUserAccess(0, AccessNum, UserNum).FirstOrDefault();
                            if (useraccess == null)
                            {
                                useraccess = new UserAccess();
                            }

                            useraccess.ReadAccess = chkReadAccess.Checked;
                            useraccess.WriteAccess = chkWriteAccess.Checked;
                            useraccess.GlobalCustomerNum = SesGlobalCustomerNum;
                            useraccess.UserNum = UserNum;
                            useraccess.AccessNum = AccessNum;
                            UserAccessesServices.Instance.CreateUpdateUserAccess(useraccess);

                        }
                    }
                }
                catch { }

                UserAccessMsg.Text = "User Access settings are saved.";

            }
        }

        protected void rtpUserModule_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Access data = (Access)e.Item.DataItem;
                CheckBox chkReadAccess = (CheckBox)e.Item.FindControl("chkReadAccess");
                CheckBox chkWriteAccess = (CheckBox)e.Item.FindControl("chkWriteAccess");

                if ((chkWriteAccess != null) && (chkReadAccess != null))
                {
                    UserAccess useraccess = UserAccessesServices.Instance.GetUserAccess(0, data.AccessNum, UserNum).FirstOrDefault();
                    if (useraccess != null)
                    {
                        chkReadAccess.Checked = useraccess.ReadAccess == null ? false : (bool)useraccess.ReadAccess;
                        chkWriteAccess.Checked = useraccess.WriteAccess == null ? false : (bool)useraccess.WriteAccess;
                    }
                }
            }
        }

    }
}