﻿$(document).ready(function () {
    
    $("#formCustomer").validate({
        ignore: ".ignore",
        rules: {
            txtName: {
                required: true,
                minlength: 3,
                maxlength : 30
            },

            txtCode: {
                required: true,
                minlength: 4,
                maxlength : 10
            },
            txtBalance: {
                required:true,
                number: true,
                min: 0,
                max : 999999,
            },
            txtTotalCredit: {
                required: true,
                number: true,
                min : 0,
                max : 999999,
            },

            txtZipCode :{
                number:true,
            },

            txtEmail: {
                email: true
            },

            txtWebsite: {
                url: true
            },
        },
        messages: {

            txtName: {
                required: 'Name is required',
                minlength: 'Minimum Length is 3',
                maxlength: 'Maximum Length is 30'
            },

            txtCode: {
                required: 'Code is required',
                minlength: 'Minimum length is 3',
                maxlength: 'Maximum length is 10'
            },
            txtBalance: {
                required: "Value should be between 0 and 99999",
                number: 'Enter a valid number',
                min: "Value should be between 0 and 99999",
                max: "Value should be between 0 and 99999",
            },
            txtTotalCredit: {
                required: "Value should be between 0 and 99999",
                number: 'Enter a valid number',
                min: "Value should be between 0 and 99999",
                max: "Value should be between 0 and 99999",
            },

            txtZipCode: {
                number: 'Enter a valid number',
            },

            txtEmail: {
                email: 'Enter a valid email'
            },

            txtWebsite: {
                url: 'Enter a valid url'
            },
        }
    });
});
