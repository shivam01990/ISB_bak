﻿//Image Preview Functions
function showimagepreview(input, PreviewImageID, ErrorSpanID) {
    var rType = checkfile(input, ErrorSpanID);
    if (rType == true) {
        if (input.files && input.files[0]) {
            var filerdr = new FileReader();
            filerdr.onload = function (e) {
                $("[id$=" + PreviewImageID + "]").attr('src', e.target.result);
            }
            filerdr.readAsDataURL(input.files[0]);
        }
    }
    else {
        $(input).filestyle('clear');
    }
    return rType;
}

function checkfile(input, ErrorSpanID) {
    //debugger;
    $("[id$=" + ErrorSpanID + "]").text("");
    var file = getNameFromPath($("[id$=" + input.id + "]").val());
    if (file != null) {
        var extension = file.substr((file.lastIndexOf('.') + 1));
        switch (extension) {
            case 'jpg':
            case 'JPG':
            case 'jpeg':
            case 'JPEG':
            case 'png':
            case 'PNG':
            case 'gif':
            case 'GIF':
                flag = true;
                break;
            default:
                flag = false;
        }
    }
    if (flag == false) {
        $("[id$=" + ErrorSpanID + "]").text("You can upload only jpg,png,gif extension file");
        return false;
    }
    return flag;
}

function getNameFromPath(strFilepath) {
    var objRE = new RegExp(/([^\/\\]+)$/);
    var strName = objRE.exec(strFilepath);
    if (strName == null) {
        return null;
    }
    else {
        return strName[0];
    }
}
//End Image Preview Functions