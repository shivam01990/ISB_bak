﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class UserAccessesEntity
    {
        public int UserAccessNum { get; set; }
        public int GlobalCustomerNum { get; set; }
        public int UserNum { get; set; }
        public int CoreModuleNum { get; set; }
        public int AccessNum { get; set; }
        public string AccessName { get; set; }
        public int AccessGroupNum { get; set; }
        public bool ReadAccess { get; set; }
        public bool WriteAccess { get; set; }
    }
}
